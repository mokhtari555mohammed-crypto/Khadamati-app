import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'routes/app_pages.dart';
import 'routes/app_routes.dart';
import 'theme/app_theme.dart';
import 'translations/app_translations.dart';
import '../core/services/storage_service.dart';

class KhadamatiApp extends StatelessWidget {
  const KhadamatiApp({super.key});

  @override
  Widget build(BuildContext context) {
    final locale = StorageService.getLocale();

    return GetMaterialApp(
      title: 'Khadamati | خدماتي',
      debugShowCheckedModeBanner: false,

      // Theme
      theme: AppTheme.lightTheme,

      // Routing
      initialRoute: AppRoutes.SPLASH,
      getPages: AppPages.routes,

      // Localization
      locale: locale,
      fallbackLocale: const Locale('fr', 'FR'),
      translations: AppTranslations(),
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('fr', 'FR'),
        Locale('ar', 'AR'),
      ],

      // RTL support
      builder: (context, child) {
        return Directionality(
          textDirection: Get.locale?.languageCode == 'ar'
              ? TextDirection.rtl
              : TextDirection.ltr,
          child: child!,
        );
      },
    );
  }
}
