import 'package:get/get.dart';

import 'app_routes.dart';
import '../../features/auth/bindings/auth_binding.dart';
import '../../features/auth/views/splash_view.dart';
import '../../features/auth/views/client_login_view.dart';
import '../../features/auth/views/artisan_login_view.dart';
import '../../features/auth/views/admin_login_view.dart';
import '../../features/auth/views/client_register_view.dart';
import '../../features/auth/views/artisan_register_view.dart';
import '../../features/auth/views/forgot_password_view.dart';
import '../../features/home/bindings/home_binding.dart';
import '../../features/home/views/home_view.dart';
import '../../features/home/views/about_view.dart';
import '../../features/search/bindings/search_binding.dart';
import '../../features/search/views/find_expert_view.dart';
import '../../features/search/views/artisan_profile_view.dart';
import '../../features/services_pages/bindings/services_binding.dart';
import '../../features/services_pages/views/service_details_view.dart';
import '../../features/services_pages/views/request_quote_view.dart';
import '../../features/services_pages/views/service_pricing_view.dart';
import '../../features/services_pages/views/moving_booking_view.dart';
import '../../features/services_pages/views/message_success_view.dart';
import '../../features/services_pages/views/subcategory_details_view.dart';
import '../../features/client/bindings/client_binding.dart';
import '../../features/client/views/client_inbox_view.dart';
import '../../features/client/views/client_projects_view.dart';
import '../../features/client/views/client_messages_view.dart';
import '../../features/client/views/client_favorites_view.dart';
import '../../features/client/views/client_settings_view.dart';
import '../../features/artisan/bindings/artisan_binding.dart';
import '../../features/artisan/views/artisan_dashboard_view.dart';
import '../../features/artisan/views/artisan_projects_view.dart';
import '../../features/artisan/views/artisan_pricing_view.dart';
import '../../features/artisan/views/artisan_messages_view.dart';
import '../../features/artisan/views/artisan_settings_view.dart';
import '../../features/artisan/views/artisan_verifications_view.dart';
import '../../features/admin/bindings/admin_binding.dart';
import '../../features/admin/views/admin_dashboard_view.dart';
import '../../features/admin/views/admin_artisans_view.dart';
import '../../features/admin/views/admin_clients_view.dart';
import '../../features/admin/views/admin_projects_view.dart';
import '../../features/admin/views/admin_verifications_view.dart';
import '../../features/admin/views/admin_payments_view.dart';
import '../../features/admin/views/admin_settings_view.dart';
import '../../features/admin/views/admin_evidence_view.dart';
import '../../features/admin/views/admin_configuration_view.dart';

class AppPages {
  static final routes = [
    GetPage(
      name: AppRoutes.SPLASH,
      page: () => const SplashView(),
      binding: AuthBinding(),
    ),
    // ── AUTH ──────────────────────────────────────────────────────────
    GetPage(
      name: AppRoutes.CLIENT_LOGIN,
      page: () => const ClientLoginView(),
      binding: AuthBinding(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: AppRoutes.ARTISAN_LOGIN,
      page: () => const ArtisanLoginView(),
      binding: AuthBinding(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: AppRoutes.ADMIN_LOGIN,
      page: () => const AdminLoginView(),
      binding: AuthBinding(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: AppRoutes.CLIENT_REGISTER,
      page: () => const ClientRegisterView(),
      binding: AuthBinding(),
      transition: Transition.rightToLeft,
    ),
    GetPage(
      name: AppRoutes.ARTISAN_REGISTER,
      page: () => const ArtisanRegisterView(),
      binding: AuthBinding(),
      transition: Transition.rightToLeft,
    ),
    GetPage(
      name: AppRoutes.FORGOT_PASSWORD,
      page: () => const ForgotPasswordView(),
      binding: AuthBinding(),
    ),
    // ── PUBLIC ──────────────────────────────────────────────────────────
    GetPage(
      name: AppRoutes.HOME,
      page: () => const HomeView(),
      binding: HomeBinding(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: AppRoutes.ABOUT_US,
      page: () => const AboutView(),
      binding: HomeBinding(),
    ),
    GetPage(
      name: AppRoutes.FIND_EXPERT,
      page: () => const FindExpertView(),
      binding: SearchBinding(),
      transition: Transition.rightToLeft,
    ),
    GetPage(
      name: AppRoutes.ARTISAN_PROFILE,
      page: () => const ArtisanProfileView(),
      binding: SearchBinding(),
      transition: Transition.rightToLeft,
    ),
    GetPage(
      name: AppRoutes.SERVICE_DETAILS,
      page: () => const ServiceDetailsView(),
      binding: ServicesBinding(),
      transition: Transition.rightToLeft,
    ),
    GetPage(
      name: AppRoutes.SERVICE_PRICING,
      page: () => const ServicePricingView(),
      binding: ServicesBinding(),
    ),
    GetPage(
      name: AppRoutes.REQUEST_QUOTE,
      page: () => const RequestQuoteView(),
      binding: ServicesBinding(),
      transition: Transition.rightToLeft,
    ),
    GetPage(
      name: AppRoutes.MOVING_BOOKING,
      page: () => const MovingBookingView(),
      binding: ServicesBinding(),
    ),
    GetPage(
      name: AppRoutes.MESSAGE_SUCCESS,
      page: () => const MessageSuccessView(),
      binding: ServicesBinding(),
    ),
    GetPage(
      name: AppRoutes.SUBCATEGORY_DETAILS,
      page: () => const SubcategoryDetailsView(),
      binding: ServicesBinding(),
    ),
    // ── CLIENT ──────────────────────────────────────────────────────────
    GetPage(
      name: AppRoutes.CLIENT_INBOX,
      page: () => const ClientInboxView(),
      binding: ClientBinding(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: AppRoutes.CLIENT_PROJECTS,
      page: () => const ClientProjectsView(),
      binding: ClientBinding(),
    ),
    GetPage(
      name: AppRoutes.CLIENT_MESSAGES,
      page: () => const ClientMessagesView(),
      binding: ClientBinding(),
    ),
    GetPage(
      name: AppRoutes.CLIENT_FAVORITES,
      page: () => const ClientFavoritesView(),
      binding: ClientBinding(),
    ),
    GetPage(
      name: AppRoutes.CLIENT_SETTINGS,
      page: () => const ClientSettingsView(),
      binding: ClientBinding(),
    ),
    // ── ARTISAN ──────────────────────────────────────────────────────────
    GetPage(
      name: AppRoutes.ARTISAN_DASHBOARD,
      page: () => const ArtisanDashboardView(),
      binding: ArtisanBinding(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: AppRoutes.ARTISAN_PROJECTS,
      page: () => const ArtisanProjectsView(),
      binding: ArtisanBinding(),
    ),
    GetPage(
      name: AppRoutes.ARTISAN_PRICING,
      page: () => const ArtisanPricingView(),
      binding: ArtisanBinding(),
    ),
    GetPage(
      name: AppRoutes.ARTISAN_MESSAGES,
      page: () => const ArtisanMessagesView(),
      binding: ArtisanBinding(),
    ),
    GetPage(
      name: AppRoutes.ARTISAN_SETTINGS,
      page: () => const ArtisanSettingsView(),
      binding: ArtisanBinding(),
    ),
    GetPage(
      name: AppRoutes.ARTISAN_VERIFICATIONS,
      page: () => const ArtisanVerificationsView(),
      binding: ArtisanBinding(),
    ),
    // ── ADMIN ──────────────────────────────────────────────────────────
    GetPage(
      name: AppRoutes.ADMIN_DASHBOARD,
      page: () => const AdminDashboardView(),
      binding: AdminBinding(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: AppRoutes.ADMIN_ARTISANS,
      page: () => const AdminArtisansView(),
      binding: AdminBinding(),
    ),
    GetPage(
      name: AppRoutes.ADMIN_CLIENTS,
      page: () => const AdminClientsView(),
      binding: AdminBinding(),
    ),
    GetPage(
      name: AppRoutes.ADMIN_PROJECTS,
      page: () => const AdminProjectsView(),
      binding: AdminBinding(),
    ),
    GetPage(
      name: AppRoutes.ADMIN_VERIFICATIONS,
      page: () => const AdminVerificationsView(),
      binding: AdminBinding(),
    ),
    GetPage(
      name: AppRoutes.ADMIN_PAYMENTS,
      page: () => const AdminPaymentsView(),
      binding: AdminBinding(),
    ),
    GetPage(
      name: AppRoutes.ADMIN_SETTINGS,
      page: () => const AdminSettingsView(),
      binding: AdminBinding(),
    ),
    GetPage(
      name: AppRoutes.ADMIN_EVIDENCE,
      page: () => const AdminEvidenceView(),
      binding: AdminBinding(),
    ),
    GetPage(
      name: AppRoutes.ADMIN_CONFIGURATION,
      page: () => const AdminConfigurationView(),
      binding: AdminBinding(),
    ),
  ];
}
