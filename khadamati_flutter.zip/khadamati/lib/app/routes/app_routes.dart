abstract class AppRoutes {
  // Splash & Onboarding
  static const SPLASH = '/';

  // Auth
  static const CLIENT_LOGIN = '/login/client';
  static const ARTISAN_LOGIN = '/login/artisan';
  static const ADMIN_LOGIN = '/login/admin';
  static const CLIENT_REGISTER = '/register/client';
  static const ARTISAN_REGISTER = '/register/artisan';
  static const FORGOT_PASSWORD = '/forgot-password';

  // Public
  static const HOME = '/home';
  static const ABOUT_US = '/about-us';
  static const FIND_EXPERT = '/search';
  static const ARTISAN_PROFILE = '/artisan/:id';
  static const SERVICE_DETAILS = '/service/:id';
  static const SERVICE_PRICING = '/services/pricing';
  static const REQUEST_QUOTE = '/request-quote';
  static const MOVING_BOOKING = '/moving-booking';
  static const MESSAGE_SUCCESS = '/message-success';
  static const SUBCATEGORY_DETAILS = '/subcategory/:id';

  // Client Dashboard
  static const CLIENT_INBOX = '/dashboard/client/inbox';
  static const CLIENT_PROJECTS = '/dashboard/client/projects';
  static const CLIENT_MESSAGES = '/dashboard/client/messages';
  static const CLIENT_FAVORITES = '/dashboard/client/favorites';
  static const CLIENT_SETTINGS = '/dashboard/client/settings';

  // Artisan Dashboard
  static const ARTISAN_DASHBOARD = '/dashboard/artisan';
  static const ARTISAN_PROJECTS = '/dashboard/artisan/projects';
  static const ARTISAN_PRICING = '/dashboard/artisan/pricing';
  static const ARTISAN_MESSAGES = '/dashboard/artisan/messages';
  static const ARTISAN_SETTINGS = '/dashboard/artisan/settings';
  static const ARTISAN_VERIFICATIONS = '/dashboard/artisan/verifications';

  // Admin Dashboard
  static const ADMIN_DASHBOARD = '/dashboard/admin';
  static const ADMIN_ARTISANS = '/dashboard/admin/artisans';
  static const ADMIN_CLIENTS = '/dashboard/admin/clients';
  static const ADMIN_PROJECTS = '/dashboard/admin/projects';
  static const ADMIN_VERIFICATIONS = '/dashboard/admin/verifications';
  static const ADMIN_PAYMENTS = '/dashboard/admin/payments';
  static const ADMIN_SETTINGS = '/dashboard/admin/settings';
  static const ADMIN_EVIDENCE = '/dashboard/admin/evidence';
  static const ADMIN_CONFIGURATION = '/dashboard/admin/configuration';

  // Services / Categories
  static const JARDINAGE = '/category/jardinage';
  static const PEINTURE_CATEGORY = '/category/peinture';
  static const ELECTRICITE_CATEGORY = '/category/electricite';
  static const PLOMBERIE_CATEGORY = '/category/plomberie';
}
