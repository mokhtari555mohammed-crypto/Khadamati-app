import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  // Brand
  static const primary = Color(0xFF004C96);
  static const secondary = Color(0xFFF28B2C);
  static const primaryLight = Color(0xFFE8F0FB);
  static const secondaryLight = Color(0xFFFFF3E0);

  // Neutrals
  static const slate900 = Color(0xFF0F172A);
  static const slate700 = Color(0xFF334155);
  static const slate500 = Color(0xFF64748B);
  static const slate400 = Color(0xFF94A3B8);
  static const slate300 = Color(0xFFCBD5E1);
  static const slate100 = Color(0xFFF1F5F9);
  static const slate50  = Color(0xFFF8FAFC);
  static const white    = Color(0xFFFFFFFF);
  static const slate200 = Color(0xFFE2E8F0);
  static const slate600 = Color(0xFF475569);

  // Status
  static const emerald500 = Color(0xFF10B981);
  static const emerald50  = Color(0xFFECFDF5);
  static const red500     = Color(0xFFEF4444);
  static const red50      = Color(0xFFFEF2F2);
  static const amber500   = Color(0xFFF59E0B);
  static const amber50    = Color(0xFFFFFBEB);
  static const blue500    = Color(0xFF3B82F6);
  static const purple500  = Color(0xFF8B5CF6);

  // Backgrounds
  static const bgAdmin  = Color(0xFFEEF2FF);
  static const bgClient = Color(0xFFF8FAFC);
}

class AppTheme {
  static ThemeData get lightTheme => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.primary,
      primary: AppColors.primary,
      secondary: AppColors.secondary,
      surface: AppColors.white,
      error: AppColors.red500,
    ),
    scaffoldBackgroundColor: AppColors.white,
    fontFamily: 'Outfit',
    textTheme: _textTheme,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.white,
      elevation: 0,
      scrolledUnderElevation: 0,
      iconTheme: IconThemeData(color: AppColors.slate900),
      titleTextStyle: TextStyle(
        fontFamily: 'Outfit',
        fontSize: 18,
        fontWeight: FontWeight.w800,
        color: AppColors.slate900,
        letterSpacing: -0.5,
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.white,
        elevation: 0,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        textStyle: const TextStyle(
          fontFamily: 'Outfit',
          fontSize: 14,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.5,
        ),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.slate100,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.primary, width: 2),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
    ),
    cardTheme: CardThemeData(
      color: AppColors.white,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: Color(0xFFF1F5F9)),
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: AppColors.slate100,
      selectedColor: AppColors.primaryLight,
      labelStyle: const TextStyle(
        fontFamily: 'Outfit',
        fontWeight: FontWeight.w700,
        fontSize: 12,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(100),
      ),
    ),
  );

  static TextTheme get _textTheme => const TextTheme(
    displayLarge: TextStyle(
      fontSize: 56, fontWeight: FontWeight.w900,
      color: AppColors.slate900, letterSpacing: -2, height: 0.95,
    ),
    displayMedium: TextStyle(
      fontSize: 40, fontWeight: FontWeight.w900,
      color: AppColors.slate900, letterSpacing: -1.5,
    ),
    displaySmall: TextStyle(
      fontSize: 32, fontWeight: FontWeight.w800,
      color: AppColors.slate900, letterSpacing: -1,
    ),
    headlineLarge: TextStyle(
      fontSize: 28, fontWeight: FontWeight.w800,
      color: AppColors.slate900, letterSpacing: -0.5,
    ),
    headlineMedium: TextStyle(
      fontSize: 22, fontWeight: FontWeight.w800,
      color: AppColors.slate900,
    ),
    headlineSmall: TextStyle(
      fontSize: 18, fontWeight: FontWeight.w700,
      color: AppColors.slate900,
    ),
    titleLarge: TextStyle(
      fontSize: 16, fontWeight: FontWeight.w700,
      color: AppColors.slate900,
    ),
    titleMedium: TextStyle(
      fontSize: 14, fontWeight: FontWeight.w700,
      color: AppColors.slate700,
    ),
    titleSmall: TextStyle(
      fontSize: 12, fontWeight: FontWeight.w700,
      color: AppColors.slate500,
      letterSpacing: 1.2,
    ),
    bodyLarge: TextStyle(
      fontSize: 16, fontWeight: FontWeight.w500,
      color: AppColors.slate700,
    ),
    bodyMedium: TextStyle(
      fontSize: 14, fontWeight: FontWeight.w500,
      color: AppColors.slate500,
    ),
    bodySmall: TextStyle(
      fontSize: 12, fontWeight: FontWeight.w500,
      color: AppColors.slate400,
    ),
    labelLarge: TextStyle(
      fontSize: 11, fontWeight: FontWeight.w900,
      color: AppColors.slate500, letterSpacing: 2,
    ),
  );
}
