import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../app/theme/app_theme.dart';
import '../core/models/app_models.dart';
import '../app/routes/app_routes.dart';

// ─── APP BUTTON ───────────────────────────────────────────────────────────────
class AppButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool isLoading;
  final bool isOutlined;
  final bool isSmall;
  final Color? color;
  final IconData? icon;
  final double? width;

  const AppButton({
    super.key,
    required this.label,
    this.onTap,
    this.isLoading = false,
    this.isOutlined = false,
    this.isSmall = false,
    this.color,
    this.icon,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    final bg = color ?? AppColors.primary;
    return SizedBox(
      width: width,
      height: isSmall ? 42 : 56,
      child: isOutlined
          ? OutlinedButton(
              onPressed: isLoading ? null : onTap,
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: bg, width: 2),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(isSmall ? 12 : 16)),
                foregroundColor: bg,
              ),
              child: _child(bg),
            )
          : ElevatedButton(
              onPressed: isLoading ? null : onTap,
              style: ElevatedButton.styleFrom(
                backgroundColor: bg,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(isSmall ? 12 : 16)),
              ),
              child: _child(Colors.white),
            ),
    );
  }

  Widget _child(Color fg) {
    if (isLoading) {
      return SizedBox(
        width: 22, height: 22,
        child: CircularProgressIndicator(strokeWidth: 2.5,
            valueColor: AlwaysStoppedAnimation(fg)),
      );
    }
    if (icon != null) {
      return Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: isSmall ? 16 : 20),
        const SizedBox(width: 8),
        Text(label, style: TextStyle(
          fontFamily: 'Outfit', fontWeight: FontWeight.w900,
          fontSize: isSmall ? 12 : 14, letterSpacing: 1.2, color: fg,
        )),
      ]);
    }
    return Text(label.toUpperCase(), style: TextStyle(
      fontFamily: 'Outfit', fontWeight: FontWeight.w900,
      fontSize: isSmall ? 12 : 14, letterSpacing: 1.5, color: fg,
    ));
  }
}

// ─── APP TEXT FIELD ───────────────────────────────────────────────────────────
class AppTextField extends StatelessWidget {
  final String label;
  final String? hint;
  final IconData? prefixIcon;
  final IconData? suffixIcon;
  final VoidCallback? onSuffixTap;
  final bool obscureText;
  final TextEditingController? controller;
  final TextInputType? keyboardType;
  final String? Function(String?)? validator;
  final ValueChanged<String>? onChanged;
  final int maxLines;

  const AppTextField({
    super.key,
    required this.label,
    this.hint,
    this.prefixIcon,
    this.suffixIcon,
    this.onSuffixTap,
    this.obscureText = false,
    this.controller,
    this.keyboardType,
    this.validator,
    this.onChanged,
    this.maxLines = 1,
  });

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label.toUpperCase(), style: const TextStyle(
        fontSize: 11, fontWeight: FontWeight.w900,
        color: AppColors.slate500, letterSpacing: 1.5,
      )),
      const SizedBox(height: 8),
      TextFormField(
        controller: controller,
        obscureText: obscureText,
        keyboardType: keyboardType,
        validator: validator,
        onChanged: onChanged,
        maxLines: maxLines,
        style: const TextStyle(
          fontFamily: 'Outfit', fontWeight: FontWeight.w600,
          fontSize: 15, color: AppColors.slate900,
        ),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: AppColors.slate300, fontWeight: FontWeight.w500),
          prefixIcon: prefixIcon != null
              ? Icon(prefixIcon, color: AppColors.slate400, size: 22)
              : null,
          suffixIcon: suffixIcon != null
              ? GestureDetector(
                  onTap: onSuffixTap,
                  child: Icon(suffixIcon, color: AppColors.slate400, size: 22),
                )
              : null,
        ),
      ),
    ]);
  }
}

// ─── STATUS BADGE ─────────────────────────────────────────────────────────────
class StatusBadge extends StatelessWidget {
  final String status;
  const StatusBadge({super.key, required this.status});

  @override
  Widget build(BuildContext context) {
    Color bg; Color fg; String label;
    switch (status.toLowerCase()) {
      case 'confirmed': case 'accepté': case 'accepted': case 'active':
        bg = AppColors.emerald50; fg = AppColors.emerald500; label = status; break;
      case 'pending': case 'en attente':
        bg = AppColors.amber50; fg = AppColors.amber500; label = status; break;
      case 'completed': case 'terminé':
        bg = const Color(0xFFEFF6FF); fg = AppColors.blue500; label = status; break;
      case 'cancelled': case 'annulé': case 'refused':
        bg = AppColors.red50; fg = AppColors.red500; label = status; break;
      default:
        bg = AppColors.slate100; fg = AppColors.slate500; label = status;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(100)),
      child: Text(label.toUpperCase(), style: TextStyle(
        fontSize: 10, fontWeight: FontWeight.w900,
        color: fg, letterSpacing: 1.2,
      )),
    );
  }
}

// ─── ARTISAN CARD ─────────────────────────────────────────────────────────────
class ArtisanCard extends StatelessWidget {
  final ArtisanModel artisan;
  final bool compact;

  const ArtisanCard({super.key, required this.artisan, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Get.toNamed(AppRoutes.ARTISAN_PROFILE,
          parameters: {'id': artisan.id.toString()}),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.slate100),
          boxShadow: [BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 20, offset: const Offset(0, 8),
          )],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            // Avatar
            Container(
              width: 60, height: 60,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppColors.primary, Color(0xFF0066CC)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(18),
              ),
              alignment: Alignment.center,
              child: Text(artisan.initials, style: const TextStyle(
                color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900,
              )),
            ),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(artisan.name, style: const TextStyle(
                  fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.slate900,
                ))),
                if (artisan.isVerified)
                  const Icon(Icons.verified_rounded, color: AppColors.primary, size: 18),
              ]),
              const SizedBox(height: 4),
              Text(artisan.specialty, style: const TextStyle(
                fontSize: 13, color: AppColors.primary, fontWeight: FontWeight.w700,
              )),
              const SizedBox(height: 4),
              Row(children: [
                const Icon(Icons.location_on, size: 13, color: AppColors.slate400),
                const SizedBox(width: 3),
                Text(artisan.city, style: const TextStyle(
                  fontSize: 12, color: AppColors.slate400, fontWeight: FontWeight.w600,
                )),
                const SizedBox(width: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: artisan.isAvailable ? AppColors.emerald50 : AppColors.red50,
                    borderRadius: BorderRadius.circular(100),
                  ),
                  child: Text(
                    artisan.isAvailable ? 'Disponible' : 'Indisponible',
                    style: TextStyle(
                      fontSize: 10, fontWeight: FontWeight.w800,
                      color: artisan.isAvailable ? AppColors.emerald500 : AppColors.red500,
                    ),
                  ),
                ),
              ]),
            ])),
          ]),
          if (!compact) ...[
            const SizedBox(height: 16),
            const Divider(color: AppColors.slate100, height: 1),
            const SizedBox(height: 16),
            Row(children: [
              _stat('★ ${artisan.rating}', '${artisan.reviewCount} avis'),
              _divider(),
              _stat('${artisan.yearsExperience}', 'ans exp.'),
              _divider(),
              _stat('${artisan.projectsDone}', 'projets'),
              const Spacer(),
              if (artisan.hourlyRate != null)
                Text('${artisan.hourlyRate!.toInt()} DA/h',
                    style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w900, color: AppColors.secondary,
                    )),
            ]),
          ],
        ]),
      ),
    );
  }

  Widget _stat(String value, String label) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(value, style: const TextStyle(
        fontSize: 14, fontWeight: FontWeight.w900, color: AppColors.slate900,
      )),
      Text(label, style: const TextStyle(
        fontSize: 11, color: AppColors.slate400, fontWeight: FontWeight.w600,
      )),
    ],
  );

  Widget _divider() => Container(
    margin: const EdgeInsets.symmetric(horizontal: 14),
    width: 1, height: 28, color: AppColors.slate100,
  );
}

// ─── SECTION TITLE ────────────────────────────────────────────────────────────
class SectionTitle extends StatelessWidget {
  final String title;
  final String? action;
  final VoidCallback? onAction;

  const SectionTitle({super.key, required this.title, this.action, this.onAction});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(child: Text(title, style: const TextStyle(
        fontSize: 22, fontWeight: FontWeight.w900,
        color: AppColors.slate900, letterSpacing: -0.5,
      ))),
      if (action != null)
        GestureDetector(
          onTap: onAction,
          child: Text(action!, style: const TextStyle(
            fontSize: 13, fontWeight: FontWeight.w800,
            color: AppColors.primary,
          )),
        ),
    ]);
  }
}

// ─── STAT CARD ────────────────────────────────────────────────────────────────
class StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;
  final String? subtitle;

  const StatCard({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
    this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.slate100),
        boxShadow: [BoxShadow(
          color: color.withOpacity(0.08),
          blurRadius: 20, offset: const Offset(0, 8),
        )],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          if (subtitle != null)
            Text(subtitle!, style: TextStyle(
              fontSize: 11, fontWeight: FontWeight.w700,
              color: color,
            )),
        ]),
        const SizedBox(height: 14),
        Text(value, style: const TextStyle(
          fontSize: 26, fontWeight: FontWeight.w900, color: AppColors.slate900,
        )),
        const SizedBox(height: 4),
        Text(title, style: const TextStyle(
          fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.slate400,
        )),
      ]),
    );
  }
}

// ─── AVATAR CIRCLE ────────────────────────────────────────────────────────────
class AvatarCircle extends StatelessWidget {
  final String initials;
  final double size;
  final Color? color;
  final String? imageUrl;

  const AvatarCircle({
    super.key,
    required this.initials,
    this.size = 44,
    this.color,
    this.imageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color ?? AppColors.primary, (color ?? AppColors.primary).withOpacity(0.7)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(size * 0.32),
      ),
      alignment: Alignment.center,
      child: Text(initials, style: TextStyle(
        color: Colors.white, fontSize: size * 0.36,
        fontWeight: FontWeight.w900,
      )),
    );
  }
}

// ─── LOADING SKELETON ─────────────────────────────────────────────────────────
class SkeletonBox extends StatelessWidget {
  final double width;
  final double height;
  final double radius;

  const SkeletonBox({
    super.key,
    required this.width,
    required this.height,
    this.radius = 12,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width, height: height,
      decoration: BoxDecoration(
        color: AppColors.slate100,
        borderRadius: BorderRadius.circular(radius),
      ),
    );
  }
}

// ─── EMPTY STATE ─────────────────────────────────────────────────────────────
class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final String? actionLabel;
  final VoidCallback? onAction;

  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    this.actionLabel,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.primaryLight,
              shape: BoxShape.circle,
            ),
            child: Icon(icon, size: 48, color: AppColors.primary),
          ),
          const SizedBox(height: 24),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(
            fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.slate900,
          )),
          if (subtitle != null) ...[
            const SizedBox(height: 8),
            Text(subtitle!, textAlign: TextAlign.center, style: const TextStyle(
              fontSize: 14, color: AppColors.slate400,
            )),
          ],
          if (actionLabel != null && onAction != null) ...[
            const SizedBox(height: 24),
            AppButton(label: actionLabel!, onTap: onAction),
          ],
        ]),
      ),
    );
  }
}
