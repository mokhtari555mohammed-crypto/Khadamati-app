import 'package:get/get.dart';
import '../../../core/models/app_models.dart';
import '../../../core/services/storage_service.dart';

class HomeController extends GetxController {
  final categories = <CategoryModel>[].obs;
  final artisans = <ArtisanModel>[].obs;
  final searchTerm = ''.obs;
  final locationTerm = ''.obs;
  final isMenuOpen = false.obs;

  @override
  void onInit() {
    super.onInit();
    _loadData();
  }

  void _loadData() {
    categories.assignAll(MockData.categories);
    artisans.assignAll(MockData.artisans.take(4).toList());
  }

  void toggleMenu() => isMenuOpen.toggle();

  void switchLanguage() {
    final current = Get.locale?.languageCode ?? 'fr';
    final next = current == 'fr' ? 'ar' : 'fr';
    Get.updateLocale(next == 'ar' ? const Locale('ar', 'AR') : const Locale('fr', 'FR'));
    StorageService.setLocale(next);
  }
}
