import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/theme/app_theme.dart';
import '../../../app/routes/app_routes.dart';
import '../../../shared/widgets/app_widgets.dart';

class AboutView extends StatelessWidget {
  const AboutView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('À propos de nous'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          // Hero
          Container(
            padding: const EdgeInsets.all(24),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.primary, Color(0xFF0066CC)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Notre Mission', style: TextStyle(
                color: Colors.white, fontSize: 28,
                fontWeight: FontWeight.w900, letterSpacing: -0.5,
              )),
              const SizedBox(height: 12),
              Text(
                'Connecter les clients avec des artisans qualifiés et vérifiés, pour faciliter la réalisation de tous vos projets.',
                style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 14, height: 1.7),
              ),
            ]),
          ),
          // Content
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _section('Notre histoire', Icons.auto_stories_rounded, AppColors.primary,
                  'Fondée en 2024, Khadamati est née d\'un constat simple : il est difficile de trouver un artisan de confiance. Notre plateforme change cela en mettant en relation clients et professionnels vérifiés.'),
              _section('Nos valeurs', Icons.favorite_rounded, AppColors.secondary,
                  'Confiance, transparence et qualité. Chaque artisan est vérifié manuellement. Chaque avis est authentique. Chaque paiement est sécurisé.'),
              _section('Notre équipe', Icons.groups_rounded, AppColors.emerald500,
                  'Une équipe passionnée de professionnels du digital et de l\'artisanat, engagée à révolutionner le secteur des services à domicile.'),
              const SizedBox(height: 8),
              // Stats
              Row(children: [
                Expanded(child: _statBox('2 500+', 'Artisans')),
                const SizedBox(width: 12),
                Expanded(child: _statBox('15K+', 'Projets')),
                const SizedBox(width: 12),
                Expanded(child: _statBox('12', 'Wilayas')),
              ]),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _section(String title, IconData icon, Color color, String text) => Container(
    margin: const EdgeInsets.only(bottom: 20),
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: AppColors.slate100),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: color, size: 20),
        ),
        const SizedBox(width: 12),
        Text(title, style: const TextStyle(
          fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.slate900,
        )),
      ]),
      const SizedBox(height: 12),
      Text(text, style: const TextStyle(
        fontSize: 13, color: AppColors.slate500, height: 1.7,
      )),
    ]),
  );

  Widget _statBox(String value, String label) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      gradient: const LinearGradient(
        colors: [AppColors.primary, Color(0xFF0066CC)],
        begin: Alignment.topLeft, end: Alignment.bottomRight,
      ),
      borderRadius: BorderRadius.circular(16),
    ),
    child: Column(children: [
      Text(value, style: const TextStyle(
        fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white,
      )),
      Text(label, style: TextStyle(
        fontSize: 11, color: Colors.white.withOpacity(0.7), fontWeight: FontWeight.w600,
      )),
    ]),
  );
}
