import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/theme/app_theme.dart';
import '../../../app/routes/app_routes.dart';
import '../../../core/models/app_models.dart';
import '../../../shared/widgets/app_widgets.dart';
import '../controllers/home_controller.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: CustomScrollView(
        slivers: [
          _buildAppBar(),
          SliverToBoxAdapter(child: _buildHero()),
          SliverToBoxAdapter(child: _buildStats()),
          SliverToBoxAdapter(child: _buildCategories()),
          SliverToBoxAdapter(child: _buildHowItWorks()),
          SliverToBoxAdapter(child: _buildTopArtisans()),
          SliverToBoxAdapter(child: _buildWhyUs()),
          SliverToBoxAdapter(child: _buildTestimonials()),
          SliverToBoxAdapter(child: _buildCTA()),
          SliverToBoxAdapter(child: _buildFooter()),
        ],
      ),
    );
  }

  // ── APP BAR ──────────────────────────────────────────────────────────────
  SliverAppBar _buildAppBar() => SliverAppBar(
    floating: true,
    snap: true,
    backgroundColor: Colors.white,
    elevation: 0,
    scrolledUnderElevation: 1,
    shadowColor: AppColors.slate100,
    titleSpacing: 20,
    title: Row(children: [
      Container(
        width: 36, height: 36,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppColors.primary, Color(0xFF0066CC)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(10),
        ),
        alignment: Alignment.center,
        child: const Text('K', style: TextStyle(
          color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900,
        )),
      ),
      const SizedBox(width: 10),
      const Text('KHADAMATI', style: TextStyle(
        fontSize: 16, fontWeight: FontWeight.w900,
        color: AppColors.primary, letterSpacing: 2,
      )),
    ]),
    actions: [
      // Language toggle
      GestureDetector(
        onTap: () => Get.find<HomeController>().switchLanguage(),
        child: Container(
          margin: const EdgeInsets.only(right: 8),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            border: Border.all(color: AppColors.slate200 ?? AppColors.slate300),
            borderRadius: BorderRadius.circular(100),
          ),
          child: Obx(() => Text(
            Get.locale?.languageCode == 'ar' ? 'FR' : 'AR',
            style: const TextStyle(
              fontSize: 12, fontWeight: FontWeight.w800,
              color: AppColors.slate700,
            ),
          )),
        ),
      ),
      // Login button
      Padding(
        padding: const EdgeInsets.only(right: 8),
        child: TextButton(
          onPressed: () => Get.toNamed(AppRoutes.CLIENT_LOGIN),
          child: const Text('Connexion', style: TextStyle(
            fontWeight: FontWeight.w700, color: AppColors.primary,
          )),
        ),
      ),
      Padding(
        padding: const EdgeInsets.only(right: 16),
        child: AppButton(
          label: 'Inscription', isSmall: true,
          onTap: () => Get.toNamed(AppRoutes.CLIENT_REGISTER),
        ),
      ),
    ],
  );

  // ── HERO ─────────────────────────────────────────────────────────────────
  Widget _buildHero() {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 40, 24, 48),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFFEEF4FF), Color(0xFFF8FAFC)],
          begin: Alignment.topCenter, end: Alignment.bottomCenter,
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Badge
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
          decoration: BoxDecoration(
            color: AppColors.primaryLight,
            borderRadius: BorderRadius.circular(100),
            border: Border.all(color: AppColors.primary.withOpacity(0.2)),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 8, height: 8,
              decoration: const BoxDecoration(
                color: AppColors.emerald500, shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 8),
            const Text('2 500+ Artisans Vérifiés', style: TextStyle(
              fontSize: 12, fontWeight: FontWeight.w800,
              color: AppColors.primary, letterSpacing: 0.5,
            )),
          ]),
        ),
        const SizedBox(height: 20),

        // Big headline
        RichText(
          text: const TextSpan(
            style: TextStyle(fontFamily: 'Outfit'),
            children: [
              TextSpan(text: 'Trouvez\n', style: TextStyle(
                fontSize: 46, fontWeight: FontWeight.w900,
                color: AppColors.slate900, height: 1.0,
              )),
              TextSpan(text: 'l\'artisan ', style: TextStyle(
                fontSize: 46, fontWeight: FontWeight.w900,
                color: AppColors.primary, height: 1.0,
              )),
              TextSpan(text: 'idéal\npour vous', style: TextStyle(
                fontSize: 46, fontWeight: FontWeight.w900,
                color: AppColors.slate900, height: 1.0,
              )),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const Text(
          'Des experts qualifiés et vérifiés à votre service pour tous vos besoins de rénovation, réparation et entretien.',
          style: TextStyle(
            fontSize: 15, color: AppColors.slate500,
            height: 1.7, fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 32),

        // Search card
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [BoxShadow(
              color: AppColors.primary.withOpacity(0.1),
              blurRadius: 40, offset: const Offset(0, 16),
            )],
          ),
          child: Column(children: [
            TextField(
              decoration: InputDecoration(
                hintText: 'Peinture, Électricité...',
                hintStyle: const TextStyle(color: AppColors.slate300),
                prefixIcon: const Icon(Icons.search_rounded, color: AppColors.primary),
                filled: true, fillColor: AppColors.slate50,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none,
                ),
              ),
              onChanged: (v) => controller.searchTerm.value = v,
            ),
            const SizedBox(height: 12),
            TextField(
              decoration: InputDecoration(
                hintText: 'Votre ville',
                hintStyle: const TextStyle(color: AppColors.slate300),
                prefixIcon: const Icon(Icons.location_on_outlined, color: AppColors.slate400),
                filled: true, fillColor: AppColors.slate50,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none,
                ),
              ),
              onChanged: (v) => controller.locationTerm.value = v,
            ),
            const SizedBox(height: 16),
            AppButton(
              label: 'Rechercher',
              onTap: () => Get.toNamed(AppRoutes.FIND_EXPERT),
              width: double.infinity,
              icon: Icons.search_rounded,
            ),
          ]),
        ),
      ]),
    );
  }

  // ── STATS ─────────────────────────────────────────────────────────────────
  Widget _buildStats() => Container(
    padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 24),
    child: Row(children: [
      _statItem('2 500+', 'Artisans\nVérifiés', Icons.verified_rounded, AppColors.primary),
      _statDivider(),
      _statItem('15 000+', 'Projets\nRéalisés', Icons.check_circle_outline_rounded, AppColors.emerald500),
      _statDivider(),
      _statItem('4.8/5', 'Note\nMoyenne', Icons.star_rounded, AppColors.secondary),
    ]),
  );

  Widget _statItem(String value, String label, IconData icon, Color color) => Expanded(
    child: Column(children: [
      Icon(icon, color: color, size: 28),
      const SizedBox(height: 8),
      Text(value, style: const TextStyle(
        fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.slate900,
      )),
      const SizedBox(height: 4),
      Text(label, textAlign: TextAlign.center, style: const TextStyle(
        fontSize: 11, color: AppColors.slate400, fontWeight: FontWeight.w600,
      )),
    ]),
  );

  Widget _statDivider() => Container(
    height: 48, width: 1, color: AppColors.slate100,
    margin: const EdgeInsets.symmetric(horizontal: 16),
  );

  // ── CATEGORIES ────────────────────────────────────────────────────────────
  Widget _buildCategories() => Padding(
    padding: const EdgeInsets.fromLTRB(24, 16, 24, 40),
    child: Column(children: [
      SectionTitle(
        title: 'popular_services'.tr,
        action: 'Voir tout',
        onAction: () => Get.toNamed(AppRoutes.FIND_EXPERT),
      ),
      const SizedBox(height: 20),
      GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          childAspectRatio: 0.95,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
        ),
        itemCount: 9,
        itemBuilder: (_, i) => _CategoryCard(category: MockData.categories[i]),
      ),
    ]),
  );

  // ── HOW IT WORKS ──────────────────────────────────────────────────────────
  Widget _buildHowItWorks() => Container(
    padding: const EdgeInsets.all(24),
    color: AppColors.slate50,
    child: Column(children: [
      const Text('Comment ça marche ?', style: TextStyle(
        fontSize: 26, fontWeight: FontWeight.w900, color: AppColors.slate900,
        letterSpacing: -0.5,
      )),
      const SizedBox(height: 8),
      const Text('Simple, rapide et sécurisé', style: TextStyle(
        fontSize: 14, color: AppColors.slate400,
      )),
      const SizedBox(height: 28),
      _buildStep(1, 'Décrivez votre projet',
          'Expliquez vos besoins, obtenez des devis gratuits.',
          Icons.edit_note_rounded, AppColors.primary),
      _buildStep(2, 'Choisissez votre artisan',
          'Comparez profils, avis et tarifs.',
          Icons.person_search_rounded, AppColors.secondary),
      _buildStep(3, 'Projet réalisé',
          'Validez le travail. Simple et sécurisé.',
          Icons.check_circle_rounded, AppColors.emerald500),
    ]),
  );

  Widget _buildStep(int n, String title, String desc, IconData icon, Color color) => Container(
    margin: const EdgeInsets.only(bottom: 16),
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: AppColors.slate100),
    ),
    child: Row(children: [
      Container(
        width: 48, height: 48,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(14),
        ),
        alignment: Alignment.center,
        child: Icon(icon, color: color, size: 26),
      ),
      const SizedBox(width: 16),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 22, height: 22,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
            alignment: Alignment.center,
            child: Text('$n', style: const TextStyle(
              color: Colors.white, fontSize: 11, fontWeight: FontWeight.w900,
            )),
          ),
          const SizedBox(width: 10),
          Text(title, style: const TextStyle(
            fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.slate900,
          )),
        ]),
        const SizedBox(height: 6),
        Text(desc, style: const TextStyle(
          fontSize: 13, color: AppColors.slate400, height: 1.5,
        )),
      ])),
    ]),
  );

  // ── TOP ARTISANS ─────────────────────────────────────────────────────────
  Widget _buildTopArtisans() => Padding(
    padding: const EdgeInsets.all(24),
    child: Column(children: [
      SectionTitle(
        title: 'Nos meilleurs artisans',
        action: 'Voir tout',
        onAction: () => Get.toNamed(AppRoutes.FIND_EXPERT),
      ),
      const SizedBox(height: 20),
      Obx(() => Column(
        children: controller.artisans.map((a) => ArtisanCard(artisan: a)).toList(),
      )),
    ]),
  );

  // ── WHY US ────────────────────────────────────────────────────────────────
  Widget _buildWhyUs() => Container(
    padding: const EdgeInsets.all(24),
    color: AppColors.bgAdmin,
    child: Column(children: [
      const Text('Pourquoi nous choisir ?', style: TextStyle(
        fontSize: 26, fontWeight: FontWeight.w900, color: AppColors.slate900,
        letterSpacing: -0.5,
      )),
      const SizedBox(height: 24),
      _whyCard(Icons.verified_user_rounded, 'Artisans Vérifiés',
          'Chaque artisan est vérifié par notre équipe avec contrôle des documents et certifications.',
          AppColors.primary),
      const SizedBox(height: 14),
      _whyCard(Icons.shield_rounded, 'Paiement Sécurisé',
          'Vos paiements sont protégés. L\'argent est libéré uniquement à la validation du travail.',
          AppColors.emerald500),
      const SizedBox(height: 14),
      _whyCard(Icons.star_rounded, 'Avis Authentiques',
          'Tous les avis proviennent de clients ayant réellement utilisé le service.',
          AppColors.secondary),
      const SizedBox(height: 14),
      _whyCard(Icons.support_agent_rounded, 'Support 7j/7',
          'Notre équipe est disponible pour vous accompagner à chaque étape de votre projet.',
          AppColors.purple500),
    ]),
  );

  Widget _whyCard(IconData icon, String title, String desc, Color color) => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      boxShadow: [BoxShadow(
        color: color.withOpacity(0.06),
        blurRadius: 16, offset: const Offset(0, 4),
      )],
    ),
    child: Row(children: [
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Icon(icon, color: color, size: 24),
      ),
      const SizedBox(width: 16),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(
          fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.slate900,
        )),
        const SizedBox(height: 4),
        Text(desc, style: const TextStyle(
          fontSize: 12, color: AppColors.slate400, height: 1.5,
        )),
      ])),
    ]),
  );

  // ── TESTIMONIALS ─────────────────────────────────────────────────────────
  Widget _buildTestimonials() => Padding(
    padding: const EdgeInsets.all(24),
    child: Column(children: [
      const SectionTitle(title: 'Ce que disent nos clients'),
      const SizedBox(height: 20),
      ...MockData.reviews.map((r) => _TestimonialCard(review: r)).toList(),
    ]),
  );

  // ── CTA ───────────────────────────────────────────────────────────────────
  Widget _buildCTA() => Container(
    margin: const EdgeInsets.all(24),
    padding: const EdgeInsets.all(32),
    decoration: BoxDecoration(
      gradient: const LinearGradient(
        colors: [AppColors.primary, Color(0xFF0066CC)],
        begin: Alignment.topLeft, end: Alignment.bottomRight,
      ),
      borderRadius: BorderRadius.circular(28),
    ),
    child: Column(children: [
      const Text('Prêt à commencer ?', style: TextStyle(
        color: Colors.white, fontSize: 24,
        fontWeight: FontWeight.w900, letterSpacing: -0.5,
      )),
      const SizedBox(height: 10),
      Text(
        'Rejoignez des milliers de clients satisfaits et trouvez l\'artisan idéal pour votre projet.',
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 13, height: 1.6),
      ),
      const SizedBox(height: 24),
      Row(children: [
        Expanded(child: AppButton(
          label: 'Trouver un artisan',
          onTap: () => Get.toNamed(AppRoutes.FIND_EXPERT),
          color: Colors.white,
        )),
        const SizedBox(width: 12),
        Expanded(child: AppButton(
          label: 'Devenir artisan',
          onTap: () => Get.toNamed(AppRoutes.ARTISAN_REGISTER),
          isOutlined: true,
          color: Colors.white,
        )),
      ]),
    ]),
  );

  // ── FOOTER ────────────────────────────────────────────────────────────────
  Widget _buildFooter() => Container(
    padding: const EdgeInsets.all(24),
    color: AppColors.slate900,
    child: Column(children: [
      Row(children: [
        Container(
          width: 36, height: 36,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          alignment: Alignment.center,
          child: const Text('K', style: TextStyle(
            color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900,
          )),
        ),
        const SizedBox(width: 10),
        const Text('KHADAMATI', style: TextStyle(
          color: Colors.white, fontSize: 14,
          fontWeight: FontWeight.w900, letterSpacing: 2,
        )),
      ]),
      const SizedBox(height: 12),
      Text('خدماتي  •  L\'expertise à votre portée',
        style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 12)),
      const SizedBox(height: 24),
      Divider(color: Colors.white.withOpacity(0.1)),
      const SizedBox(height: 16),
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        _footerLink('Accueil', () => {}),
        _footerLink('Services', () => Get.toNamed(AppRoutes.FIND_EXPERT)),
        _footerLink('À propos', () => Get.toNamed(AppRoutes.ABOUT_US)),
        _footerLink('Contact', () => {}),
      ]),
      const SizedBox(height: 20),
      Text('© 2024 Khadamati. Tous droits réservés.',
        style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 11)),
    ]),
  );

  Widget _footerLink(String label, VoidCallback onTap) => GestureDetector(
    onTap: onTap,
    child: Text(label, style: TextStyle(
      color: Colors.white.withOpacity(0.6),
      fontSize: 12, fontWeight: FontWeight.w600,
    )),
  );
}

// ── CATEGORY CARD (private) ───────────────────────────────────────────────────
class _CategoryCard extends StatelessWidget {
  final CategoryModel category;
  const _CategoryCard({required this.category});

  static const _icons = [
    Icons.carpenter_rounded, Icons.hardware_rounded,
    Icons.water_rounded, Icons.bolt_rounded,
    Icons.format_paint_rounded, Icons.construction_rounded,
    Icons.build_rounded, Icons.cut_rounded,
    Icons.grid_on_rounded, Icons.bakery_dining_rounded,
    Icons.yard_rounded, Icons.local_shipping_rounded,
  ];

  static const _colors = [
    AppColors.primary, Color(0xFF6366F1), AppColors.blue500,
    AppColors.secondary, AppColors.emerald500, Color(0xFF8B5CF6),
    Color(0xFFEC4899), AppColors.amber500, Color(0xFF14B8A6),
    Color(0xFFEF4444), Color(0xFF22C55E), Color(0xFF3B82F6),
  ];

  @override
  Widget build(BuildContext context) {
    final idx = (category.id - 1).clamp(0, 11);
    final color = _colors[idx];
    final icon = _icons[idx];

    return GestureDetector(
      onTap: () => Get.toNamed(AppRoutes.FIND_EXPERT,
          parameters: {'category': category.name}),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.slate100),
          boxShadow: [BoxShadow(
            color: color.withOpacity(0.06),
            blurRadius: 12, offset: const Offset(0, 4),
          )],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(height: 8),
            Text(
              category.name.split(' ').take(2).join(' '),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 10, fontWeight: FontWeight.w800,
                color: AppColors.slate700, height: 1.3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── TESTIMONIAL CARD (private) ────────────────────────────────────────────────
class _TestimonialCard extends StatelessWidget {
  final dynamic review;
  const _TestimonialCard({required this.review});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.slate100),
        boxShadow: [BoxShadow(
          color: Colors.black.withOpacity(0.04),
          blurRadius: 16, offset: const Offset(0, 4),
        )],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.primary, Color(0xFF0066CC)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            alignment: Alignment.center,
            child: Text(
              review.clientName[0].toUpperCase(),
              style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(review.clientName, style: const TextStyle(
              fontWeight: FontWeight.w800, color: AppColors.slate900,
            )),
            Row(children: List.generate(5, (i) => Icon(
              i < review.rating.round() ? Icons.star_rounded : Icons.star_outline_rounded,
              color: AppColors.secondary, size: 14,
            ))),
          ])),
          const Icon(Icons.format_quote_rounded, color: AppColors.primaryLight, size: 32),
        ]),
        const SizedBox(height: 14),
        Text(review.comment, style: const TextStyle(
          fontSize: 13, color: AppColors.slate500, height: 1.6,
        )),
      ]),
    );
  }
}
