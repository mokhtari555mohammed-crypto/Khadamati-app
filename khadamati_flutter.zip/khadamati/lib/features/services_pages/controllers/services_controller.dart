import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/routes/app_routes.dart';

class ServicesController extends GetxController {
  final isLoading = false.obs;
  final descCtrl = TextEditingController();
  final addressCtrl = TextEditingController();
  final budgetCtrl = TextEditingController();
  final selectedDate = Rxn<DateTime>();
  final formKey = GlobalKey<FormState>();

  void pickDate(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 1)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 90)),
      builder: (ctx, child) => Theme(
        data: ThemeData.light().copyWith(
          colorScheme: const ColorScheme.light(primary: Color(0xFF004C96)),
        ),
        child: child!,
      ),
    );
    if (picked != null) selectedDate.value = picked;
  }

  Future<void> submitQuote() async {
    if (!formKey.currentState!.validate()) return;
    isLoading.value = true;
    await Future.delayed(const Duration(seconds: 1));
    isLoading.value = false;
    Get.offNamed(AppRoutes.MESSAGE_SUCCESS);
  }

  Future<void> submitBooking() async {
    if (!formKey.currentState!.validate()) return;
    isLoading.value = true;
    await Future.delayed(const Duration(seconds: 1));
    isLoading.value = false;
    Get.offNamed(AppRoutes.MESSAGE_SUCCESS, arguments: {'type': 'booking'});
  }

  @override
  void onClose() {
    descCtrl.dispose();
    addressCtrl.dispose();
    budgetCtrl.dispose();
    super.onClose();
  }
}
