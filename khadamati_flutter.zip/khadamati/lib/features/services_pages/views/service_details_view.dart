import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../../app/theme/app_theme.dart';
import '../../../app/routes/app_routes.dart';
import '../../../shared/widgets/app_widgets.dart';
import '../controllers/services_controller.dart';

// ─── SERVICE DETAILS VIEW ─────────────────────────────────────────────────────
class ServiceDetailsView extends GetView<ServicesController> {
  const ServiceDetailsView({super.key});

  static const _pricingPlans = [
    {'name': 'Basique', 'price': '2 500 DA', 'desc': 'Intervention simple jusqu\'à 2h', 'features': ['Diagnostic', 'Devis gratuit']},
    {'name': 'Standard', 'price': '5 000 DA', 'desc': 'Intervention complète jusqu\'à 4h', 'features': ['Diagnostic', 'Pièces incluses', 'Garantie 3 mois']},
    {'name': 'Premium', 'price': '9 000 DA', 'desc': 'Rénovation complète', 'features': ['Tout inclus', 'Garantie 1 an', 'Suivi prioritaire']},
  ];

  @override
  Widget build(BuildContext context) {
    final serviceName = Get.parameters['id'] ?? 'Service';
    return Scaffold(
      appBar: AppBar(
        title: Text(serviceName),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Hero image
          Container(
            height: 200,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.primary, Color(0xFF0066CC)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
            ),
            alignment: Alignment.center,
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.handyman_rounded, color: Colors.white, size: 64),
              const SizedBox(height: 12),
              Text(serviceName, style: const TextStyle(
                color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900,
              )),
            ]),
          ),

          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Description', style: TextStyle(
                fontSize: 18, fontWeight: FontWeight.w900, color: AppColors.slate900,
              )),
              const SizedBox(height: 10),
              const Text(
                'Nos artisans spécialisés interviennent rapidement pour tous vos besoins. Chaque professionnel est vérifié, certifié et évalué par nos clients.',
                style: TextStyle(fontSize: 14, color: AppColors.slate500, height: 1.7),
              ),
              const SizedBox(height: 24),

              const Text('Formules disponibles', style: TextStyle(
                fontSize: 18, fontWeight: FontWeight.w900, color: AppColors.slate900,
              )),
              const SizedBox(height: 16),
              ..._pricingPlans.asMap().entries.map((e) => _PlanCard(
                plan: e.value, isPopular: e.key == 1,
              )).toList(),

              const SizedBox(height: 24),
              AppButton(
                label: 'Demander un devis gratuit',
                onTap: () => Get.toNamed(AppRoutes.REQUEST_QUOTE),
                width: double.infinity,
                icon: Icons.request_quote_rounded,
              ),
              const SizedBox(height: 12),
              AppButton(
                label: 'Trouver un artisan',
                onTap: () => Get.toNamed(AppRoutes.FIND_EXPERT),
                width: double.infinity,
                isOutlined: true,
                icon: Icons.search_rounded,
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  final Map<String, dynamic> plan;
  final bool isPopular;
  const _PlanCard({required this.plan, this.isPopular = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: isPopular ? AppColors.primary : Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isPopular ? AppColors.primary : AppColors.slate100,
          width: isPopular ? 2 : 1,
        ),
        boxShadow: isPopular ? [BoxShadow(
          color: AppColors.primary.withOpacity(0.2),
          blurRadius: 20, offset: const Offset(0, 8),
        )] : [],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text(plan['name']!, style: TextStyle(
            fontSize: 16, fontWeight: FontWeight.w900,
            color: isPopular ? Colors.white : AppColors.slate900,
          )),
          const Spacer(),
          if (isPopular) Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.secondary,
              borderRadius: BorderRadius.circular(100),
            ),
            child: const Text('POPULAIRE', style: TextStyle(
              fontSize: 9, fontWeight: FontWeight.w900, color: Colors.white,
            )),
          ),
          Text(plan['price']!, style: TextStyle(
            fontSize: 18, fontWeight: FontWeight.w900,
            color: isPopular ? Colors.white : AppColors.secondary,
          )),
        ]),
        const SizedBox(height: 4),
        Text(plan['desc']!, style: TextStyle(
          fontSize: 12,
          color: isPopular ? Colors.white.withOpacity(0.7) : AppColors.slate400,
        )),
        const SizedBox(height: 12),
        ...(plan['features'] as List<String>).map((f) => Row(children: [
          Icon(Icons.check_circle_rounded,
              size: 14, color: isPopular ? Colors.white : AppColors.emerald500),
          const SizedBox(width: 6),
          Text(f, style: TextStyle(
            fontSize: 12, fontWeight: FontWeight.w600,
            color: isPopular ? Colors.white.withOpacity(0.9) : AppColors.slate600,
          )),
        ])).toList(),
      ]),
    );
  }
}

// ─── REQUEST QUOTE VIEW ───────────────────────────────────────────────────────
class RequestQuoteView extends GetView<ServicesController> {
  const RequestQuoteView({super.key});

  @override
  Widget build(BuildContext context) {
    final artisanName = Get.parameters['artisanName'];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Demander un devis'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded), onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: controller.formKey,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (artisanName != null) Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.primaryLight,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(children: [
                const Icon(Icons.person_pin_rounded, color: AppColors.primary),
                const SizedBox(width: 10),
                Text('Demande pour : $artisanName',
                    style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary)),
              ]),
            ),
            const SizedBox(height: 20),

            AppTextField(
              label: 'Description du projet',
              hint: 'Décrivez votre besoin en détail...',
              controller: controller.descCtrl,
              maxLines: 4,
              validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
            ),
            const SizedBox(height: 20),
            AppTextField(
              label: 'Adresse d\'intervention',
              hint: 'Rue, Quartier, Ville',
              prefixIcon: Icons.location_on_outlined,
              controller: controller.addressCtrl,
              validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
            ),
            const SizedBox(height: 20),
            AppTextField(
              label: 'Budget estimé (DA)',
              hint: 'Votre budget en DA',
              prefixIcon: Icons.payments_outlined,
              controller: controller.budgetCtrl,
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 20),

            // Date picker
            const Text('DATE SOUHAITÉE', style: TextStyle(
              fontSize: 11, fontWeight: FontWeight.w900,
              color: AppColors.slate500, letterSpacing: 1.5,
            )),
            const SizedBox(height: 8),
            Obx(() => GestureDetector(
              onTap: () => controller.pickDate(context),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.slate100,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(children: [
                  const Icon(Icons.calendar_today_rounded, color: AppColors.primary, size: 20),
                  const SizedBox(width: 12),
                  Text(
                    controller.selectedDate.value != null
                        ? DateFormat('dd/MM/yyyy').format(controller.selectedDate.value!)
                        : 'Choisir une date',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: controller.selectedDate.value != null
                          ? AppColors.slate900 : AppColors.slate400,
                    ),
                  ),
                ]),
              ),
            )),
            const SizedBox(height: 32),
            Obx(() => AppButton(
              label: 'Envoyer la demande',
              onTap: controller.submitQuote,
              isLoading: controller.isLoading.value,
              width: double.infinity,
              icon: Icons.send_rounded,
            )),
          ]),
        ),
      ),
    );
  }
}

// ─── SERVICE PRICING VIEW ─────────────────────────────────────────────────────
class ServicePricingView extends GetView<ServicesController> {
  const ServicePricingView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tarification'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded), onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(children: [
          const Text('Nos formules', style: TextStyle(
            fontSize: 26, fontWeight: FontWeight.w900, color: AppColors.slate900,
          )),
          const SizedBox(height: 8),
          const Text('Choisissez la formule qui vous convient',
              style: TextStyle(fontSize: 14, color: AppColors.slate400)),
          const SizedBox(height: 28),
          _PricingCard(
            title: 'Basique', price: 'Gratuit',
            color: AppColors.slate700,
            features: const ['Accès à la plateforme', 'Recherche d\'artisans', '3 devis / mois'],
            isActive: false,
          ),
          const SizedBox(height: 16),
          _PricingCard(
            title: 'Standard', price: '990 DA/mois',
            color: AppColors.primary,
            features: const ['Tout Basique', 'Devis illimités', 'Chat en temps réel', 'Support prioritaire'],
            isActive: true,
          ),
          const SizedBox(height: 16),
          _PricingCard(
            title: 'Premium', price: '1 990 DA/mois',
            color: AppColors.secondary,
            features: const ['Tout Standard', 'Artisans vérifiés prioritaires', 'Garantie travaux', 'Manager dédié'],
            isActive: false,
          ),
        ]),
      ),
    );
  }
}

class _PricingCard extends StatelessWidget {
  final String title, price;
  final Color color;
  final List<String> features;
  final bool isActive;
  const _PricingCard({required this.title, required this.price,
    required this.color, required this.features, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: isActive ? color : Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: isActive ? color : AppColors.slate100, width: 2),
        boxShadow: isActive ? [BoxShadow(
          color: color.withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 10),
        )] : [],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (isActive) Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(100),
          ),
          child: const Text('RECOMMANDÉ', style: TextStyle(
            fontSize: 10, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 1.5,
          )),
        ),
        Text(title, style: TextStyle(
          fontSize: 22, fontWeight: FontWeight.w900,
          color: isActive ? Colors.white : AppColors.slate900,
        )),
        const SizedBox(height: 4),
        Text(price, style: TextStyle(
          fontSize: 18, fontWeight: FontWeight.w900,
          color: isActive ? Colors.white.withOpacity(0.9) : color,
        )),
        const SizedBox(height: 16),
        ...features.map((f) => Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(children: [
            Icon(Icons.check_circle_rounded,
                size: 16, color: isActive ? Colors.white : color),
            const SizedBox(width: 8),
            Text(f, style: TextStyle(
              fontSize: 13, fontWeight: FontWeight.w600,
              color: isActive ? Colors.white.withOpacity(0.9) : AppColors.slate600,
            )),
          ]),
        )),
        const SizedBox(height: 16),
        AppButton(
          label: isActive ? 'Formule actuelle' : 'Choisir',
          onTap: isActive ? null : () {},
          color: isActive ? Colors.white.withOpacity(0.2) : color,
          width: double.infinity,
        ),
      ]),
    );
  }
}

// ─── MOVING BOOKING VIEW ──────────────────────────────────────────────────────
class MovingBookingView extends GetView<ServicesController> {
  const MovingBookingView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Réservation Déménagement'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded), onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: controller.formKey,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppColors.primary, Color(0xFF0066CC)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(children: [
                const Icon(Icons.local_shipping_rounded, color: Colors.white, size: 36),
                const SizedBox(width: 16),
                const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Déménagement & Transport', style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16,
                  )),
                  Text('Réservez votre déménagement', style: TextStyle(
                    color: Colors.white70, fontSize: 12,
                  )),
                ]),
              ]),
            ),
            const SizedBox(height: 28),
            AppTextField(
              label: 'Adresse de départ',
              hint: 'Adresse actuelle',
              prefixIcon: Icons.location_on_outlined,
              controller: controller.addressCtrl,
              validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
            ),
            const SizedBox(height: 18),
            AppTextField(
              label: 'Adresse d\'arrivée',
              hint: 'Nouvelle adresse',
              prefixIcon: Icons.location_on_rounded,
              controller: TextEditingController(),
            ),
            const SizedBox(height: 18),
            const Text('DATE DE DÉMÉNAGEMENT', style: TextStyle(
              fontSize: 11, fontWeight: FontWeight.w900,
              color: AppColors.slate500, letterSpacing: 1.5,
            )),
            const SizedBox(height: 8),
            Obx(() => GestureDetector(
              onTap: () => controller.pickDate(context),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.slate100, borderRadius: BorderRadius.circular(14),
                ),
                child: Row(children: [
                  const Icon(Icons.calendar_today_rounded, color: AppColors.primary, size: 20),
                  const SizedBox(width: 12),
                  Text(
                    controller.selectedDate.value != null
                        ? DateFormat('dd/MM/yyyy').format(controller.selectedDate.value!)
                        : 'Choisir une date',
                    style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.slate500),
                  ),
                ]),
              ),
            )),
            const SizedBox(height: 18),
            AppTextField(
              label: 'Volume estimé (m³)',
              hint: 'Ex: 15 m³',
              prefixIcon: Icons.inventory_2_outlined,
              controller: controller.budgetCtrl,
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 32),
            Obx(() => AppButton(
              label: 'Confirmer la réservation',
              onTap: controller.submitBooking,
              isLoading: controller.isLoading.value,
              width: double.infinity,
              icon: Icons.check_circle_outline_rounded,
            )),
          ]),
        ),
      ),
    );
  }
}

// ─── MESSAGE SUCCESS VIEW ─────────────────────────────────────────────────────
class MessageSuccessView extends StatelessWidget {
  const MessageSuccessView({super.key});

  @override
  Widget build(BuildContext context) {
    final args = Get.arguments as Map? ?? {};
    final isBooking = args['type'] == 'booking';

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(
                width: 100, height: 100,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppColors.emerald500, Color(0xFF059669)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(
                    color: AppColors.emerald500.withOpacity(0.3),
                    blurRadius: 30, offset: const Offset(0, 12),
                  )],
                ),
                alignment: Alignment.center,
                child: const Icon(Icons.check_rounded, color: Colors.white, size: 52),
              ),
              const SizedBox(height: 32),
              Text(
                isBooking ? 'Réservation confirmée !' : 'Demande envoyée !',
                style: const TextStyle(
                  fontSize: 26, fontWeight: FontWeight.w900,
                  color: AppColors.slate900, letterSpacing: -0.5,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              Text(
                isBooking
                    ? 'Votre réservation a été confirmée. L\'artisan vous contactera dans les 24h.'
                    : 'Votre demande de devis a été envoyée. Vous recevrez une réponse sous 2h.',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 14, color: AppColors.slate400, height: 1.7,
                ),
              ),
              const SizedBox(height: 40),
              AppButton(
                label: 'Retour à l\'accueil',
                onTap: () => Get.offAllNamed(AppRoutes.HOME),
                width: double.infinity,
                icon: Icons.home_rounded,
              ),
              const SizedBox(height: 12),
              AppButton(
                label: 'Voir mes projets',
                isOutlined: true,
                onTap: () => Get.offAllNamed(AppRoutes.CLIENT_PROJECTS),
                width: double.infinity,
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

// ─── SUBCATEGORY DETAILS VIEW ─────────────────────────────────────────────────
class SubcategoryDetailsView extends StatelessWidget {
  const SubcategoryDetailsView({super.key});

  @override
  Widget build(BuildContext context) {
    final id = Get.parameters['id'] ?? '1';
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sous-catégorie'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded), onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.primary, Color(0xFF0066CC)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.build_rounded, color: Colors.white, size: 40),
              SizedBox(height: 12),
              Text('Spécialisation', style: TextStyle(
                color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900,
              )),
              Text('Artisans spécialisés disponibles',
                  style: TextStyle(color: Colors.white70, fontSize: 13)),
            ]),
          ),
          const SizedBox(height: 24),
          ...MockData.artisans.take(3).map((a) => ArtisanCard(artisan: a)).toList(),
          AppButton(
            label: 'Voir tous les artisans',
            onTap: () => Get.toNamed(AppRoutes.FIND_EXPERT),
            width: double.infinity,
          ),
        ]),
      ),
    );
  }
}

