import 'package:get/get.dart';
import 'package:flutter/material.dart';
import '../../../core/services/storage_service.dart';
import '../../../core/services/api_service.dart';
import '../../../core/models/app_models.dart';
import '../../../app/routes/app_routes.dart';

class AuthController extends GetxController {
  // ── Form fields ──────────────────────────────────────────────────────────
  final emailCtrl = TextEditingController();
  final passwordCtrl = TextEditingController();
  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final cityCtrl = TextEditingController();
  final specialtyCtrl = TextEditingController();
  final confirmPasswordCtrl = TextEditingController();
  final formKey = GlobalKey<FormState>();

  // ── State ────────────────────────────────────────────────────────────────
  final isLoading = false.obs;
  final error = ''.obs;
  final obscurePassword = true.obs;
  final selectedRole = 'client'.obs;
  final currentUser = Rxn<UserModel>();

  @override
  void onInit() {
    super.onInit();
    currentUser.value = StorageService.getUser();
  }

  @override
  void onClose() {
    emailCtrl.dispose(); passwordCtrl.dispose();
    nameCtrl.dispose(); phoneCtrl.dispose();
    cityCtrl.dispose(); specialtyCtrl.dispose();
    confirmPasswordCtrl.dispose();
    super.onClose();
  }

  // ── LOGIN ─────────────────────────────────────────────────────────────────
  Future<void> login(String role) async {
    if (!formKey.currentState!.validate()) return;
    isLoading.value = true;
    error.value = '';

    try {
      // For demo: use mock login
      await Future.delayed(const Duration(seconds: 1));
      final mockUser = UserModel(
        id: role == 'admin' ? 999 : (role == 'artisan' ? 1 : 10),
        name: role == 'admin' ? 'Super Admin' : (role == 'artisan' ? 'Mohammed Amine Benali' : 'Ahmed Bensalem'),
        email: emailCtrl.text,
        phone: '+213 555 000 000',
        city: 'Alger',
        role: role,
        isVerified: true,
        createdAt: DateTime.now(),
      );
      await StorageService.saveToken('mock_token_${role}_${DateTime.now().millisecondsSinceEpoch}');
      await StorageService.saveUser(mockUser);
      currentUser.value = mockUser;

      // Navigate based on role
      if (role == 'admin') {
        Get.offAllNamed(AppRoutes.ADMIN_DASHBOARD);
      } else if (role == 'artisan') {
        Get.offAllNamed(AppRoutes.ARTISAN_DASHBOARD);
      } else {
        Get.offAllNamed(AppRoutes.CLIENT_INBOX);
      }
    } catch (e) {
      error.value = e.toString().replaceFirst('Exception: ', '');
    } finally {
      isLoading.value = false;
    }
  }

  // ── REGISTER ──────────────────────────────────────────────────────────────
  Future<void> register(String role) async {
    if (!formKey.currentState!.validate()) return;
    if (passwordCtrl.text != confirmPasswordCtrl.text) {
      error.value = 'Les mots de passe ne correspondent pas';
      return;
    }
    isLoading.value = true;
    error.value = '';
    try {
      await Future.delayed(const Duration(seconds: 1));
      Get.snackbar(
        'Succès !',
        role == 'client'
            ? 'Compte client créé avec succès !'
            : 'Compte artisan créé. En attente de vérification.',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: const Color(0xFF10B981),
        colorText: Colors.white,
        margin: const EdgeInsets.all(16),
        borderRadius: 16,
      );
      await Future.delayed(const Duration(milliseconds: 500));
      if (role == 'client') {
        Get.offAllNamed(AppRoutes.CLIENT_LOGIN);
      } else {
        Get.offAllNamed(AppRoutes.ARTISAN_LOGIN);
      }
    } catch (e) {
      error.value = e.toString().replaceFirst('Exception: ', '');
    } finally {
      isLoading.value = false;
    }
  }

  // ── LOGOUT ────────────────────────────────────────────────────────────────
  Future<void> logout() async {
    await StorageService.clearAll();
    currentUser.value = null;
    Get.offAllNamed(AppRoutes.HOME);
  }

  // ── FORGOT PASSWORD ───────────────────────────────────────────────────────
  Future<void> forgotPassword() async {
    if (emailCtrl.text.isEmpty) {
      error.value = 'Veuillez entrer votre email';
      return;
    }
    isLoading.value = true;
    await Future.delayed(const Duration(seconds: 1));
    isLoading.value = false;
    Get.snackbar(
      'Email envoyé',
      'Un lien de réinitialisation a été envoyé à ${emailCtrl.text}',
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: const Color(0xFF004C96),
      colorText: Colors.white,
      margin: const EdgeInsets.all(16),
      borderRadius: 16,
    );
  }

  void toggleObscure() => obscurePassword.toggle();
  void clearError() => error.value = '';
}
