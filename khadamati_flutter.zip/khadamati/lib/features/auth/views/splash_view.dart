import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/theme/app_theme.dart';
import '../../../app/routes/app_routes.dart';
import '../../../core/services/storage_service.dart';

class SplashView extends StatefulWidget {
  const SplashView({super.key});
  @override
  State<SplashView> createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView> with TickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _fade = Tween(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _ctrl, curve: const Interval(0.0, 0.6, curve: Curves.easeOut)));
    _slide = Tween(begin: const Offset(0, 0.3), end: Offset.zero).animate(
        CurvedAnimation(parent: _ctrl, curve: const Interval(0.2, 0.8, curve: Curves.easeOut)));
    _ctrl.forward();
    _navigate();
  }

  void _navigate() async {
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted) return;
    if (StorageService.isLoggedIn()) {
      final user = StorageService.getUser();
      if (user?.role == 'admin') Get.offAllNamed(AppRoutes.ADMIN_DASHBOARD);
      else if (user?.role == 'artisan') Get.offAllNamed(AppRoutes.ARTISAN_DASHBOARD);
      else Get.offAllNamed(AppRoutes.CLIENT_INBOX);
    } else {
      Get.offAllNamed(AppRoutes.HOME);
    }
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primary,
      body: Center(
        child: FadeTransition(
          opacity: _fade,
          child: SlideTransition(
            position: _slide,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(
                width: 90, height: 90,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(28),
                  boxShadow: [BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 40, offset: const Offset(0, 20),
                  )],
                ),
                alignment: Alignment.center,
                child: const Text('K', style: TextStyle(
                  fontSize: 44, fontWeight: FontWeight.w900,
                  color: AppColors.primary, fontFamily: 'Outfit',
                )),
              ),
              const SizedBox(height: 24),
              const Text('KHADAMATI', style: TextStyle(
                color: Colors.white, fontSize: 28,
                fontWeight: FontWeight.w900, letterSpacing: 4,
                fontFamily: 'Outfit',
              )),
              const SizedBox(height: 8),
              Text('خدماتي  •  L\'expertise à votre portée',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.7),
                  fontSize: 13, fontWeight: FontWeight.w600, fontFamily: 'Outfit',
                )),
              const SizedBox(height: 48),
              SizedBox(
                width: 28, height: 28,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  valueColor: AlwaysStoppedAnimation(Colors.white.withOpacity(0.5)),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
