import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/theme/app_theme.dart';
import '../../../app/routes/app_routes.dart';
import '../../../shared/widgets/app_widgets.dart';
import '../controllers/auth_controller.dart';

class ClientLoginView extends GetView<AuthController> {
  const ClientLoginView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.slate50,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Container(
              constraints: const BoxConstraints(maxWidth: 480),
              padding: const EdgeInsets.all(36),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(28),
                boxShadow: [BoxShadow(
                  color: AppColors.primary.withOpacity(0.08),
                  blurRadius: 60, offset: const Offset(0, 24),
                )],
                border: Border.all(color: AppColors.slate100),
              ),
              child: Form(
                key: controller.formKey,
                child: Column(children: [
                  // Role switcher
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppColors.slate100,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Row(children: [
                      _roleTab('CLIENT', AppRoutes.CLIENT_LOGIN, true),
                      _roleTab('ARTISAN', AppRoutes.ARTISAN_LOGIN, false),
                    ]),
                  ),
                  const SizedBox(height: 32),

                  // Title
                  Text('login'.tr, style: const TextStyle(
                    fontSize: 30, fontWeight: FontWeight.w900,
                    color: AppColors.slate900, letterSpacing: -1,
                  )),
                  const SizedBox(height: 8),
                  Text('login_welcome_back'.tr, style: const TextStyle(
                    fontSize: 15, color: AppColors.slate400, fontWeight: FontWeight.w500,
                  )),
                  const SizedBox(height: 32),

                  // Error
                  Obx(() => controller.error.value.isNotEmpty
                      ? _errorBanner(controller.error.value)
                      : const SizedBox()),

                  // Email
                  AppTextField(
                    label: 'email'.tr,
                    hint: 'nom@exemple.com',
                    prefixIcon: Icons.mail_outline_rounded,
                    controller: controller.emailCtrl,
                    keyboardType: TextInputType.emailAddress,
                    validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
                  ),
                  const SizedBox(height: 20),

                  // Password
                  Obx(() => AppTextField(
                    label: 'password'.tr,
                    hint: '••••••••',
                    prefixIcon: Icons.lock_outline_rounded,
                    suffixIcon: controller.obscurePassword.value
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    onSuffixTap: controller.toggleObscure,
                    obscureText: controller.obscurePassword.value,
                    controller: controller.passwordCtrl,
                    validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
                  )),
                  const SizedBox(height: 12),

                  // Forgot password
                  Align(
                    alignment: Alignment.centerRight,
                    child: GestureDetector(
                      onTap: () => Get.toNamed(AppRoutes.FORGOT_PASSWORD),
                      child: Text('forgot_password'.tr, style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w700,
                        color: AppColors.primary,
                      )),
                    ),
                  ),
                  const SizedBox(height: 28),

                  // Login button
                  Obx(() => AppButton(
                    label: 'login'.tr,
                    onTap: () => controller.login('client'),
                    isLoading: controller.isLoading.value,
                    width: double.infinity,
                  )),
                  const SizedBox(height: 28),

                  // Register link
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text('no_account'.tr, style: const TextStyle(
                      color: AppColors.slate400, fontSize: 14,
                    )),
                    const SizedBox(width: 6),
                    GestureDetector(
                      onTap: () => Get.toNamed(AppRoutes.CLIENT_REGISTER),
                      child: Text('register'.tr, style: const TextStyle(
                        color: AppColors.primary, fontWeight: FontWeight.w800,
                        fontSize: 14,
                      )),
                    ),
                  ]),
                  const SizedBox(height: 20),

                  // Back to home
                  GestureDetector(
                    onTap: () => Get.offAllNamed(AppRoutes.HOME),
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: const [
                      Icon(Icons.arrow_back_ios_new_rounded, size: 13, color: AppColors.slate400),
                      SizedBox(width: 4),
                      Text('Retour à l\'accueil', style: TextStyle(
                        color: AppColors.slate400, fontSize: 13, fontWeight: FontWeight.w600,
                      )),
                    ]),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _roleTab(String label, String route, bool isActive) {
    return Expanded(
      child: GestureDetector(
        onTap: () => Get.offNamed(route),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isActive ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
            boxShadow: isActive ? [BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 8, offset: const Offset(0, 2),
            )] : [],
          ),
          alignment: Alignment.center,
          child: Text(label, style: TextStyle(
            fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 1.5,
            color: isActive ? AppColors.primary : AppColors.slate400,
          )),
        ),
      ),
    );
  }

  Widget _errorBanner(String msg) => Container(
    margin: const EdgeInsets.only(bottom: 20),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: AppColors.red50,
      borderRadius: BorderRadius.circular(14),
      border: Border(left: BorderSide(color: AppColors.red500, width: 4)),
    ),
    child: Row(children: [
      const Icon(Icons.error_outline_rounded, color: AppColors.red500, size: 20),
      const SizedBox(width: 10),
      Expanded(child: Text(msg, style: const TextStyle(
        color: AppColors.red500, fontWeight: FontWeight.w600, fontSize: 13,
      ))),
    ]),
  );
}
