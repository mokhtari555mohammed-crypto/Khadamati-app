import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/theme/app_theme.dart';
import '../../../app/routes/app_routes.dart';
import '../../../shared/widgets/app_widgets.dart';
import '../controllers/auth_controller.dart';

// ─── ARTISAN LOGIN ────────────────────────────────────────────────────────────
class ArtisanLoginView extends GetView<AuthController> {
  const ArtisanLoginView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.slate50,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Container(
              constraints: const BoxConstraints(maxWidth: 480),
              padding: const EdgeInsets.all(36),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(28),
                boxShadow: [BoxShadow(
                  color: AppColors.primary.withOpacity(0.08),
                  blurRadius: 60, offset: const Offset(0, 24),
                )],
                border: Border.all(color: AppColors.slate100),
              ),
              child: Form(
                key: controller.formKey,
                child: Column(children: [
                  // Role switcher
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppColors.slate100,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Row(children: [
                      _tab('CLIENT', AppRoutes.CLIENT_LOGIN, false),
                      _tab('ARTISAN', AppRoutes.ARTISAN_LOGIN, true),
                    ]),
                  ),
                  const SizedBox(height: 32),
                  Text('artisan_login'.tr, style: const TextStyle(
                    fontSize: 30, fontWeight: FontWeight.w900, color: AppColors.slate900,
                  )),
                  const SizedBox(height: 8),
                  Text('login_welcome_back'.tr, style: const TextStyle(
                    fontSize: 15, color: AppColors.slate400,
                  )),
                  const SizedBox(height: 32),
                  Obx(() => controller.error.value.isNotEmpty
                      ? _errorBanner(controller.error.value)
                      : const SizedBox()),
                  AppTextField(
                    label: 'email'.tr, hint: 'artisan@exemple.com',
                    prefixIcon: Icons.mail_outline_rounded,
                    controller: controller.emailCtrl,
                    keyboardType: TextInputType.emailAddress,
                    validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
                  ),
                  const SizedBox(height: 20),
                  Obx(() => AppTextField(
                    label: 'password'.tr, hint: '••••••••',
                    prefixIcon: Icons.lock_outline_rounded,
                    suffixIcon: controller.obscurePassword.value
                        ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                    onSuffixTap: controller.toggleObscure,
                    obscureText: controller.obscurePassword.value,
                    controller: controller.passwordCtrl,
                    validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
                  )),
                  const SizedBox(height: 12),
                  Align(
                    alignment: Alignment.centerRight,
                    child: GestureDetector(
                      onTap: () => Get.toNamed(AppRoutes.FORGOT_PASSWORD),
                      child: Text('forgot_password'.tr, style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.primary,
                      )),
                    ),
                  ),
                  const SizedBox(height: 28),
                  Obx(() => AppButton(
                    label: 'login'.tr,
                    onTap: () => controller.login('artisan'),
                    isLoading: controller.isLoading.value,
                    width: double.infinity,
                  )),
                  const SizedBox(height: 28),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text('no_account'.tr, style: const TextStyle(color: AppColors.slate400, fontSize: 14)),
                    const SizedBox(width: 6),
                    GestureDetector(
                      onTap: () => Get.toNamed(AppRoutes.ARTISAN_REGISTER),
                      child: Text('register'.tr, style: const TextStyle(
                        color: AppColors.primary, fontWeight: FontWeight.w800, fontSize: 14,
                      )),
                    ),
                  ]),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () => Get.offAllNamed(AppRoutes.HOME),
                    child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.arrow_back_ios_new_rounded, size: 13, color: AppColors.slate400),
                      SizedBox(width: 4),
                      Text('Retour à l\'accueil', style: TextStyle(
                        color: AppColors.slate400, fontSize: 13, fontWeight: FontWeight.w600,
                      )),
                    ]),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _tab(String label, String route, bool isActive) => Expanded(
    child: GestureDetector(
      onTap: () => Get.offNamed(route),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isActive ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          boxShadow: isActive ? [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8)] : [],
        ),
        alignment: Alignment.center,
        child: Text(label, style: TextStyle(
          fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 1.5,
          color: isActive ? AppColors.primary : AppColors.slate400,
        )),
      ),
    ),
  );

  Widget _errorBanner(String msg) => Container(
    margin: const EdgeInsets.only(bottom: 20),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: AppColors.red50,
      borderRadius: BorderRadius.circular(14),
      border: Border(left: BorderSide(color: AppColors.red500, width: 4)),
    ),
    child: Row(children: [
      const Icon(Icons.error_outline_rounded, color: AppColors.red500, size: 20),
      const SizedBox(width: 10),
      Expanded(child: Text(msg, style: const TextStyle(color: AppColors.red500, fontWeight: FontWeight.w600, fontSize: 13))),
    ]),
  );
}

// ─── ADMIN LOGIN ──────────────────────────────────────────────────────────────
class AdminLoginView extends GetView<AuthController> {
  const AdminLoginView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Container(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(children: [
                // Logo
                Container(
                  width: 72, height: 72,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppColors.primary, Color(0xFF0066CC)],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: [BoxShadow(
                      color: AppColors.primary.withOpacity(0.4),
                      blurRadius: 24, offset: const Offset(0, 12),
                    )],
                  ),
                  alignment: Alignment.center,
                  child: const Icon(Icons.diamond_outlined, color: Colors.white, size: 36),
                ),
                const SizedBox(height: 20),
                const Text('KHADAMATI', style: TextStyle(
                  color: Colors.white, fontSize: 22,
                  fontWeight: FontWeight.w900, letterSpacing: 4,
                )),
                const SizedBox(height: 4),
                Text('premium_edition'.tr, style: const TextStyle(
                  color: AppColors.secondary, fontSize: 11,
                  fontWeight: FontWeight.w800, letterSpacing: 2,
                )),
                const SizedBox(height: 36),
                // Card
                Container(
                  padding: const EdgeInsets.all(32),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E293B),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: const Color(0xFF334155)),
                  ),
                  child: Form(
                    key: controller.formKey,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('Accès Administrateur', style: TextStyle(
                        fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white,
                      )),
                      const SizedBox(height: 6),
                      const Text('Réservé aux administrateurs autorisés', style: TextStyle(
                        fontSize: 13, color: Color(0xFF64748B),
                      )),
                      const SizedBox(height: 28),
                      Obx(() => controller.error.value.isNotEmpty
                          ? Container(
                              margin: const EdgeInsets.only(bottom: 20),
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                color: AppColors.red500.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: AppColors.red500.withOpacity(0.3)),
                              ),
                              child: Text(controller.error.value, style: const TextStyle(
                                color: AppColors.red500, fontSize: 13,
                              )),
                            )
                          : const SizedBox()),
                      _darkField('Email', Icons.mail_outline_rounded, controller.emailCtrl, false),
                      const SizedBox(height: 16),
                      Obx(() => _darkField('Mot de passe', Icons.lock_outline_rounded,
                          controller.passwordCtrl, controller.obscurePassword.value,
                          suffix: controller.obscurePassword.value
                              ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                          onSuffix: controller.toggleObscure)),
                      const SizedBox(height: 28),
                      Obx(() => SizedBox(
                        width: double.infinity, height: 54,
                        child: ElevatedButton(
                          onPressed: controller.isLoading.value ? null : () => controller.login('admin'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          ),
                          child: controller.isLoading.value
                              ? const CircularProgressIndicator(color: Colors.white, strokeWidth: 2)
                              : const Text('CONNEXION', style: TextStyle(
                                  fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 14)),
                        ),
                      )),
                    ]),
                  ),
                ),
                const SizedBox(height: 24),
                GestureDetector(
                  onTap: () => Get.offAllNamed(AppRoutes.HOME),
                  child: const Text('← Retour à l\'accueil', style: TextStyle(
                    color: Color(0xFF64748B), fontSize: 13, fontWeight: FontWeight.w600,
                  )),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget _darkField(String label, IconData icon, TextEditingController ctrl, bool obscure,
      {IconData? suffix, VoidCallback? onSuffix}) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label.toUpperCase(), style: const TextStyle(
        fontSize: 10, fontWeight: FontWeight.w800,
        color: Color(0xFF94A3B8), letterSpacing: 1.5,
      )),
      const SizedBox(height: 8),
      TextFormField(
        controller: ctrl,
        obscureText: obscure,
        style: const TextStyle(color: Colors.white, fontFamily: 'Outfit', fontWeight: FontWeight.w600),
        decoration: InputDecoration(
          filled: true,
          fillColor: const Color(0xFF0F172A),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFF334155)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFF334155)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: AppColors.primary, width: 2),
          ),
          prefixIcon: Icon(icon, color: const Color(0xFF64748B), size: 20),
          suffixIcon: suffix != null ? GestureDetector(
            onTap: onSuffix,
            child: Icon(suffix, color: const Color(0xFF64748B), size: 20),
          ) : null,
        ),
        validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
      ),
    ]);
  }
}

// ─── FORGOT PASSWORD ──────────────────────────────────────────────────────────
class ForgotPasswordView extends GetView<AuthController> {
  const ForgotPasswordView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.slate50,
      appBar: AppBar(backgroundColor: AppColors.slate50),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 440),
            padding: const EdgeInsets.all(36),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: AppColors.slate100),
              boxShadow: [BoxShadow(
                color: AppColors.primary.withOpacity(0.06),
                blurRadius: 40, offset: const Offset(0, 16),
              )],
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.primaryLight,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.lock_reset_rounded, color: AppColors.primary, size: 32),
              ),
              const SizedBox(height: 24),
              const Text('Mot de passe oublié ?', style: TextStyle(
                fontSize: 26, fontWeight: FontWeight.w900, color: AppColors.slate900,
              )),
              const SizedBox(height: 8),
              const Text('Entrez votre email pour recevoir un lien de réinitialisation.',
                  style: TextStyle(fontSize: 14, color: AppColors.slate400)),
              const SizedBox(height: 32),
              AppTextField(
                label: 'Email',
                hint: 'nom@exemple.com',
                prefixIcon: Icons.mail_outline_rounded,
                controller: controller.emailCtrl,
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 24),
              Obx(() => AppButton(
                label: 'Envoyer le lien',
                onTap: controller.forgotPassword,
                isLoading: controller.isLoading.value,
                width: double.infinity,
              )),
            ]),
          ),
        ),
      ),
    );
  }
}
