import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/theme/app_theme.dart';
import '../../../app/routes/app_routes.dart';
import '../../../shared/widgets/app_widgets.dart';
import '../controllers/auth_controller.dart';

// ─── CLIENT REGISTER ──────────────────────────────────────────────────────────
class ClientRegisterView extends GetView<AuthController> {
  const ClientRegisterView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.slate50,
      appBar: AppBar(
        backgroundColor: AppColors.slate50,
        title: Text('register'.tr),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: Container(
            constraints: const BoxConstraints(maxWidth: 480),
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: AppColors.slate100),
              boxShadow: [BoxShadow(
                color: AppColors.primary.withOpacity(0.06),
                blurRadius: 40, offset: const Offset(0, 16),
              )],
            ),
            child: Form(
              key: controller.formKey,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // Header
                Row(children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppColors.primary, Color(0xFF0066CC)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(Icons.person_add_rounded, color: Colors.white, size: 24),
                  ),
                  const SizedBox(width: 14),
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('register_welcome'.tr, style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.slate900,
                    )),
                    Text('client'.tr, style: const TextStyle(
                      fontSize: 12, color: AppColors.primary, fontWeight: FontWeight.w700,
                      letterSpacing: 1.5,
                    )),
                  ]),
                ]),
                const SizedBox(height: 28),
                Obx(() => controller.error.value.isNotEmpty
                    ? _errorBanner(controller.error.value)
                    : const SizedBox()),
                AppTextField(
                  label: 'full_name'.tr, hint: 'Votre nom complet',
                  prefixIcon: Icons.person_outline_rounded,
                  controller: controller.nameCtrl,
                  validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
                ),
                const SizedBox(height: 18),
                AppTextField(
                  label: 'email'.tr, hint: 'nom@exemple.com',
                  prefixIcon: Icons.mail_outline_rounded,
                  controller: controller.emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
                ),
                const SizedBox(height: 18),
                AppTextField(
                  label: 'phone'.tr, hint: '+213 5XX XXX XXX',
                  prefixIcon: Icons.phone_outlined,
                  controller: controller.phoneCtrl,
                  keyboardType: TextInputType.phone,
                  validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
                ),
                const SizedBox(height: 18),
                AppTextField(
                  label: 'city'.tr, hint: 'Alger, Oran...',
                  prefixIcon: Icons.location_city_rounded,
                  controller: controller.cityCtrl,
                  validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
                ),
                const SizedBox(height: 18),
                Obx(() => AppTextField(
                  label: 'password'.tr, hint: '8+ caractères',
                  prefixIcon: Icons.lock_outline_rounded,
                  suffixIcon: controller.obscurePassword.value
                      ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  onSuffixTap: controller.toggleObscure,
                  obscureText: controller.obscurePassword.value,
                  controller: controller.passwordCtrl,
                  validator: (v) => (v?.length ?? 0) < 8 ? 'Min. 8 caractères' : null,
                )),
                const SizedBox(height: 18),
                AppTextField(
                  label: 'confirm_password'.tr, hint: 'Répétez le mot de passe',
                  prefixIcon: Icons.lock_outline_rounded,
                  obscureText: true,
                  controller: controller.confirmPasswordCtrl,
                  validator: (v) => v != controller.passwordCtrl.text ? 'Différent' : null,
                ),
                const SizedBox(height: 28),
                Obx(() => AppButton(
                  label: 'Créer mon compte',
                  onTap: () => controller.register('client'),
                  isLoading: controller.isLoading.value,
                  width: double.infinity,
                )),
                const SizedBox(height: 20),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('have_account'.tr, style: const TextStyle(
                    color: AppColors.slate400, fontSize: 14,
                  )),
                  const SizedBox(width: 6),
                  GestureDetector(
                    onTap: () => Get.offNamed(AppRoutes.CLIENT_LOGIN),
                    child: Text('login'.tr, style: const TextStyle(
                      color: AppColors.primary, fontWeight: FontWeight.w800, fontSize: 14,
                    )),
                  ),
                ]),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget _errorBanner(String msg) => Container(
    margin: const EdgeInsets.only(bottom: 20),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: AppColors.red50,
      borderRadius: BorderRadius.circular(14),
      border: Border(left: BorderSide(color: AppColors.red500, width: 4)),
    ),
    child: Text(msg, style: const TextStyle(color: AppColors.red500, fontWeight: FontWeight.w600)),
  );
}

// ─── ARTISAN REGISTER ─────────────────────────────────────────────────────────
class ArtisanRegisterView extends GetView<AuthController> {
  const ArtisanRegisterView({super.key});

  static const _specialties = [
    'Plomberie et Réseaux', 'Électricité et Énergie',
    'Menuiserie et Bois', 'Ferronnerie et Soudure',
    'Peinture et Plâtre', 'Maçonnerie et Finitions',
    'Mécanique et Machines', 'Couture et Cuir',
    'Verre et Miroiterie', 'Métiers Alimentaires',
    'Jardinage et Espaces Verts', 'Déménagement et Transport',
  ];

  final selectedSpecialty = ''.obs;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.slate50,
      appBar: AppBar(
        backgroundColor: AppColors.slate50,
        title: const Text('Inscription Artisan'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: Container(
            constraints: const BoxConstraints(maxWidth: 480),
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: AppColors.slate100),
              boxShadow: [BoxShadow(
                color: AppColors.primary.withOpacity(0.06),
                blurRadius: 40, offset: const Offset(0, 16),
              )],
            ),
            child: Form(
              key: controller.formKey,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppColors.secondary, Color(0xFFE07020)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(Icons.engineering_rounded, color: Colors.white, size: 24),
                  ),
                  const SizedBox(width: 14),
                  const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Rejoindre en tant qu\'Artisan', style: TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w900, color: AppColors.slate900,
                    )),
                    Text('ARTISAN', style: TextStyle(
                      fontSize: 11, color: AppColors.secondary,
                      fontWeight: FontWeight.w800, letterSpacing: 1.5,
                    )),
                  ]),
                ]),
                const SizedBox(height: 28),

                // Info banner
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.amber50,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.amber500.withOpacity(0.3)),
                  ),
                  child: Row(children: [
                    const Icon(Icons.info_outline_rounded, color: AppColors.amber500, size: 20),
                    const SizedBox(width: 10),
                    const Expanded(child: Text(
                      'Votre compte sera activé après vérification de vos documents par notre équipe.',
                      style: TextStyle(fontSize: 12, color: AppColors.amber500, fontWeight: FontWeight.w600),
                    )),
                  ]),
                ),
                const SizedBox(height: 24),

                Obx(() => controller.error.value.isNotEmpty
                    ? Container(
                        margin: const EdgeInsets.only(bottom: 20),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppColors.red50,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Text(controller.error.value,
                            style: const TextStyle(color: AppColors.red500)),
                      )
                    : const SizedBox()),

                AppTextField(
                  label: 'full_name'.tr, hint: 'Votre nom complet',
                  prefixIcon: Icons.person_outline_rounded,
                  controller: controller.nameCtrl,
                  validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
                ),
                const SizedBox(height: 18),
                AppTextField(
                  label: 'email'.tr, hint: 'artisan@exemple.com',
                  prefixIcon: Icons.mail_outline_rounded,
                  controller: controller.emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
                ),
                const SizedBox(height: 18),
                AppTextField(
                  label: 'phone'.tr, hint: '+213 5XX XXX XXX',
                  prefixIcon: Icons.phone_outlined,
                  controller: controller.phoneCtrl,
                  keyboardType: TextInputType.phone,
                  validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
                ),
                const SizedBox(height: 18),
                AppTextField(
                  label: 'city'.tr, hint: 'Alger, Oran...',
                  prefixIcon: Icons.location_city_rounded,
                  controller: controller.cityCtrl,
                  validator: (v) => (v?.isEmpty ?? true) ? 'Requis' : null,
                ),
                const SizedBox(height: 18),

                // Specialty picker
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('SPÉCIALITÉ', style: TextStyle(
                    fontSize: 11, fontWeight: FontWeight.w900,
                    color: AppColors.slate500, letterSpacing: 1.5,
                  )),
                  const SizedBox(height: 8),
                  Obx(() => DropdownButtonFormField<String>(
                    value: selectedSpecialty.value.isEmpty ? null : selectedSpecialty.value,
                    decoration: InputDecoration(
                      filled: true, fillColor: AppColors.slate100,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide.none,
                      ),
                      prefixIcon: const Icon(Icons.handyman_outlined, color: AppColors.slate400),
                    ),
                    hint: const Text('Choisissez votre spécialité',
                        style: TextStyle(color: AppColors.slate300)),
                    items: _specialties.map((s) => DropdownMenuItem(
                      value: s,
                      child: Text(s, style: const TextStyle(
                        fontFamily: 'Outfit', fontWeight: FontWeight.w600,
                      )),
                    )).toList(),
                    onChanged: (v) {
                      if (v != null) selectedSpecialty.value = v;
                      controller.specialtyCtrl.text = v ?? '';
                    },
                    validator: (v) => v == null ? 'Requis' : null,
                  )),
                ]),
                const SizedBox(height: 18),
                Obx(() => AppTextField(
                  label: 'password'.tr, hint: '8+ caractères',
                  prefixIcon: Icons.lock_outline_rounded,
                  suffixIcon: controller.obscurePassword.value
                      ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  onSuffixTap: controller.toggleObscure,
                  obscureText: controller.obscurePassword.value,
                  controller: controller.passwordCtrl,
                  validator: (v) => (v?.length ?? 0) < 8 ? 'Min. 8 caractères' : null,
                )),
                const SizedBox(height: 18),
                AppTextField(
                  label: 'confirm_password'.tr, hint: 'Répétez le mot de passe',
                  prefixIcon: Icons.lock_outline_rounded,
                  obscureText: true,
                  controller: controller.confirmPasswordCtrl,
                  validator: (v) => v != controller.passwordCtrl.text ? 'Différent' : null,
                ),
                const SizedBox(height: 28),
                Obx(() => AppButton(
                  label: 'S\'inscrire comme Artisan',
                  onTap: () => controller.register('artisan'),
                  isLoading: controller.isLoading.value,
                  width: double.infinity,
                  color: AppColors.secondary,
                )),
                const SizedBox(height: 20),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Text('Déjà inscrit ?', style: TextStyle(
                    color: AppColors.slate400, fontSize: 14,
                  )),
                  const SizedBox(width: 6),
                  GestureDetector(
                    onTap: () => Get.offNamed(AppRoutes.ARTISAN_LOGIN),
                    child: const Text('Se connecter', style: TextStyle(
                      color: AppColors.secondary, fontWeight: FontWeight.w800, fontSize: 14,
                    )),
                  ),
                ]),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
