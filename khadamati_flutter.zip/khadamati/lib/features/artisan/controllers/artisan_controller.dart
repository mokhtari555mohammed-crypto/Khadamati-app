import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/models/app_models.dart';
import '../../../core/services/storage_service.dart';
import '../../../app/routes/app_routes.dart';

class ArtisanController extends GetxController {
  final stats = Rxn<ArtisanStats>();
  final bookings = <BookingModel>[].obs;
  final pendingDevis = <BookingModel>[].obs;
  final conversations = <ConversationModel>[].obs;
  final isLoading = false.obs;
  final currentUser = Rxn<UserModel>();
  final isAvailable = true.obs;

  // Settings form
  final nameCtrl = TextEditingController();
  final bioCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final cityCtrl = TextEditingController();
  final hourlyRateCtrl = TextEditingController();

  @override
  void onInit() {
    super.onInit();
    currentUser.value = StorageService.getUser();
    _load();
  }

  void _load() {
    isLoading.value = true;
    Future.delayed(const Duration(milliseconds: 700), () {
      stats.value = MockData.artisanStats;
      bookings.assignAll(MockData.artisanBookings);
      pendingDevis.assignAll(MockData.artisanBookings.where((b) => b.status == 'pending').toList());
      conversations.assignAll(MockData.conversations);
      nameCtrl.text = currentUser.value?.name ?? '';
      isLoading.value = false;
    });
  }

  void acceptDevis(dynamic id) {
    final idx = pendingDevis.indexWhere((b) => b.id == id);
    if (idx != -1) {
      pendingDevis.removeAt(idx);
      Get.snackbar('Devis accepté', 'Le client sera notifié.',
          backgroundColor: AppColors.emerald500,
          colorText: Colors.white, snackPosition: SnackPosition.BOTTOM,
          margin: const EdgeInsets.all(16));
    }
  }

  void rejectDevis(dynamic id) {
    final idx = pendingDevis.indexWhere((b) => b.id == id);
    if (idx != -1) pendingDevis.removeAt(idx);
  }

  void markCompleted(dynamic id) {
    final idx = bookings.indexWhere((b) => b.id == id);
    if (idx != -1) {
      final b = bookings[idx];
      bookings[idx] = BookingModel(
        id: b.id, serviceTitle: b.serviceTitle,
        clientName: b.clientName, clientId: b.clientId,
        bookingDate: b.bookingDate, status: 'completed',
        totalPrice: b.totalPrice, type: b.type,
      );
      bookings.refresh();
    }
  }

  void logout() {
    Get.dialog(AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('Déconnexion', style: TextStyle(fontWeight: FontWeight.w900)),
      content: const Text('Voulez-vous vraiment vous déconnecter ?'),
      actions: [
        TextButton(onPressed: () => Get.back(), child: const Text('Annuler')),
        ElevatedButton(
          onPressed: () async {
            Get.back();
            await StorageService.clearAll();
            Get.offAllNamed(AppRoutes.HOME);
          },
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFEF4444),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
          child: const Text('Déconnexion'),
        ),
      ],
    ));
  }

  @override
  void onClose() {
    nameCtrl.dispose(); bioCtrl.dispose();
    phoneCtrl.dispose(); cityCtrl.dispose(); hourlyRateCtrl.dispose();
    super.onClose();
  }
}
