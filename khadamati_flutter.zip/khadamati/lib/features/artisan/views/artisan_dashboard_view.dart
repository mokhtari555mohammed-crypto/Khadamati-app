import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../app/theme/app_theme.dart';
import '../../../app/routes/app_routes.dart';
import '../../../core/models/app_models.dart';
import '../../../shared/widgets/app_widgets.dart';
import '../controllers/artisan_controller.dart';

// ─── ARTISAN LAYOUT ───────────────────────────────────────────────────────────
class _ArtisanLayout extends GetView<ArtisanController> {
  final Widget child;
  final String title;
  final int currentIndex;
  final List<Widget>? actions;

  const _ArtisanLayout({
    required this.child, required this.title,
    required this.currentIndex, this.actions,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          ...?actions,
          IconButton(icon: const Icon(Icons.notifications_none_rounded), onPressed: () {}),
        ],
        leading: Builder(builder: (ctx) => IconButton(
          icon: const Icon(Icons.menu_rounded),
          onPressed: () => Scaffold.of(ctx).openDrawer(),
        )),
      ),
      drawer: _buildDrawer(),
      bottomNavigationBar: _buildBottomNav(),
      body: child,
    );
  }

  Widget _buildDrawer() => Drawer(
    child: Column(children: [
      Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(24, 56, 24, 24),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0F172A), Color(0xFF1E293B)],
          ),
        ),
        child: Obx(() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            width: 60, height: 60,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.secondary, Color(0xFFE07020)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(18),
            ),
            alignment: Alignment.center,
            child: Text(
              controller.currentUser.value?.initials ?? 'A',
              style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900),
            ),
          ),
          const SizedBox(height: 12),
          Text(controller.currentUser.value?.name ?? 'Artisan',
              style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)),
          if (controller.stats.value?.isVerified == true) ...[
            const SizedBox(height: 4),
            Row(children: const [
              Icon(Icons.verified_rounded, color: AppColors.primary, size: 14),
              SizedBox(width: 4),
              Text('Compte vérifié', style: TextStyle(color: Colors.white70, fontSize: 12)),
            ]),
          ],
          const SizedBox(height: 10),
          Obx(() => GestureDetector(
            onTap: () => controller.isAvailable.toggle(),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
              decoration: BoxDecoration(
                color: controller.isAvailable.value
                    ? AppColors.emerald500.withOpacity(0.2) : Colors.red.withOpacity(0.2),
                borderRadius: BorderRadius.circular(100),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  width: 8, height: 8,
                  decoration: BoxDecoration(
                    color: controller.isAvailable.value ? AppColors.emerald500 : Colors.red,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  controller.isAvailable.value ? 'Disponible' : 'Indisponible',
                  style: TextStyle(
                    fontSize: 11, fontWeight: FontWeight.w800,
                    color: controller.isAvailable.value ? AppColors.emerald500 : Colors.red,
                  ),
                ),
              ]),
            ),
          )),
        ])),
      ),
      Expanded(child: ListView(padding: const EdgeInsets.all(12), children: [
        _drawerItem(Icons.dashboard_rounded, 'Tableau de bord', AppRoutes.ARTISAN_DASHBOARD, 0),
        _drawerItem(Icons.folder_open_rounded, 'Projets', AppRoutes.ARTISAN_PROJECTS, 1),
        _drawerItem(Icons.request_quote_rounded, 'Tarification', AppRoutes.ARTISAN_PRICING, 2),
        _drawerItem(Icons.chat_bubble_outline_rounded, 'Messages', AppRoutes.ARTISAN_MESSAGES, 3),
        _drawerItem(Icons.verified_user_outlined, 'Vérifications', AppRoutes.ARTISAN_VERIFICATIONS, 4),
        const Divider(height: 20),
        _drawerItem(Icons.settings_outlined, 'Paramètres', AppRoutes.ARTISAN_SETTINGS, 5),
      ])),
      Padding(
        padding: const EdgeInsets.all(16),
        child: AppButton(
          label: 'Déconnexion', onTap: controller.logout,
          isOutlined: true, color: AppColors.red500, width: double.infinity,
          icon: Icons.logout_rounded,
        ),
      ),
    ]),
  );

  Widget _drawerItem(IconData icon, String label, String route, int index) {
    final isActive = currentIndex == index;
    return ListTile(
      leading: Icon(icon, color: isActive ? AppColors.secondary : AppColors.slate400, size: 22),
      title: Text(label, style: TextStyle(
        fontWeight: FontWeight.w700,
        color: isActive ? AppColors.secondary : AppColors.slate700,
      )),
      tileColor: isActive ? const Color(0xFFFFF3E0) : null,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      onTap: () { Get.back(); if (route != Get.currentRoute) Get.offNamed(route); },
    );
  }

  Widget _buildBottomNav() => NavigationBar(
    selectedIndex: currentIndex.clamp(0, 5),
    onDestinationSelected: (i) {
      const routes = [
        AppRoutes.ARTISAN_DASHBOARD, AppRoutes.ARTISAN_PROJECTS,
        AppRoutes.ARTISAN_PRICING, AppRoutes.ARTISAN_MESSAGES,
        AppRoutes.ARTISAN_VERIFICATIONS, AppRoutes.ARTISAN_SETTINGS,
      ];
      if (i < routes.length) Get.offNamed(routes[i]);
    },
    backgroundColor: Colors.white,
    indicatorColor: const Color(0xFFFFF3E0),
    destinations: const [
      NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard_rounded), label: 'Accueil'),
      NavigationDestination(icon: Icon(Icons.folder_outlined), selectedIcon: Icon(Icons.folder_rounded), label: 'Projets'),
      NavigationDestination(icon: Icon(Icons.payments_outlined), selectedIcon: Icon(Icons.payments_rounded), label: 'Tarifs'),
      NavigationDestination(icon: Icon(Icons.chat_bubble_outline_rounded), selectedIcon: Icon(Icons.chat_bubble_rounded), label: 'Messages'),
      NavigationDestination(icon: Icon(Icons.verified_outlined), selectedIcon: Icon(Icons.verified_rounded), label: 'Docs'),
      NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: 'Réglages'),
    ],
  );
}

// ─── ARTISAN DASHBOARD VIEW ───────────────────────────────────────────────────
class ArtisanDashboardView extends GetView<ArtisanController> {
  const ArtisanDashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return _ArtisanLayout(
      title: 'Tableau de bord',
      currentIndex: 0,
      child: Obx(() => controller.isLoading.value
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // Greeting
                Text('Bonjour, ${controller.currentUser.value?.name.split(' ').first ?? ''} 👨‍🔧',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.slate900)),
                const SizedBox(height: 4),
                const Text("Voici vos performances du mois",
                    style: TextStyle(color: AppColors.slate400, fontSize: 13)),
                const SizedBox(height: 24),

                // Stats grid
                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2, childAspectRatio: 1.3,
                  crossAxisSpacing: 12, mainAxisSpacing: 12,
                  children: [
                    StatCard(
                      title: 'Revenu total', color: AppColors.emerald500,
                      value: '${(controller.stats.value?.totalRevenue ?? 0).toInt()} DA',
                      icon: Icons.account_balance_wallet_rounded,
                      subtitle: '+12% ce mois',
                    ),
                    StatCard(
                      title: 'Projets terminés', color: AppColors.primary,
                      value: '${controller.stats.value?.completedBookings ?? 0}',
                      icon: Icons.check_circle_rounded,
                    ),
                    StatCard(
                      title: 'Devis en attente', color: AppColors.amber500,
                      value: '${controller.stats.value?.pendingDevis ?? 0}',
                      icon: Icons.hourglass_empty_rounded,
                    ),
                    StatCard(
                      title: 'Note moyenne', color: AppColors.secondary,
                      value: '★ ${controller.stats.value?.rating ?? 0}',
                      icon: Icons.star_rounded,
                      subtitle: '${controller.stats.value?.reviewCount ?? 0} avis',
                    ),
                  ],
                ),
                const SizedBox(height: 28),

                // Revenue chart
                const SectionTitle(title: 'Revenus (6 mois)'),
                const SizedBox(height: 16),
                Container(
                  height: 200,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white, borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppColors.slate100),
                  ),
                  child: LineChart(LineChartData(
                    gridData: FlGridData(show: false),
                    titlesData: FlTitlesData(
                      bottomTitles: AxisTitles(sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (v, _) {
                          const labels = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun'];
                          final i = v.toInt();
                          if (i < 0 || i >= labels.length) return const Text('');
                          return Text(labels[i], style: const TextStyle(fontSize: 10, color: AppColors.slate400));
                        },
                        reservedSize: 24,
                      )),
                      leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    ),
                    borderData: FlBorderData(show: false),
                    lineBarsData: [
                      LineChartBarData(
                        spots: const [
                          FlSpot(0, 18000), FlSpot(1, 22000), FlSpot(2, 19500),
                          FlSpot(3, 27000), FlSpot(4, 24500), FlSpot(5, 31000),
                        ],
                        isCurved: true,
                        color: AppColors.primary,
                        barWidth: 3,
                        belowBarData: BarAreaData(
                          show: true,
                          color: AppColors.primary.withOpacity(0.1),
                        ),
                        dotData: FlDotData(show: false),
                      ),
                    ],
                  )),
                ),
                const SizedBox(height: 28),

                // Pending devis
                if (controller.pendingDevis.isNotEmpty) ...[
                  SectionTitle(
                    title: 'Devis en attente (${controller.pendingDevis.length})',
                    action: 'Voir tout',
                    onAction: () => Get.toNamed(AppRoutes.ARTISAN_PROJECTS),
                  ),
                  const SizedBox(height: 14),
                  ...controller.pendingDevis.take(2).map((d) => _DevisTile(
                    devis: d,
                    onAccept: () => controller.acceptDevis(d.id),
                    onReject: () => controller.rejectDevis(d.id),
                  )).toList(),
                ],
              ]),
            )),
    );
  }
}

// ─── ARTISAN PROJECTS VIEW ────────────────────────────────────────────────────
class ArtisanProjectsView extends GetView<ArtisanController> {
  const ArtisanProjectsView({super.key});

  @override
  Widget build(BuildContext context) {
    return _ArtisanLayout(
      title: 'Projets & Devis',
      currentIndex: 1,
      child: DefaultTabController(
        length: 3,
        child: Column(children: [
          const TabBar(
            labelColor: AppColors.primary,
            unselectedLabelColor: AppColors.slate400,
            indicatorColor: AppColors.primary,
            labelStyle: TextStyle(fontWeight: FontWeight.w800, fontSize: 13),
            tabs: [Tab(text: 'En attente'), Tab(text: 'En cours'), Tab(text: 'Terminés')],
          ),
          Expanded(child: Obx(() => TabBarView(children: [
            _bookingList(controller.bookings.where((b) => b.status == 'pending').toList(), showActions: true),
            _bookingList(controller.bookings.where((b) => b.status == 'confirmed' || b.status == 'active').toList()),
            _bookingList(controller.bookings.where((b) => b.status == 'completed').toList()),
          ]))),
        ]),
      ),
    );
  }

  Widget _bookingList(List<BookingModel> list, {bool showActions = false}) {
    if (list.isEmpty) return const EmptyState(icon: Icons.folder_open_rounded, title: 'Aucun projet');
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: list.length,
      itemBuilder: (_, i) => _ProjectCard(
        booking: list[i],
        showActions: showActions,
        onAccept: () => controller.acceptDevis(list[i].id),
        onReject: () => controller.rejectDevis(list[i].id),
        onComplete: () => controller.markCompleted(list[i].id),
      ),
    );
  }
}

// ─── ARTISAN PRICING VIEW ─────────────────────────────────────────────────────
class ArtisanPricingView extends GetView<ArtisanController> {
  const ArtisanPricingView({super.key});

  @override
  Widget build(BuildContext context) {
    return _ArtisanLayout(
      title: 'Tarification',
      currentIndex: 2,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Hourly rate card
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.secondary, Color(0xFFE07020)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Tarif horaire actuel', style: TextStyle(
                color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w700,
              )),
              const SizedBox(height: 8),
              const Text('2 500 DA / heure', style: TextStyle(
                color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900,
              )),
              const SizedBox(height: 16),
              AppButton(
                label: 'Modifier le tarif', color: Colors.white,
                onTap: () => _showEditRate(context),
              ),
            ]),
          ),
          const SizedBox(height: 28),

          const SectionTitle(title: 'Mes formules de service'),
          const SizedBox(height: 16),
          _ServiceFormCard(title: 'Diagnostic', price: '1 000 DA', desc: 'Évaluation rapide du problème'),
          _ServiceFormCard(title: 'Intervention standard', price: '2 500 DA', desc: 'Réparation jusqu\'à 2h'),
          _ServiceFormCard(title: 'Intervention complète', price: '5 000 DA', desc: 'Travaux complexes + pièces'),
          const SizedBox(height: 16),
          AppButton(
            label: 'Ajouter une formule',
            width: double.infinity, isOutlined: true,
            icon: Icons.add_rounded, onTap: () {},
          ),
        ]),
      ),
    );
  }

  void _showEditRate(BuildContext context) {
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Modifier le tarif horaire', style: TextStyle(
            fontSize: 18, fontWeight: FontWeight.w900,
          )),
          const SizedBox(height: 20),
          AppTextField(
            label: 'Tarif horaire (DA)',
            controller: controller.hourlyRateCtrl,
            keyboardType: TextInputType.number,
            prefixIcon: Icons.payments_outlined,
          ),
          const SizedBox(height: 20),
          AppButton(label: 'Sauvegarder', width: double.infinity, onTap: () {
            Get.back();
            Get.snackbar('Tarif mis à jour', '', snackPosition: SnackPosition.BOTTOM,
                backgroundColor: AppColors.emerald500, colorText: Colors.white,
                margin: const EdgeInsets.all(16));
          }),
          const SizedBox(height: 12),
        ]),
      ),
    );
  }
}

// ─── ARTISAN MESSAGES VIEW ────────────────────────────────────────────────────
class ArtisanMessagesView extends GetView<ArtisanController> {
  const ArtisanMessagesView({super.key});

  @override
  Widget build(BuildContext context) {
    return _ArtisanLayout(
      title: 'Messages',
      currentIndex: 3,
      child: Obx(() => controller.conversations.isEmpty
          ? const EmptyState(icon: Icons.chat_bubble_outline_rounded, title: 'Aucune conversation')
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: controller.conversations.length,
              separatorBuilder: (_, __) => const Divider(height: 1, indent: 76),
              itemBuilder: (_, i) {
                final c = controller.conversations[i];
                return ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  leading: Stack(children: [
                    AvatarCircle(initials: c.initials, size: 50),
                    if (c.isOnline) Positioned(
                      bottom: 2, right: 2,
                      child: Container(
                        width: 12, height: 12,
                        decoration: BoxDecoration(
                          color: AppColors.emerald500, shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                      ),
                    ),
                  ]),
                  title: Text(c.otherUserName, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text(c.lastMessage, maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12, color: AppColors.slate400)),
                  trailing: Text(DateFormat('HH:mm').format(c.lastMessageAt),
                      style: const TextStyle(fontSize: 11, color: AppColors.slate400)),
                  onTap: () {},
                );
              },
            )),
    );
  }
}

// ─── ARTISAN VERIFICATIONS VIEW ───────────────────────────────────────────────
class ArtisanVerificationsView extends GetView<ArtisanController> {
  const ArtisanVerificationsView({super.key});

  @override
  Widget build(BuildContext context) {
    return _ArtisanLayout(
      title: 'Documents & Vérifications',
      currentIndex: 4,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          // Status banner
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppColors.emerald50,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.emerald500.withOpacity(0.3)),
            ),
            child: Row(children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.emerald500, borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.verified_rounded, color: Colors.white, size: 24),
              ),
              const SizedBox(width: 14),
              const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Compte Vérifié', style: TextStyle(
                  fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.emerald500,
                )),
                Text('Tous vos documents sont validés', style: TextStyle(
                  fontSize: 12, color: AppColors.emerald500,
                )),
              ]),
            ]),
          ),
          const SizedBox(height: 24),
          const SectionTitle(title: 'Mes documents'),
          const SizedBox(height: 16),
          _DocTile(title: 'Pièce d\'identité', status: 'verified', subtitle: 'CIN N°12345678'),
          _DocTile(title: 'Certification professionnelle', status: 'verified', subtitle: 'Cert. Nationale Artisanat'),
          _DocTile(title: 'Photo de profil', status: 'verified', subtitle: 'Photo uploadée'),
          _DocTile(title: 'Diplômes / Formations', status: 'pending', subtitle: 'En cours de vérification'),
          const SizedBox(height: 20),
          AppButton(
            label: 'Ajouter un document',
            width: double.infinity, icon: Icons.upload_file_rounded,
            onTap: () {},
          ),
        ]),
      ),
    );
  }
}

// ─── ARTISAN SETTINGS VIEW ────────────────────────────────────────────────────
class ArtisanSettingsView extends GetView<ArtisanController> {
  const ArtisanSettingsView({super.key});

  @override
  Widget build(BuildContext context) {
    return _ArtisanLayout(
      title: 'Paramètres',
      currentIndex: 5,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          // Profile card
          Obx(() => Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF0F172A), Color(0xFF1E293B)],
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(children: [
              AvatarCircle(
                initials: controller.currentUser.value?.initials ?? 'A',
                size: 52, color: AppColors.secondary,
              ),
              const SizedBox(width: 14),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(controller.currentUser.value?.name ?? '',
                    style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)),
                const Text('Artisan', style: TextStyle(
                  color: AppColors.secondary, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.5,
                )),
              ]),
            ]),
          )),
          const SizedBox(height: 24),
          const SectionTitle(title: 'Profil'),
          const SizedBox(height: 14),
          AppTextField(label: 'Nom', controller: controller.nameCtrl, prefixIcon: Icons.person_outline_rounded),
          const SizedBox(height: 14),
          AppTextField(label: 'Biographie', controller: controller.bioCtrl,
              hint: 'Parlez de vous...', maxLines: 3),
          const SizedBox(height: 14),
          AppTextField(label: 'Téléphone', controller: controller.phoneCtrl, prefixIcon: Icons.phone_outlined),
          const SizedBox(height: 14),
          AppTextField(label: 'Ville', controller: controller.cityCtrl, prefixIcon: Icons.location_city_rounded),
          const SizedBox(height: 20),
          AppButton(label: 'Sauvegarder', width: double.infinity, onTap: () {
            Get.snackbar('Succès', 'Profil mis à jour',
                backgroundColor: AppColors.emerald500, colorText: Colors.white,
                snackPosition: SnackPosition.BOTTOM, margin: const EdgeInsets.all(16));
          }),
          const SizedBox(height: 24),
          const SectionTitle(title: 'Disponibilité'),
          const SizedBox(height: 12),
          Obx(() => Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white, borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.slate100),
            ),
            child: Row(children: [
              const Icon(Icons.schedule_rounded, color: AppColors.primary),
              const SizedBox(width: 12),
              const Expanded(child: Text('Disponible pour de nouvelles missions',
                  style: TextStyle(fontWeight: FontWeight.w700))),
              Switch(
                value: controller.isAvailable.value,
                onChanged: (v) => controller.isAvailable.value = v,
                activeColor: AppColors.primary,
              ),
            ]),
          )),
          const SizedBox(height: 24),
          AppButton(
            label: 'Déconnexion', onTap: controller.logout,
            isOutlined: true, color: AppColors.red500,
            width: double.infinity, icon: Icons.logout_rounded,
          ),
        ]),
      ),
    );
  }
}

// ─── SHARED ARTISAN WIDGETS ───────────────────────────────────────────────────
class _DevisTile extends StatelessWidget {
  final BookingModel devis;
  final VoidCallback onAccept;
  final VoidCallback onReject;
  const _DevisTile({required this.devis, required this.onAccept, required this.onReject});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(18),
      border: Border.all(color: AppColors.amber500.withOpacity(0.2)),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Expanded(child: Text(devis.serviceTitle, style: const TextStyle(
          fontSize: 14, fontWeight: FontWeight.w800,
        ))),
        Text('${devis.totalPrice.toInt()} DA', style: const TextStyle(
          fontSize: 14, fontWeight: FontWeight.w900, color: AppColors.secondary,
        )),
      ]),
      const SizedBox(height: 4),
      Text(devis.clientName, style: const TextStyle(fontSize: 12, color: AppColors.slate400)),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: AppButton(
          label: 'Accepter', isSmall: true, color: AppColors.emerald500, onTap: onAccept,
        )),
        const SizedBox(width: 8),
        Expanded(child: AppButton(
          label: 'Refuser', isSmall: true, isOutlined: true, color: AppColors.red500, onTap: onReject,
        )),
      ]),
    ]),
  );
}

class _ProjectCard extends StatelessWidget {
  final BookingModel booking;
  final bool showActions;
  final VoidCallback? onAccept;
  final VoidCallback? onReject;
  final VoidCallback? onComplete;
  const _ProjectCard({required this.booking, this.showActions = false,
    this.onAccept, this.onReject, this.onComplete});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(18),
      border: Border.all(color: AppColors.slate100),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Expanded(child: Text(booking.serviceTitle, style: const TextStyle(
          fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.slate900,
        ))),
        StatusBadge(status: booking.status),
      ]),
      const SizedBox(height: 6),
      Text(booking.clientName, style: const TextStyle(fontSize: 12, color: AppColors.slate400)),
      const SizedBox(height: 6),
      Row(children: [
        const Icon(Icons.calendar_today_rounded, size: 13, color: AppColors.slate400),
        const SizedBox(width: 4),
        Text(DateFormat('dd/MM/yyyy').format(booking.bookingDate),
            style: const TextStyle(fontSize: 12, color: AppColors.slate400)),
        const Spacer(),
        Text('${booking.totalPrice.toInt()} DA', style: const TextStyle(
          fontSize: 14, fontWeight: FontWeight.w900, color: AppColors.secondary,
        )),
      ]),
      if (showActions) ...[
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: AppButton(label: 'Accepter', isSmall: true,
              color: AppColors.emerald500, onTap: onAccept)),
          const SizedBox(width: 8),
          Expanded(child: AppButton(label: 'Refuser', isSmall: true,
              isOutlined: true, color: AppColors.red500, onTap: onReject)),
        ]),
      ] else if (booking.status == 'active' || booking.status == 'confirmed') ...[
        const SizedBox(height: 12),
        AppButton(label: 'Marquer terminé', isSmall: true,
            color: AppColors.blue500, width: double.infinity, onTap: onComplete),
      ],
    ]),
  );
}

class _ServiceFormCard extends StatelessWidget {
  final String title, price, desc;
  const _ServiceFormCard({required this.title, required this.price, required this.desc});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(16),
      border: Border.all(color: AppColors.slate100),
    ),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
        const SizedBox(height: 2),
        Text(desc, style: const TextStyle(fontSize: 12, color: AppColors.slate400)),
      ])),
      Text(price, style: const TextStyle(
        fontSize: 14, fontWeight: FontWeight.w900, color: AppColors.secondary,
      )),
      const SizedBox(width: 8),
      const Icon(Icons.edit_outlined, color: AppColors.slate400, size: 18),
    ]),
  );
}

class _DocTile extends StatelessWidget {
  final String title, status, subtitle;
  const _DocTile({required this.title, required this.status, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    final isVerified = status == 'verified';
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.slate100),
      ),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: isVerified ? AppColors.emerald50 : AppColors.amber50,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(
            isVerified ? Icons.check_circle_rounded : Icons.hourglass_empty_rounded,
            color: isVerified ? AppColors.emerald500 : AppColors.amber500,
            size: 20,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
          Text(subtitle, style: const TextStyle(fontSize: 11, color: AppColors.slate400)),
        ])),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: isVerified ? AppColors.emerald50 : AppColors.amber50,
            borderRadius: BorderRadius.circular(100),
          ),
          child: Text(isVerified ? 'Vérifié' : 'En attente',
              style: TextStyle(
                fontSize: 10, fontWeight: FontWeight.w900,
                color: isVerified ? AppColors.emerald500 : AppColors.amber500,
              )),
        ),
      ]),
    );
  }
}
