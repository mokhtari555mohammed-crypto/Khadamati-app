import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/theme/app_theme.dart';
import '../../../app/routes/app_routes.dart';
import '../../../core/models/app_models.dart';
import '../../../shared/widgets/app_widgets.dart';
import '../controllers/search_controller.dart' as sc;

// ─── FIND EXPERT VIEW ─────────────────────────────────────────────────────────
class FindExpertView extends GetView<sc.SearchController> {
  const FindExpertView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.slate50,
      appBar: AppBar(
        backgroundColor: AppColors.slate50,
        title: const Text('Trouver un Expert'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => Get.back(),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.tune_rounded, color: AppColors.primary),
            onPressed: () => _showFilters(context),
          ),
        ],
      ),
      body: Column(children: [
        // Search bar
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: TextField(
            controller: controller.searchCtrl,
            decoration: InputDecoration(
              hintText: 'search'.tr,
              prefixIcon: const Icon(Icons.search_rounded, color: AppColors.primary),
              filled: true, fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: AppColors.slate100),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: AppColors.slate100),
              ),
            ),
          ),
        ),
        // Category chips
        SizedBox(
          height: 44,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: [
              Obx(() => _chip('Tous', '', controller.selectedCategory.value == '')),
              ...MockData.categories.take(8).map((c) => Obx(() =>
                  _chip(c.name.split(' ').first, c.name,
                      controller.selectedCategory.value == c.name))),
            ],
          ),
        ),
        const SizedBox(height: 8),
        // Results count
        Obx(() => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Row(children: [
            Text(
              '${controller.filtered.length} ${'results'.tr}',
              style: const TextStyle(
                fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.slate500,
              ),
            ),
          ]),
        )),
        // Artisan list
        Expanded(
          child: Obx(() {
            if (controller.isLoading.value) {
              return const Center(child: CircularProgressIndicator());
            }
            if (controller.filtered.isEmpty) {
              return EmptyState(
                icon: Icons.search_off_rounded,
                title: 'no_experts_found'.tr,
                subtitle: 'Essayez d\'autres critères de recherche.',
                actionLabel: 'reset_filters'.tr,
                onAction: controller.resetFilters,
              );
            }
            return ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: controller.filtered.length,
              itemBuilder: (_, i) => ArtisanCard(artisan: controller.filtered[i]),
            );
          }),
        ),
      ]),
    );
  }

  Widget _chip(String label, String value, bool selected) => GestureDetector(
    onTap: () {
      controller.selectedCategory.value = value;
      controller.applyFilters();
    },
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: selected ? AppColors.primary : Colors.white,
        borderRadius: BorderRadius.circular(100),
        border: Border.all(color: selected ? AppColors.primary : AppColors.slate200 ?? AppColors.slate300),
      ),
      child: Text(label, style: TextStyle(
        fontSize: 12, fontWeight: FontWeight.w800,
        color: selected ? Colors.white : AppColors.slate500,
      )),
    ),
  );

  void _showFilters(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => _FiltersSheet(controller: controller),
    );
  }
}

// ─── FILTERS SHEET ────────────────────────────────────────────────────────────
class _FiltersSheet extends StatelessWidget {
  final sc.SearchController controller;
  const _FiltersSheet({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Filtres', style: TextStyle(
            fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.slate900,
          )),
          IconButton(onPressed: () => Get.back(), icon: const Icon(Icons.close_rounded)),
        ]),
        const SizedBox(height: 20),
        const Text('NOTE MINIMALE', style: TextStyle(
          fontSize: 11, fontWeight: FontWeight.w900,
          color: AppColors.slate400, letterSpacing: 1.5,
        )),
        Obx(() => Slider(
          value: controller.minRating.value,
          max: 5, divisions: 10,
          activeColor: AppColors.primary,
          label: '${controller.minRating.value}★',
          onChanged: (v) => controller.minRating.value = v,
        )),
        const SizedBox(height: 8),
        Obx(() => SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Disponibles uniquement',
              style: TextStyle(fontWeight: FontWeight.w700)),
          value: controller.onlyAvailable.value,
          activeColor: AppColors.primary,
          onChanged: (v) => controller.onlyAvailable.value = v,
        )),
        Obx(() => SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Vérifiés uniquement',
              style: TextStyle(fontWeight: FontWeight.w700)),
          value: controller.onlyVerified.value,
          activeColor: AppColors.primary,
          onChanged: (v) => controller.onlyVerified.value = v,
        )),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: AppButton(
            label: 'Réinitialiser',
            onTap: () { controller.resetFilters(); Get.back(); },
            isOutlined: true,
          )),
          const SizedBox(width: 12),
          Expanded(child: AppButton(
            label: 'Appliquer',
            onTap: () { controller.applyFilters(); Get.back(); },
          )),
        ]),
        const SizedBox(height: 8),
      ]),
    );
  }
}

// ─── ARTISAN PROFILE VIEW ─────────────────────────────────────────────────────
class ArtisanProfileView extends GetView<sc.SearchController> {
  const ArtisanProfileView({super.key});

  @override
  Widget build(BuildContext context) {
    final id = int.tryParse(Get.parameters['id'] ?? '') ?? 1;
    controller.selectArtisan(id);

    return Obx(() {
      final artisan = controller.selectedArtisan.value
          ?? MockData.artisans.firstWhere((a) => a.id == id, orElse: () => MockData.artisans.first);
      final isFav = controller.isFavorite(artisan.id);

      return Scaffold(
        backgroundColor: Colors.white,
        body: CustomScrollView(
          slivers: [
            // Header
            SliverAppBar(
              expandedHeight: 220,
              floating: false,
              pinned: true,
              backgroundColor: AppColors.primary,
              leading: IconButton(
                icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
                onPressed: () => Get.back(),
              ),
              actions: [
                IconButton(
                  icon: Icon(
                    isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    color: isFav ? AppColors.red500 : Colors.white,
                  ),
                  onPressed: () => controller.toggleFavorite(artisan.id),
                ),
              ],
              flexibleSpace: FlexibleSpaceBar(
                background: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [AppColors.primary, Color(0xFF0066CC)],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ),
                  ),
                  child: SafeArea(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 40),
                        Container(
                          width: 80, height: 80,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(color: Colors.white.withOpacity(0.4), width: 2),
                          ),
                          alignment: Alignment.center,
                          child: Text(artisan.initials, style: const TextStyle(
                            color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900,
                          )),
                        ),
                        const SizedBox(height: 12),
                        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Text(artisan.name, style: const TextStyle(
                            color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900,
                          )),
                          if (artisan.isVerified) ...[
                            const SizedBox(width: 6),
                            const Icon(Icons.verified_rounded, color: Colors.white, size: 18),
                          ],
                        ]),
                        const SizedBox(height: 4),
                        Text(artisan.specialty, style: TextStyle(
                          color: Colors.white.withOpacity(0.8), fontSize: 13,
                          fontWeight: FontWeight.w600,
                        )),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            // Stats bar
            SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 8, offset: const Offset(0, 4),
                  )],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _mini('★ ${artisan.rating}', '${artisan.reviewCount} avis'),
                    _divider(),
                    _mini('${artisan.yearsExperience}', 'ans exp.'),
                    _divider(),
                    _mini('${artisan.projectsDone}', 'projets'),
                    _divider(),
                    _mini(artisan.isAvailable ? 'Oui' : 'Non', 'Dispo.',
                        color: artisan.isAvailable ? AppColors.emerald500 : AppColors.red500),
                  ],
                ),
              ),
            ),

            // Body
            SliverPadding(
              padding: const EdgeInsets.all(20),
              sliver: SliverList(delegate: SliverChildListDelegate([
                // Location
                Row(children: [
                  const Icon(Icons.location_on_outlined, color: AppColors.primary, size: 18),
                  const SizedBox(width: 6),
                  Text(artisan.city, style: const TextStyle(
                    fontWeight: FontWeight.w700, color: AppColors.slate700,
                  )),
                  const SizedBox(width: 16),
                  const Icon(Icons.access_time_rounded, color: AppColors.slate400, size: 16),
                  const SizedBox(width: 4),
                  Text('Répond en ${artisan.responseTime ?? '< 2h'}',
                      style: const TextStyle(fontSize: 12, color: AppColors.slate400)),
                ]),
                const SizedBox(height: 20),

                // Bio
                if (artisan.bio != null) ...[
                  const Text('À propos', style: TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.slate900,
                  )),
                  const SizedBox(height: 8),
                  Text(artisan.bio!, style: const TextStyle(
                    fontSize: 14, color: AppColors.slate500, height: 1.7,
                  )),
                  const SizedBox(height: 20),
                ],

                // Certifications
                if (artisan.certifications.isNotEmpty) ...[
                  const Text('Certifications', style: TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.slate900,
                  )),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8, runSpacing: 8,
                    children: artisan.certifications.map((c) => Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppColors.emerald50,
                        borderRadius: BorderRadius.circular(100),
                        border: Border.all(color: AppColors.emerald500.withOpacity(0.3)),
                      ),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.workspace_premium_rounded,
                            color: AppColors.emerald500, size: 14),
                        const SizedBox(width: 6),
                        Text(c, style: const TextStyle(
                          fontSize: 12, fontWeight: FontWeight.w700,
                          color: AppColors.emerald500,
                        )),
                      ]),
                    )).toList(),
                  ),
                  const SizedBox(height: 20),
                ],

                // Reviews section
                const Text('Avis clients', style: TextStyle(
                  fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.slate900,
                )),
                const SizedBox(height: 12),
                ...MockData.reviews.map((r) => _ReviewTile(review: r)).toList(),

                // Pricing
                if (artisan.hourlyRate != null) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFFF3E0), Color(0xFFFFF8F0)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.secondary.withOpacity(0.2)),
                    ),
                    child: Row(children: [
                      const Icon(Icons.payments_outlined, color: AppColors.secondary),
                      const SizedBox(width: 12),
                      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('Tarif horaire', style: TextStyle(
                          fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.slate400,
                        )),
                        Text('${artisan.hourlyRate!.toInt()} DA / heure',
                            style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w900, color: AppColors.secondary,
                            )),
                      ]),
                    ]),
                  ),
                ],

                const SizedBox(height: 100),
              ])),
            ),
          ],
        ),

        // Bottom action bar
        bottomNavigationBar: Container(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 16, offset: const Offset(0, -4),
            )],
          ),
          child: Row(children: [
            Expanded(child: AppButton(
              label: 'Contacter',
              isOutlined: true,
              icon: Icons.chat_outlined,
              onTap: () => Get.toNamed(AppRoutes.CLIENT_MESSAGES),
            )),
            const SizedBox(width: 12),
            Expanded(child: AppButton(
              label: 'Demander un devis',
              icon: Icons.request_quote_rounded,
              onTap: () => Get.toNamed(AppRoutes.REQUEST_QUOTE,
                  parameters: {'artisanId': artisan.id.toString(), 'artisanName': artisan.name}),
            )),
          ]),
        ),
      );
    });
  }

  Widget _mini(String value, String label, {Color? color}) => Column(children: [
    Text(value, style: TextStyle(
      fontSize: 16, fontWeight: FontWeight.w900,
      color: color ?? AppColors.slate900,
    )),
    Text(label, style: const TextStyle(
      fontSize: 10, color: AppColors.slate400, fontWeight: FontWeight.w600,
    )),
  ]);

  Widget _divider() => Container(
    height: 32, width: 1, color: AppColors.slate100,
  );
}

class _ReviewTile extends StatelessWidget {
  final dynamic review;
  const _ReviewTile({required this.review});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.slate50,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          AvatarCircle(initials: review.clientName[0], size: 36),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(review.clientName, style: const TextStyle(
              fontWeight: FontWeight.w800, fontSize: 13, color: AppColors.slate900,
            )),
            Row(children: List.generate(5, (i) => Icon(
              i < review.rating.round() ? Icons.star_rounded : Icons.star_border_rounded,
              color: AppColors.secondary, size: 13,
            ))),
          ])),
        ]),
        const SizedBox(height: 8),
        Text(review.comment, style: const TextStyle(
          fontSize: 13, color: AppColors.slate500, height: 1.5,
        )),
      ]),
    );
  }
}
