import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/models/app_models.dart';

class SearchController extends GetxController {
  final allArtisans = <ArtisanModel>[].obs;
  final filtered = <ArtisanModel>[].obs;
  final searchCtrl = TextEditingController();
  final isLoading = false.obs;
  final selectedCategory = ''.obs;
  final maxPrice = 10000.0.obs;
  final minRating = 0.0.obs;
  final onlyAvailable = false.obs;
  final onlyVerified = false.obs;
  final selectedArtisan = Rxn<ArtisanModel>();
  final favorites = <int>{}.obs;

  @override
  void onInit() {
    super.onInit();
    // Check if category param passed
    final cat = Get.parameters['category'] ?? '';
    selectedCategory.value = cat;
    _loadArtisans();
    debounce(searchCtrl.obs, (_) => _applyFilters(),
        time: const Duration(milliseconds: 300));
  }

  void _loadArtisans() {
    isLoading.value = true;
    Future.delayed(const Duration(milliseconds: 600), () {
      allArtisans.assignAll(MockData.artisans);
      _applyFilters();
      isLoading.value = false;
    });
  }

  void _applyFilters() {
    filtered.assignAll(allArtisans.where((a) {
      final q = searchCtrl.text.toLowerCase();
      final matchSearch = q.isEmpty ||
          a.name.toLowerCase().contains(q) ||
          a.specialty.toLowerCase().contains(q) ||
          a.city.toLowerCase().contains(q);
      final matchCat = selectedCategory.value.isEmpty ||
          a.specialty.toLowerCase().contains(selectedCategory.value.toLowerCase());
      final matchPrice = a.hourlyRate == null || a.hourlyRate! <= maxPrice.value;
      final matchRating = a.rating >= minRating.value;
      final matchAvailable = !onlyAvailable.value || a.isAvailable;
      final matchVerified = !onlyVerified.value || a.isVerified;
      return matchSearch && matchCat && matchPrice && matchRating && matchAvailable && matchVerified;
    }).toList());
  }

  void applyFilters() => _applyFilters();
  void resetFilters() {
    maxPrice.value = 10000;
    minRating.value = 0;
    onlyAvailable.value = false;
    onlyVerified.value = false;
    selectedCategory.value = '';
    _applyFilters();
  }

  void selectArtisan(int id) {
    selectedArtisan.value = allArtisans.firstWhereOrNull((a) => a.id == id);
  }

  void toggleFavorite(int id) {
    if (favorites.contains(id)) {
      favorites.remove(id);
    } else {
      favorites.add(id);
    }
  }

  bool isFavorite(int id) => favorites.contains(id);

  @override
  void onClose() {
    searchCtrl.dispose();
    super.onClose();
  }
}
