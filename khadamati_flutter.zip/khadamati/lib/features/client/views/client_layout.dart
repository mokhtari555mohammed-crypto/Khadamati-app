import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/theme/app_theme.dart';
import '../../../app/routes/app_routes.dart';
import '../../../shared/widgets/app_widgets.dart';
import '../controllers/client_controller.dart';

class ClientLayout extends GetView<ClientController> {
  final Widget child;
  final String title;
  final int currentIndex;
  final List<Widget>? actions;

  const ClientLayout({
    super.key,
    required this.child,
    required this.title,
    required this.currentIndex,
    this.actions,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          ...?actions,
          IconButton(
            icon: const Icon(Icons.notifications_none_rounded),
            onPressed: () {},
          ),
        ],
        leading: Builder(builder: (ctx) => IconButton(
          icon: const Icon(Icons.menu_rounded),
          onPressed: () => Scaffold.of(ctx).openDrawer(),
        )),
      ),
      drawer: _buildDrawer(),
      bottomNavigationBar: _buildBottomNav(),
      body: child,
    );
  }

  Widget _buildDrawer() => Drawer(
    child: Column(children: [
      Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(24, 56, 24, 28),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [AppColors.primary, Color(0xFF0066CC)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
        ),
        child: Obx(() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          AvatarCircle(
            initials: controller.currentUser.value?.initials ?? 'U',
            size: 60,
            color: Colors.white.withOpacity(0.3),
          ),
          const SizedBox(height: 12),
          Text(
            controller.currentUser.value?.name ?? 'Client',
            style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900),
          ),
          Text(
            controller.currentUser.value?.email ?? '',
            style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 13),
          ),
        ])),
      ),
      Expanded(child: ListView(padding: const EdgeInsets.all(12), children: [
        _drawerItem(Icons.inbox_rounded, 'inbox'.tr, AppRoutes.CLIENT_INBOX, 0),
        _drawerItem(Icons.folder_open_rounded, 'my_projects'.tr, AppRoutes.CLIENT_PROJECTS, 1),
        _drawerItem(Icons.chat_bubble_outline_rounded, 'messages'.tr, AppRoutes.CLIENT_MESSAGES, 2),
        _drawerItem(Icons.favorite_border_rounded, 'favorites'.tr, AppRoutes.CLIENT_FAVORITES, 3),
        const Divider(height: 20),
        _drawerItem(Icons.search_rounded, 'find_expert'.tr, AppRoutes.FIND_EXPERT, -1),
        _drawerItem(Icons.home_rounded, 'Accueil public', AppRoutes.HOME, -1),
        const Divider(height: 20),
        _drawerItem(Icons.settings_outlined, 'settings'.tr, AppRoutes.CLIENT_SETTINGS, 4),
      ])),
      Padding(
        padding: const EdgeInsets.all(16),
        child: AppButton(
          label: 'logout'.tr,
          onTap: controller.logout,
          isOutlined: true,
          color: AppColors.red500,
          width: double.infinity,
          icon: Icons.logout_rounded,
        ),
      ),
    ]),
  );

  Widget _drawerItem(IconData icon, String label, String route, int index) {
    final isActive = currentIndex == index;
    return ListTile(
      leading: Icon(icon,
          color: isActive ? AppColors.primary : AppColors.slate400, size: 22),
      title: Text(label, style: TextStyle(
        fontWeight: FontWeight.w700,
        color: isActive ? AppColors.primary : AppColors.slate700,
      )),
      tileColor: isActive ? AppColors.primaryLight : null,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      onTap: () {
        Get.back();
        if (route != Get.currentRoute) Get.offNamed(route);
      },
    );
  }

  Widget _buildBottomNav() => NavigationBar(
    selectedIndex: currentIndex.clamp(0, 4),
    onDestinationSelected: (i) {
      const routes = [
        AppRoutes.CLIENT_INBOX,
        AppRoutes.CLIENT_PROJECTS,
        AppRoutes.CLIENT_MESSAGES,
        AppRoutes.CLIENT_FAVORITES,
        AppRoutes.CLIENT_SETTINGS,
      ];
      if (i < routes.length) Get.offNamed(routes[i]);
    },
    backgroundColor: Colors.white,
    indicatorColor: AppColors.primaryLight,
    destinations: const [
      NavigationDestination(icon: Icon(Icons.inbox_outlined), selectedIcon: Icon(Icons.inbox_rounded), label: 'Accueil'),
      NavigationDestination(icon: Icon(Icons.folder_outlined), selectedIcon: Icon(Icons.folder_rounded), label: 'Projets'),
      NavigationDestination(icon: Icon(Icons.chat_bubble_outline_rounded), selectedIcon: Icon(Icons.chat_bubble_rounded), label: 'Messages'),
      NavigationDestination(icon: Icon(Icons.favorite_border_rounded), selectedIcon: Icon(Icons.favorite_rounded), label: 'Favoris'),
      NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: 'Réglages'),
    ],
  );
}
