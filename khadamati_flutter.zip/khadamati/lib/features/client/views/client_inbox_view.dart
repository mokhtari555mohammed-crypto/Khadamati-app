import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../../app/theme/app_theme.dart';
import '../../../app/routes/app_routes.dart';
import '../../../core/models/app_models.dart';
import '../../../shared/widgets/app_widgets.dart';
import '../controllers/client_controller.dart';
import 'client_layout.dart';

// ─── CLIENT INBOX (DASHBOARD HOME) ───────────────────────────────────────────
class ClientInboxView extends GetView<ClientController> {
  const ClientInboxView({super.key});

  @override
  Widget build(BuildContext context) {
    return ClientLayout(
      title: 'Tableau de bord',
      currentIndex: 0,
      child: Obx(() => controller.isLoading.value
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () async {},
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(20),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  // Welcome header
                  Text(
                    'Bonjour, ${controller.currentUser.value?.name.split(' ').first ?? 'Client'} 👋',
                    style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.w900, color: AppColors.slate900,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text('Voici un aperçu de vos activités',
                      style: TextStyle(color: AppColors.slate400, fontSize: 13)),
                  const SizedBox(height: 24),

                  // Stats
                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 2, childAspectRatio: 1.4,
                    crossAxisSpacing: 12, mainAxisSpacing: 12,
                    children: [
                      StatCard(title: 'Total demandes', value: '${controller.totalBookings}',
                          icon: Icons.assignment_outlined, color: AppColors.primary),
                      StatCard(title: 'En attente', value: '${controller.pendingBookings}',
                          icon: Icons.hourglass_empty_rounded, color: AppColors.amber500),
                      StatCard(title: 'En cours', value: '${controller.activeBookings}',
                          icon: Icons.build_circle_outlined, color: AppColors.blue500),
                      StatCard(title: 'Terminés', value: '${controller.completedBookings}',
                          icon: Icons.check_circle_outline_rounded, color: AppColors.emerald500),
                    ],
                  ),
                  const SizedBox(height: 28),

                  // Quick actions
                  SectionTitle(
                    title: 'Actions rapides',
                    action: 'Voir tout',
                    onAction: () => Get.toNamed(AppRoutes.FIND_EXPERT),
                  ),
                  const SizedBox(height: 14),
                  Row(children: [
                    Expanded(child: _QuickAction(
                      icon: Icons.search_rounded, label: 'Trouver\nun artisan',
                      color: AppColors.primary,
                      onTap: () => Get.toNamed(AppRoutes.FIND_EXPERT),
                    )),
                    const SizedBox(width: 12),
                    Expanded(child: _QuickAction(
                      icon: Icons.request_quote_rounded, label: 'Demander\nun devis',
                      color: AppColors.secondary,
                      onTap: () => Get.toNamed(AppRoutes.REQUEST_QUOTE),
                    )),
                    const SizedBox(width: 12),
                    Expanded(child: _QuickAction(
                      icon: Icons.chat_bubble_outline_rounded, label: 'Mes\nmessages',
                      color: AppColors.emerald500,
                      onTap: () => Get.toNamed(AppRoutes.CLIENT_MESSAGES),
                    )),
                  ]),
                  const SizedBox(height: 28),

                  // Recent bookings
                  SectionTitle(
                    title: 'Demandes récentes',
                    action: 'Voir tout',
                    onAction: () => Get.toNamed(AppRoutes.CLIENT_PROJECTS),
                  ),
                  const SizedBox(height: 14),
                  ...controller.bookings.take(3)
                      .map((b) => _BookingTile(booking: b)).toList(),
                ]),
              ),
            )),
    );
  }
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _QuickAction({required this.icon, required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withOpacity(0.15)),
      ),
      child: Column(children: [
        Icon(icon, color: color, size: 28),
        const SizedBox(height: 8),
        Text(label, textAlign: TextAlign.center, style: TextStyle(
          fontSize: 11, fontWeight: FontWeight.w800, color: color, height: 1.3,
        )),
      ]),
    ),
  );
}

// ─── CLIENT PROJECTS VIEW ─────────────────────────────────────────────────────
class ClientProjectsView extends GetView<ClientController> {
  const ClientProjectsView({super.key});

  @override
  Widget build(BuildContext context) {
    return ClientLayout(
      title: 'my_projects'.tr,
      currentIndex: 1,
      child: Obx(() {
        if (controller.isLoading.value) return const Center(child: CircularProgressIndicator());
        if (controller.bookings.isEmpty) {
          return EmptyState(
            icon: Icons.folder_open_rounded,
            title: 'Aucun projet',
            subtitle: 'Vous n\'avez pas encore de projets.',
            actionLabel: 'Trouver un artisan',
            onAction: () => Get.toNamed(AppRoutes.FIND_EXPERT),
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.all(20),
          itemCount: controller.bookings.length,
          itemBuilder: (_, i) => _BookingTile(booking: controller.bookings[i], expanded: true),
        );
      }),
    );
  }
}

// ─── CLIENT MESSAGES VIEW ─────────────────────────────────────────────────────
class ClientMessagesView extends GetView<ClientController> {
  const ClientMessagesView({super.key});

  @override
  Widget build(BuildContext context) {
    return ClientLayout(
      title: 'messages'.tr,
      currentIndex: 2,
      child: Obx(() {
        if (controller.conversations.isEmpty) {
          return const EmptyState(
            icon: Icons.chat_bubble_outline_rounded,
            title: 'Aucune conversation',
            subtitle: 'Contactez un artisan pour commencer.',
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: controller.conversations.length,
          separatorBuilder: (_, __) => const Divider(height: 1, indent: 76),
          itemBuilder: (_, i) => _ConversationTile(conv: controller.conversations[i]),
        );
      }),
    );
  }
}

// ─── CLIENT FAVORITES VIEW ────────────────────────────────────────────────────
class ClientFavoritesView extends GetView<ClientController> {
  const ClientFavoritesView({super.key});

  @override
  Widget build(BuildContext context) {
    return ClientLayout(
      title: 'favorites'.tr,
      currentIndex: 3,
      child: Obx(() {
        if (controller.favorites.isEmpty) {
          return EmptyState(
            icon: Icons.favorite_border_rounded,
            title: 'Aucun favori',
            subtitle: 'Ajoutez des artisans à vos favoris.',
            actionLabel: 'Explorer',
            onAction: () => Get.toNamed(AppRoutes.FIND_EXPERT),
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.all(20),
          itemCount: controller.favorites.length,
          itemBuilder: (_, i) => ArtisanCard(artisan: controller.favorites[i]),
        );
      }),
    );
  }
}

// ─── CLIENT SETTINGS VIEW ─────────────────────────────────────────────────────
class ClientSettingsView extends GetView<ClientController> {
  const ClientSettingsView({super.key});

  @override
  Widget build(BuildContext context) {
    return ClientLayout(
      title: 'settings'.tr,
      currentIndex: 4,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          // Profile card
          Obx(() => Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.primary, Color(0xFF0066CC)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Row(children: [
              AvatarCircle(
                initials: controller.currentUser.value?.initials ?? 'U',
                size: 56, color: Colors.white.withOpacity(0.3),
              ),
              const SizedBox(width: 16),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(controller.currentUser.value?.name ?? '',
                    style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
                Text(controller.currentUser.value?.email ?? '',
                    style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 13)),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(100),
                  ),
                  child: const Text('CLIENT', style: TextStyle(
                    color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1.5,
                  )),
                ),
              ]),
            ]),
          )),
          const SizedBox(height: 28),

          // Profile form
          const SectionTitle(title: 'Informations personnelles'),
          const SizedBox(height: 16),
          AppTextField(label: 'Nom complet', controller: controller.nameCtrl,
              prefixIcon: Icons.person_outline_rounded),
          const SizedBox(height: 16),
          AppTextField(label: 'Téléphone', controller: controller.phoneCtrl,
              prefixIcon: Icons.phone_outlined),
          const SizedBox(height: 16),
          AppTextField(label: 'Ville', controller: controller.cityCtrl,
              prefixIcon: Icons.location_city_rounded),
          const SizedBox(height: 20),
          AppButton(label: 'Sauvegarder', width: double.infinity, onTap: () {
            Get.snackbar('Succès', 'Profil mis à jour',
                snackPosition: SnackPosition.BOTTOM,
                backgroundColor: AppColors.emerald500,
                colorText: Colors.white, margin: const EdgeInsets.all(16));
          }),
          const SizedBox(height: 28),

          // Language
          const SectionTitle(title: 'Langue'),
          const SizedBox(height: 12),
          _SettingTile(
            icon: Icons.language_rounded, label: 'Changer de langue',
            subtitle: Get.locale?.languageCode == 'ar' ? 'العربية' : 'Français',
            onTap: () {
              final current = Get.locale?.languageCode ?? 'fr';
              final next = current == 'fr' ? 'ar' : 'fr';
              Get.updateLocale(Locale(next, next == 'ar' ? 'AR' : 'FR'));
            },
          ),
          const SizedBox(height: 28),

          // More
          const SectionTitle(title: 'Aide & Informations'),
          const SizedBox(height: 12),
          _SettingTile(icon: Icons.help_outline_rounded, label: 'Aide & FAQ'),
          _SettingTile(icon: Icons.info_outline_rounded, label: 'À propos',
              onTap: () => Get.toNamed(AppRoutes.ABOUT_US)),
          _SettingTile(icon: Icons.privacy_tip_outlined, label: 'Confidentialité'),
          const SizedBox(height: 24),

          AppButton(
            label: 'logout'.tr,
            onTap: controller.logout,
            isOutlined: true,
            color: AppColors.red500,
            width: double.infinity,
            icon: Icons.logout_rounded,
          ),
        ]),
      ),
    );
  }
}

// ─── SHARED WIDGETS ───────────────────────────────────────────────────────────
class _BookingTile extends StatelessWidget {
  final BookingModel booking;
  final bool expanded;
  const _BookingTile({required this.booking, this.expanded = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.slate100),
        boxShadow: [BoxShadow(
          color: Colors.black.withOpacity(0.03),
          blurRadius: 12, offset: const Offset(0, 4),
        )],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(booking.serviceTitle, style: const TextStyle(
            fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.slate900,
          ))),
          StatusBadge(status: booking.status),
        ]),
        if (booking.artisanName != null) ...[
          const SizedBox(height: 6),
          Row(children: [
            const Icon(Icons.person_outline_rounded, size: 14, color: AppColors.slate400),
            const SizedBox(width: 4),
            Text(booking.artisanName!, style: const TextStyle(
              fontSize: 12, color: AppColors.slate400, fontWeight: FontWeight.w600,
            )),
          ]),
        ],
        const SizedBox(height: 8),
        Row(children: [
          const Icon(Icons.calendar_today_rounded, size: 13, color: AppColors.slate400),
          const SizedBox(width: 4),
          Text(
            DateFormat('dd/MM/yyyy').format(booking.bookingDate),
            style: const TextStyle(fontSize: 12, color: AppColors.slate400),
          ),
          const Spacer(),
          Text('${booking.totalPrice.toInt()} DA',
              style: const TextStyle(
                fontSize: 14, fontWeight: FontWeight.w900, color: AppColors.secondary,
              )),
        ]),
      ]),
    );
  }
}

class _ConversationTile extends StatelessWidget {
  final ConversationModel conv;
  const _ConversationTile({required this.conv});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      leading: Stack(
        children: [
          AvatarCircle(initials: conv.initials, size: 50),
          if (conv.isOnline) Positioned(
            bottom: 2, right: 2,
            child: Container(
              width: 12, height: 12,
              decoration: BoxDecoration(
                color: AppColors.emerald500, shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
            ),
          ),
        ],
      ),
      title: Row(children: [
        Expanded(child: Text(conv.otherUserName, style: const TextStyle(
          fontWeight: FontWeight.w800, fontSize: 14,
        ))),
        Text(
          _formatTime(conv.lastMessageAt),
          style: TextStyle(
            fontSize: 11, fontWeight: FontWeight.w600,
            color: conv.unreadCount > 0 ? AppColors.primary : AppColors.slate400,
          ),
        ),
      ]),
      subtitle: Row(children: [
        Expanded(child: Text(
          conv.lastMessage,
          maxLines: 1, overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 12, fontWeight: conv.unreadCount > 0 ? FontWeight.w700 : FontWeight.w500,
            color: conv.unreadCount > 0 ? AppColors.slate700 : AppColors.slate400,
          ),
        )),
        if (conv.unreadCount > 0) Container(
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
          decoration: BoxDecoration(
            color: AppColors.primary, borderRadius: BorderRadius.circular(100),
          ),
          child: Text('${conv.unreadCount}', style: const TextStyle(
            color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900,
          )),
        ),
      ]),
      onTap: () => Get.toNamed(AppRoutes.CLIENT_MESSAGES),
    );
  }

  String _formatTime(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 60) return '${diff.inMinutes}min';
    if (diff.inHours < 24) return '${diff.inHours}h';
    return DateFormat('dd/MM').format(dt);
  }
}

class _SettingTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String? subtitle;
  final VoidCallback? onTap;
  const _SettingTile({required this.icon, required this.label, this.subtitle, this.onTap});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppColors.slate100),
    ),
    child: ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: AppColors.primaryLight, borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: AppColors.primary, size: 20),
      ),
      title: Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
      subtitle: subtitle != null ? Text(subtitle!, style: const TextStyle(fontSize: 12)) : null,
      trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.slate400),
      onTap: onTap,
    ),
  );
}
