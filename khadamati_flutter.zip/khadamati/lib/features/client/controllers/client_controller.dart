import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/models/app_models.dart';
import '../../../core/services/storage_service.dart';
import '../../../app/routes/app_routes.dart';

class ClientController extends GetxController {
  final bookings = <BookingModel>[].obs;
  final conversations = <ConversationModel>[].obs;
  final favorites = <ArtisanModel>[].obs;
  final isLoading = false.obs;
  final currentUser = Rxn<UserModel>();
  final selectedTab = 0.obs;
  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final cityCtrl = TextEditingController();

  @override
  void onInit() {
    super.onInit();
    currentUser.value = StorageService.getUser();
    _load();
  }

  void _load() {
    isLoading.value = true;
    Future.delayed(const Duration(milliseconds: 600), () {
      bookings.assignAll(MockData.clientBookings);
      conversations.assignAll(MockData.conversations);
      favorites.assignAll(MockData.artisans.take(2).toList());
      if (currentUser.value != null) {
        nameCtrl.text = currentUser.value!.name;
        phoneCtrl.text = currentUser.value!.phone;
        cityCtrl.text = currentUser.value!.city;
      }
      isLoading.value = false;
    });
  }

  int get totalBookings => bookings.length;
  int get pendingBookings => bookings.where((b) => b.status == 'pending').length;
  int get activeBookings => bookings.where((b) => b.status == 'confirmed').length;
  int get completedBookings => bookings.where((b) => b.status == 'completed').length;

  void logout() {
    Get.dialog(AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('Déconnexion', style: TextStyle(fontWeight: FontWeight.w900)),
      content: const Text('Voulez-vous vraiment vous déconnecter ?'),
      actions: [
        TextButton(onPressed: () => Get.back(), child: const Text('Annuler')),
        ElevatedButton(
          onPressed: () async {
            Get.back();
            await StorageService.clearAll();
            Get.offAllNamed(AppRoutes.HOME);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFEF4444),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          child: const Text('Déconnexion'),
        ),
      ],
    ));
  }

  @override
  void onClose() {
    nameCtrl.dispose(); phoneCtrl.dispose(); cityCtrl.dispose();
    super.onClose();
  }
}
