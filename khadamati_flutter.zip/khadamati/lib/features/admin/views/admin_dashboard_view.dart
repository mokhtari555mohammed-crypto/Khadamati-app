import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../../../app/theme/app_theme.dart';
import '../../../app/routes/app_routes.dart';
import '../../../core/models/app_models.dart';
import '../../../shared/widgets/app_widgets.dart';
import '../controllers/admin_controller.dart';
import 'admin_layout.dart';

class AdminDashboardView extends GetView<AdminController> {
  const AdminDashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return AdminLayout(
      title: 'Dashboard Admin',
      currentIndex: 0,
      child: Obx(() => controller.isLoading.value
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () async {},
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(20),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  // Welcome
                  Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(
                        'Bonjour, ${controller.currentUser.value?.name.split(' ').first ?? 'Admin'} 👋',
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.slate900),
                      ),
                      const Text('Vue globale de la plateforme',
                          style: TextStyle(color: AppColors.slate400, fontSize: 13)),
                    ])),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [AppColors.primary, Color(0xFF0066CC)]),
                        borderRadius: BorderRadius.circular(100),
                      ),
                      child: Row(children: [
                        const Icon(Icons.diamond_outlined, color: Colors.white, size: 14),
                        const SizedBox(width: 6),
                        Text('premium_edition'.tr, style: const TextStyle(
                          color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1,
                        )),
                      ]),
                    ),
                  ]),
                  const SizedBox(height: 24),

                  // Stats grid
                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 2,
                    childAspectRatio: 1.35,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    children: [
                      StatCard(
                        title: 'total_artisans'.tr,
                        value: '${controller.stats.value?.totalArtisans ?? 0}',
                        icon: Icons.engineering_rounded,
                        color: AppColors.primary,
                        subtitle: '+8 ce mois',
                      ),
                      StatCard(
                        title: 'total_clients'.tr,
                        value: '${controller.stats.value?.totalClients ?? 0}',
                        icon: Icons.people_rounded,
                        color: AppColors.secondary,
                        subtitle: '+34 ce mois',
                      ),
                      StatCard(
                        title: 'total_bookings'.tr,
                        value: '${controller.stats.value?.totalBookings ?? 0}',
                        icon: Icons.assignment_rounded,
                        color: AppColors.emerald500,
                        subtitle: '+120 ce mois',
                      ),
                      StatCard(
                        title: 'Revenu total',
                        value: '${((controller.stats.value?.totalRevenue ?? 0) / 1000000).toStringAsFixed(1)}M DA',
                        icon: Icons.account_balance_wallet_rounded,
                        color: AppColors.purple500,
                        subtitle: '+15% ce mois',
                      ),
                    ],
                  ),
                  const SizedBox(height: 28),

                  // Revenue chart
                  const SectionTitle(title: 'Revenus mensuels'),
                  const SizedBox(height: 16),
                  Container(
                    height: 220,
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppColors.slate100),
                      boxShadow: [BoxShadow(
                        color: Colors.black.withOpacity(0.04),
                        blurRadius: 16, offset: const Offset(0, 4),
                      )],
                    ),
                    child: BarChart(BarChartData(
                      barTouchData: BarTouchData(enabled: false),
                      titlesData: FlTitlesData(
                        bottomTitles: AxisTitles(sideTitles: SideTitles(
                          showTitles: true,
                          getTitlesWidget: (v, _) {
                            const labels = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun'];
                            final i = v.toInt();
                            if (i < 0 || i >= labels.length) return const Text('');
                            return Padding(
                              padding: const EdgeInsets.only(top: 6),
                              child: Text(labels[i], style: const TextStyle(
                                fontSize: 10, color: AppColors.slate400, fontWeight: FontWeight.w600,
                              )),
                            );
                          },
                          reservedSize: 28,
                        )),
                        leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      ),
                      gridData: FlGridData(
                        show: true,
                        drawVerticalLine: false,
                        getDrawingHorizontalLine: (_) => FlLine(
                          color: AppColors.slate100, strokeWidth: 1,
                        ),
                      ),
                      borderData: FlBorderData(show: false),
                      barGroups: [
                        _bar(0, 320000),
                        _bar(1, 410000),
                        _bar(2, 380000),
                        _bar(3, 520000),
                        _bar(4, 480000),
                        _bar(5, 650000),
                      ],
                    )),
                  ),
                  const SizedBox(height: 28),

                  // Quick nav cards
                  const SectionTitle(title: 'Gestion rapide'),
                  const SizedBox(height: 14),
                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 3,
                    childAspectRatio: 0.95,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    children: [
                      _NavCard('Artisans', Icons.engineering_rounded, AppColors.primary,
                          AppRoutes.ADMIN_ARTISANS),
                      _NavCard('Clients', Icons.people_rounded, AppColors.secondary,
                          AppRoutes.ADMIN_CLIENTS),
                      _NavCard('Projets', Icons.folder_open_rounded, AppColors.emerald500,
                          AppRoutes.ADMIN_PROJECTS),
                      _NavCard('Vérif.', Icons.verified_user_rounded, AppColors.blue500,
                          AppRoutes.ADMIN_VERIFICATIONS),
                      _NavCard('Paiements', Icons.payments_rounded, AppColors.purple500,
                          AppRoutes.ADMIN_PAYMENTS),
                      _NavCard('Config.', Icons.tune_rounded, AppColors.amber500,
                          AppRoutes.ADMIN_CONFIGURATION),
                    ],
                  ),
                  const SizedBox(height: 28),

                  // Recent activities
                  SectionTitle(
                    title: 'recent_activities'.tr,
                    action: 'Voir tout',
                    onAction: () {},
                  ),
                  const SizedBox(height: 14),
                  ..._recentActivities(),

                  // Pending verifications alert
                  if ((controller.unverifiedArtisans.length) > 0) ...[
                    const SizedBox(height: 16),
                    GestureDetector(
                      onTap: () => Get.toNamed(AppRoutes.ADMIN_VERIFICATIONS),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFFFFFBEB), Color(0xFFFEF3C7)],
                          ),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppColors.amber500.withOpacity(0.3)),
                        ),
                        child: Row(children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: AppColors.amber500, borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(Icons.pending_actions_rounded, color: Colors.white, size: 22),
                          ),
                          const SizedBox(width: 14),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(
                              '${controller.unverifiedArtisans.length} vérification(s) en attente',
                              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: AppColors.slate900),
                            ),
                            const Text('Cliquez pour traiter les demandes',
                                style: TextStyle(fontSize: 12, color: AppColors.slate400)),
                          ])),
                          const Icon(Icons.chevron_right_rounded, color: AppColors.amber500),
                        ]),
                      ),
                    ),
                  ],
                ]),
              ),
            )),
    );
  }

  BarChartGroupData _bar(int x, double y) => BarChartGroupData(x: x, barRods: [
    BarChartRodData(
      toY: y / 10000,
      gradient: const LinearGradient(
        colors: [AppColors.primary, Color(0xFF0066CC)],
        begin: Alignment.bottomCenter, end: Alignment.topCenter,
      ),
      width: 24, borderRadius: BorderRadius.circular(6),
    ),
  ]);

  List<Widget> _recentActivities() {
    final activities = [
      {'icon': Icons.person_add_rounded, 'color': AppColors.primary,
       'title': 'Nouveau artisan inscrit', 'subtitle': 'Sofiane B. — Peinture', 'time': '5 min'},
      {'icon': Icons.assignment_rounded, 'color': AppColors.emerald500,
       'title': 'Nouvelle réservation #3241', 'subtitle': 'Plomberie — Alger', 'time': '12 min'},
      {'icon': Icons.verified_user_rounded, 'color': AppColors.secondary,
       'title': 'Demande de vérification', 'subtitle': 'Youcef M. — Constantine', 'time': '1h'},
      {'icon': Icons.payments_rounded, 'color': AppColors.purple500,
       'title': 'Paiement reçu', 'subtitle': '15 000 DA — Booking #3240', 'time': '2h'},
    ];
    return activities.map((a) => Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.slate100),
      ),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: (a['color'] as Color).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(a['icon'] as IconData, color: a['color'] as Color, size: 20),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(a['title'] as String, style: const TextStyle(
            fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.slate900,
          )),
          Text(a['subtitle'] as String, style: const TextStyle(
            fontSize: 11, color: AppColors.slate400,
          )),
        ])),
        Text(a['time'] as String, style: const TextStyle(
          fontSize: 11, color: AppColors.slate400, fontWeight: FontWeight.w600,
        )),
      ]),
    )).toList();
  }
}

class _NavCard extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final String route;
  const _NavCard(this.label, this.icon, this.color, this.route);

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () => Get.toNamed(route),
    child: Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.slate100),
        boxShadow: [BoxShadow(
          color: color.withOpacity(0.06),
          blurRadius: 12, offset: const Offset(0, 4),
        )],
      ),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: color, size: 22),
        ),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(
          fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.slate700,
        )),
      ]),
    ),
  );
}
