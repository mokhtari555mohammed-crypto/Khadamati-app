import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../../app/theme/app_theme.dart';
import '../../../core/models/app_models.dart';
import '../../../shared/widgets/app_widgets.dart';
import '../controllers/admin_controller.dart';
import 'admin_layout.dart';

// ─── ADMIN ARTISANS VIEW ──────────────────────────────────────────────────────
class AdminArtisansView extends GetView<AdminController> {
  const AdminArtisansView({super.key});

  @override
  Widget build(BuildContext context) {
    return AdminLayout(
      title: 'Gestion Artisans',
      currentIndex: 1,
      child: Column(children: [
        // Search & filter bar
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            TextField(
              onChanged: (v) => controller.searchQuery.value = v,
              decoration: InputDecoration(
                hintText: 'Rechercher un artisan...',
                prefixIcon: const Icon(Icons.search_rounded, color: AppColors.primary),
                filled: true, fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: AppColors.slate100),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: AppColors.slate100),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Obx(() => SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                _filterChip('Tous', 'all'),
                _filterChip('Vérifiés', 'verified'),
                _filterChip('Non vérifiés', 'unverified'),
              ]),
            )),
          ]),
        ),
        // List
        Expanded(
          child: Obx(() {
            final list = controller.filteredArtisans;
            if (list.isEmpty) return const EmptyState(
              icon: Icons.engineering_rounded, title: 'Aucun artisan trouvé',
            );
            return ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              itemCount: list.length,
              itemBuilder: (_, i) => _ArtisanAdminCard(artisan: list[i]),
            );
          }),
        ),
      ]),
    );
  }

  Widget _filterChip(String label, String value) {
    final selected = controller.selectedFilter.value == value;
    return GestureDetector(
      onTap: () => controller.selectedFilter.value = value,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : Colors.white,
          borderRadius: BorderRadius.circular(100),
          border: Border.all(color: selected ? AppColors.primary : AppColors.slate200),
        ),
        child: Text(label, style: TextStyle(
          fontSize: 12, fontWeight: FontWeight.w800,
          color: selected ? Colors.white : AppColors.slate500,
        )),
      ),
    );
  }
}

class _ArtisanAdminCard extends GetView<AdminController> {
  final ArtisanModel artisan;
  const _ArtisanAdminCard({required this.artisan});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.slate100),
        boxShadow: [BoxShadow(
          color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 4),
        )],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          AvatarCircle(initials: artisan.initials, size: 48),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text(artisan.name, style: const TextStyle(
                fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.slate900,
              ))),
              if (artisan.isVerified)
                const Icon(Icons.verified_rounded, color: AppColors.primary, size: 16),
            ]),
            Text(artisan.specialty, style: const TextStyle(
              fontSize: 12, color: AppColors.primary, fontWeight: FontWeight.w700,
            )),
            Row(children: [
              const Icon(Icons.location_on_outlined, size: 12, color: AppColors.slate400),
              Text(artisan.city, style: const TextStyle(fontSize: 11, color: AppColors.slate400)),
              const SizedBox(width: 8),
              Text('★ ${artisan.rating}', style: const TextStyle(
                fontSize: 11, color: AppColors.secondary, fontWeight: FontWeight.w700,
              )),
            ]),
          ])),
          StatusBadge(status: artisan.isVerified ? 'verified' : 'pending'),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _stat('${artisan.projectsDone}', 'Projets')),
          Expanded(child: _stat('${artisan.yearsExperience}', 'Ans exp.')),
          Expanded(child: _stat('${artisan.reviewCount}', 'Avis')),
        ]),
        if (!artisan.isVerified) ...[
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: AppButton(
              label: 'Vérifier', isSmall: true, color: AppColors.emerald500,
              icon: Icons.check_rounded,
              onTap: () => controller.verifyArtisan(artisan.id),
            )),
            const SizedBox(width: 8),
            Expanded(child: AppButton(
              label: 'Refuser', isSmall: true, isOutlined: true, color: AppColors.red500,
              icon: Icons.close_rounded,
              onTap: () => controller.refuseArtisan(artisan.id),
            )),
          ]),
        ],
      ]),
    );
  }

  Widget _stat(String v, String l) => Column(children: [
    Text(v, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AppColors.slate900)),
    Text(l, style: const TextStyle(fontSize: 10, color: AppColors.slate400, fontWeight: FontWeight.w600)),
  ]);
}

// ─── ADMIN CLIENTS VIEW ───────────────────────────────────────────────────────
class AdminClientsView extends GetView<AdminController> {
  const AdminClientsView({super.key});

  @override
  Widget build(BuildContext context) {
    return AdminLayout(
      title: 'Gestion Clients',
      currentIndex: 2,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            onChanged: (v) => controller.searchQuery.value = v,
            decoration: InputDecoration(
              hintText: 'Rechercher un client...',
              prefixIcon: const Icon(Icons.search_rounded, color: AppColors.primary),
              filled: true, fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: const BorderSide(color: AppColors.slate100),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: const BorderSide(color: AppColors.slate100),
              ),
            ),
          ),
        ),
        // Summary row
        Obx(() => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            _summaryChip('${controller.clients.length}', 'Total', AppColors.primary),
            const SizedBox(width: 8),
            _summaryChip('${controller.clients.where((c) => c.isVerified).length}', 'Actifs', AppColors.emerald500),
          ]),
        )),
        const SizedBox(height: 12),
        Expanded(
          child: Obx(() {
            final list = controller.filteredClients;
            if (list.isEmpty) return const EmptyState(icon: Icons.people_outline_rounded, title: 'Aucun client');
            return ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: list.length,
              itemBuilder: (_, i) => _ClientAdminCard(client: list[i]),
            );
          }),
        ),
      ]),
    );
  }

  Widget _summaryChip(String v, String l, Color c) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
    decoration: BoxDecoration(color: c.withOpacity(0.1), borderRadius: BorderRadius.circular(100)),
    child: Row(children: [
      Text(v, style: TextStyle(fontWeight: FontWeight.w900, color: c)),
      const SizedBox(width: 4),
      Text(l, style: TextStyle(fontSize: 12, color: c, fontWeight: FontWeight.w600)),
    ]),
  );
}

class _ClientAdminCard extends GetView<AdminController> {
  final UserModel client;
  const _ClientAdminCard({required this.client});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(16),
      border: Border.all(color: AppColors.slate100),
    ),
    child: Row(children: [
      AvatarCircle(initials: client.initials, size: 46, color: AppColors.secondary),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(client.name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
        Text(client.email, style: const TextStyle(fontSize: 11, color: AppColors.slate400)),
        Row(children: [
          const Icon(Icons.location_on_outlined, size: 12, color: AppColors.slate400),
          Text(client.city, style: const TextStyle(fontSize: 11, color: AppColors.slate400)),
          const SizedBox(width: 8),
          Text(DateFormat('dd/MM/yyyy').format(client.createdAt),
              style: const TextStyle(fontSize: 10, color: AppColors.slate300)),
        ]),
      ])),
      PopupMenuButton<String>(
        icon: const Icon(Icons.more_vert_rounded, color: AppColors.slate400),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onSelected: (v) {
          if (v == 'delete') {
            Get.dialog(AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              title: const Text('Supprimer ce client ?', style: TextStyle(fontWeight: FontWeight.w900)),
              content: Text('${client.name} sera définitivement supprimé.'),
              actions: [
                TextButton(onPressed: () => Get.back(), child: const Text('Annuler')),
                ElevatedButton(
                  onPressed: () { Get.back(); controller.deleteClient(client.id); },
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.red500,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                  child: const Text('Supprimer'),
                ),
              ],
            ));
          }
        },
        itemBuilder: (_) => [
          const PopupMenuItem(value: 'view', child: Row(children: [
            Icon(Icons.visibility_outlined, size: 18, color: AppColors.primary),
            SizedBox(width: 8), Text('Voir le profil'),
          ])),
          const PopupMenuItem(value: 'delete', child: Row(children: [
            Icon(Icons.delete_outline_rounded, size: 18, color: AppColors.red500),
            SizedBox(width: 8), Text('Supprimer', style: TextStyle(color: AppColors.red500)),
          ])),
        ],
      ),
    ]),
  );
}

// ─── ADMIN PROJECTS VIEW ──────────────────────────────────────────────────────
class AdminProjectsView extends GetView<AdminController> {
  const AdminProjectsView({super.key});

  @override
  Widget build(BuildContext context) {
    return AdminLayout(
      title: 'Gestion Projets',
      currentIndex: 3,
      child: DefaultTabController(
        length: 4,
        child: Column(children: [
          const TabBar(
            labelColor: AppColors.primary,
            unselectedLabelColor: AppColors.slate400,
            indicatorColor: AppColors.primary,
            isScrollable: true,
            labelStyle: TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
            tabs: [
              Tab(text: 'Tous'), Tab(text: 'En attente'),
              Tab(text: 'En cours'), Tab(text: 'Terminés'),
            ],
          ),
          Expanded(child: Obx(() => TabBarView(children: [
            _projectList(controller.projects),
            _projectList(controller.projects.where((p) => p.status == 'pending').toList()),
            _projectList(controller.projects.where((p) => p.status == 'confirmed' || p.status == 'active').toList()),
            _projectList(controller.projects.where((p) => p.status == 'completed').toList()),
          ]))),
        ]),
      ),
    );
  }

  Widget _projectList(List<BookingModel> list) {
    if (list.isEmpty) return const EmptyState(icon: Icons.folder_open_rounded, title: 'Aucun projet');
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: list.length,
      itemBuilder: (_, i) => _ProjectAdminCard(booking: list[i]),
    );
  }
}

class _ProjectAdminCard extends StatelessWidget {
  final BookingModel booking;
  const _ProjectAdminCard({required this.booking});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(18),
      border: Border.all(color: AppColors.slate100),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: AppColors.primaryLight, borderRadius: BorderRadius.circular(8),
          ),
          child: Text('#${booking.id}', style: const TextStyle(
            fontSize: 10, fontWeight: FontWeight.w900, color: AppColors.primary,
          )),
        ),
        const SizedBox(width: 8),
        Expanded(child: Text(booking.serviceTitle, style: const TextStyle(
          fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.slate900,
        ))),
        StatusBadge(status: booking.status),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        const Icon(Icons.person_outline_rounded, size: 14, color: AppColors.slate400),
        const SizedBox(width: 4),
        Text(booking.clientName, style: const TextStyle(fontSize: 12, color: AppColors.slate500)),
        const SizedBox(width: 12),
        const Icon(Icons.calendar_today_rounded, size: 13, color: AppColors.slate400),
        const SizedBox(width: 4),
        Text(DateFormat('dd/MM/yyyy').format(booking.bookingDate),
            style: const TextStyle(fontSize: 12, color: AppColors.slate400)),
        const Spacer(),
        Text('${booking.totalPrice.toInt()} DA', style: const TextStyle(
          fontSize: 14, fontWeight: FontWeight.w900, color: AppColors.secondary,
        )),
      ]),
    ]),
  );
}

// ─── ADMIN VERIFICATIONS VIEW ─────────────────────────────────────────────────
class AdminVerificationsView extends GetView<AdminController> {
  const AdminVerificationsView({super.key});

  @override
  Widget build(BuildContext context) {
    return AdminLayout(
      title: 'Vérifications',
      currentIndex: 4,
      child: Obx(() {
        final list = controller.unverifiedArtisans;
        return Column(children: [
          // Banner
          if (list.isNotEmpty) Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.amber50, borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.amber500.withOpacity(0.3)),
            ),
            child: Row(children: [
              const Icon(Icons.pending_actions_rounded, color: AppColors.amber500),
              const SizedBox(width: 10),
              Text(
                '${list.length} demande(s) en attente de vérification',
                style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.amber500),
              ),
            ]),
          ),
          Expanded(
            child: list.isEmpty
                ? const EmptyState(
                    icon: Icons.verified_user_rounded,
                    title: 'Tout est vérifié !',
                    subtitle: 'Aucune demande de vérification en attente.',
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: list.length,
                    itemBuilder: (_, i) => _VerifCard(artisan: list[i]),
                  ),
          ),
        ]);
      }),
    );
  }
}

class _VerifCard extends GetView<AdminController> {
  final ArtisanModel artisan;
  const _VerifCard({required this.artisan});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 14),
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(20),
      border: Border.all(color: AppColors.slate100),
      boxShadow: [BoxShadow(
        color: Colors.black.withOpacity(0.04), blurRadius: 12, offset: const Offset(0, 4),
      )],
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        AvatarCircle(initials: artisan.initials, size: 50),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(artisan.name, style: const TextStyle(
            fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.slate900,
          )),
          Text(artisan.specialty, style: const TextStyle(
            fontSize: 12, color: AppColors.primary, fontWeight: FontWeight.w700,
          )),
          Row(children: [
            const Icon(Icons.location_on_outlined, size: 12, color: AppColors.slate400),
            Text(artisan.city, style: const TextStyle(fontSize: 11, color: AppColors.slate400)),
            const SizedBox(width: 8),
            const Icon(Icons.phone_outlined, size: 12, color: AppColors.slate400),
            Text(artisan.phone, style: const TextStyle(fontSize: 11, color: AppColors.slate400)),
          ]),
        ])),
      ]),
      const SizedBox(height: 14),
      // Docs checklist
      _docRow('Pièce d\'identité', true),
      _docRow('Photo de profil', true),
      _docRow('Certification professionnelle', false),
      const SizedBox(height: 14),
      Row(children: [
        Expanded(child: AppButton(
          label: 'Vérifier', color: AppColors.emerald500,
          icon: Icons.check_rounded,
          onTap: () => controller.verifyArtisan(artisan.id),
        )),
        const SizedBox(width: 10),
        Expanded(child: AppButton(
          label: 'Refuser', isOutlined: true, color: AppColors.red500,
          icon: Icons.close_rounded,
          onTap: () => controller.refuseArtisan(artisan.id),
        )),
      ]),
    ]),
  );

  Widget _docRow(String label, bool uploaded) => Padding(
    padding: const EdgeInsets.only(bottom: 6),
    child: Row(children: [
      Icon(
        uploaded ? Icons.check_circle_rounded : Icons.cancel_rounded,
        size: 16, color: uploaded ? AppColors.emerald500 : AppColors.red500,
      ),
      const SizedBox(width: 8),
      Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.slate600)),
      const Spacer(),
      Text(uploaded ? 'Soumis' : 'Manquant', style: TextStyle(
        fontSize: 10, fontWeight: FontWeight.w800,
        color: uploaded ? AppColors.emerald500 : AppColors.red500,
      )),
    ]),
  );
}

// ─── ADMIN PAYMENTS VIEW ──────────────────────────────────────────────────────
class AdminPaymentsView extends GetView<AdminController> {
  const AdminPaymentsView({super.key});

  static const _payments = [
    {'ref': 'PAY-001', 'client': 'Ahmed B.', 'artisan': 'Mohammed A.', 'amount': 12000, 'status': 'completed', 'date': '2024-01-15'},
    {'ref': 'PAY-002', 'client': 'Sara M.', 'artisan': 'Karim H.', 'amount': 8500, 'status': 'pending', 'date': '2024-01-16'},
    {'ref': 'PAY-003', 'client': 'Omar K.', 'artisan': 'Youcef M.', 'amount': 25000, 'status': 'completed', 'date': '2024-01-17'},
    {'ref': 'PAY-004', 'client': 'Fatima Z.', 'artisan': 'Rachid H.', 'amount': 5000, 'status': 'refunded', 'date': '2024-01-18'},
    {'ref': 'PAY-005', 'client': 'Hichem B.', 'artisan': 'Nabil C.', 'amount': 18000, 'status': 'pending', 'date': '2024-01-19'},
    {'ref': 'PAY-006', 'client': 'Leila H.', 'artisan': 'Sofiane B.', 'amount': 7500, 'status': 'completed', 'date': '2024-01-20'},
  ];

  @override
  Widget build(BuildContext context) {
    final total = _payments.where((p) => p['status'] == 'completed')
        .fold(0, (s, p) => s + (p['amount'] as int));
    final pending = _payments.where((p) => p['status'] == 'pending').length;

    return AdminLayout(
      title: 'Paiements',
      currentIndex: 5,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          // Summary cards
          Row(children: [
            Expanded(child: StatCard(
              title: 'Total encaissé', icon: Icons.payments_rounded,
              value: '${(total / 1000).toStringAsFixed(0)}K DA', color: AppColors.emerald500,
            )),
            const SizedBox(width: 12),
            Expanded(child: StatCard(
              title: 'En attente', icon: Icons.hourglass_empty_rounded,
              value: '$pending', color: AppColors.amber500,
            )),
          ]),
          const SizedBox(height: 20),
          const SectionTitle(title: 'Transactions récentes'),
          const SizedBox(height: 14),
          ..._payments.map((p) => _PaymentRow(payment: p)).toList(),
        ]),
      ),
    );
  }
}

class _PaymentRow extends StatelessWidget {
  final Map<String, dynamic> payment;
  const _PaymentRow({required this.payment});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppColors.slate100),
    ),
    child: Row(children: [
      Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: _statusColor(payment['status'] as String).withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(Icons.payments_rounded,
            color: _statusColor(payment['status'] as String), size: 20),
      ),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text(payment['ref'] as String, style: const TextStyle(
            fontSize: 12, fontWeight: FontWeight.w900, color: AppColors.primary,
          )),
          const SizedBox(width: 8),
          StatusBadge(status: payment['status'] as String),
        ]),
        const SizedBox(height: 2),
        Text('${payment['client']} → ${payment['artisan']}',
            style: const TextStyle(fontSize: 11, color: AppColors.slate400)),
      ])),
      Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text('${(payment['amount'] as int).toString()} DA', style: const TextStyle(
          fontSize: 13, fontWeight: FontWeight.w900, color: AppColors.slate900,
        )),
        Text(payment['date'] as String, style: const TextStyle(
          fontSize: 10, color: AppColors.slate400,
        )),
      ]),
    ]),
  );

  Color _statusColor(String s) {
    switch (s) {
      case 'completed': return AppColors.emerald500;
      case 'pending': return AppColors.amber500;
      case 'refunded': return AppColors.red500;
      default: return AppColors.slate400;
    }
  }
}
