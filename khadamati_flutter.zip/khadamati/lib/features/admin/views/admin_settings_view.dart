import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/theme/app_theme.dart';
import '../../../shared/widgets/app_widgets.dart';
import '../controllers/admin_controller.dart';
import 'admin_layout.dart';

// ─── ADMIN SETTINGS VIEW ──────────────────────────────────────────────────────
class AdminSettingsView extends GetView<AdminController> {
  const AdminSettingsView({super.key});

  @override
  Widget build(BuildContext context) {
    return AdminLayout(
      title: 'Paramètres Admin',
      currentIndex: 8,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          // Profile card
          Obx(() => Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF0F172A), Color(0xFF1E293B)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Row(children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppColors.primary, Color(0xFF0066CC)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(Icons.diamond_outlined, color: Colors.white, size: 28),
              ),
              const SizedBox(width: 16),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(
                  controller.currentUser.value?.name ?? 'Super Admin',
                  style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900),
                ),
                Text(
                  controller.currentUser.value?.email ?? 'admin@khadamati.dz',
                  style: const TextStyle(color: Colors.white60, fontSize: 12),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(100),
                  ),
                  child: const Text('SUPER ADMIN', style: TextStyle(
                    color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 2,
                  )),
                ),
              ]),
            ]),
          )),
          const SizedBox(height: 28),

          // Stats summary
          Row(children: [
            Expanded(child: _InfoCard('${MockData.artisans.length}', 'Artisans', AppColors.primary)),
            const SizedBox(width: 12),
            Expanded(child: _InfoCard('8', 'Clients', AppColors.secondary)),
            const SizedBox(width: 12),
            Expanded(child: _InfoCard('${MockData.artisanBookings.length}', 'Projets', AppColors.emerald500)),
          ]),
          const SizedBox(height: 28),

          const SectionTitle(title: 'Compte'),
          const SizedBox(height: 14),
          _tile(Icons.person_outline_rounded, 'Mon profil', subtitle: 'Modifier vos informations'),
          _tile(Icons.lock_outline_rounded, 'Changer le mot de passe'),
          _tile(Icons.notifications_none_rounded, 'Notifications', trailing: Switch(
            value: true, onChanged: (_) {},
            activeColor: AppColors.primary,
          )),
          const SizedBox(height: 24),

          const SectionTitle(title: 'Langue & Région'),
          const SizedBox(height: 14),
          _tile(Icons.language_rounded, 'Langue',
              subtitle: Get.locale?.languageCode == 'ar' ? 'العربية' : 'Français',
              onTap: () {
                final cur = Get.locale?.languageCode ?? 'fr';
                final next = cur == 'fr' ? 'ar' : 'fr';
                Get.updateLocale(Locale(next, next == 'ar' ? 'AR' : 'FR'));
              }),
          _tile(Icons.access_time_rounded, 'Fuseau horaire', subtitle: 'Alger GMT+1'),
          const SizedBox(height: 24),

          const SectionTitle(title: 'À propos'),
          const SizedBox(height: 14),
          _tile(Icons.info_outline_rounded, 'Version de l\'application', subtitle: 'v1.0.0'),
          _tile(Icons.help_outline_rounded, 'Aide & Support'),
          _tile(Icons.privacy_tip_outlined, 'Politique de confidentialité'),
          const SizedBox(height: 28),

          AppButton(
            label: 'Déconnexion',
            onTap: controller.logout,
            isOutlined: true, color: AppColors.red500,
            width: double.infinity, icon: Icons.logout_rounded,
          ),
        ]),
      ),
    );
  }

  Widget _tile(IconData icon, String label, {String? subtitle, Widget? trailing, VoidCallback? onTap}) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppColors.slate100),
    ),
    child: ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(10)),
        child: Icon(icon, color: AppColors.primary, size: 20),
      ),
      title: Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
      subtitle: subtitle != null ? Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.slate400)) : null,
      trailing: trailing ?? const Icon(Icons.chevron_right_rounded, color: AppColors.slate400),
      onTap: onTap,
    ),
  );
}

class _InfoCard extends StatelessWidget {
  final String value, label;
  final Color color;
  const _InfoCard(this.value, this.label, this.color);

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(16),
    ),
    child: Column(children: [
      Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: color)),
      Text(label, style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w700)),
    ]),
  );
}

// ─── ADMIN EVIDENCE VIEW ──────────────────────────────────────────────────────
class AdminEvidenceView extends GetView<AdminController> {
  const AdminEvidenceView({super.key});

  static const _evidences = [
    {'artisan': 'Mohammed Amine B.', 'project': 'Réparation plomberie', 'type': 'before', 'date': '2024-01-15'},
    {'artisan': 'Karim H.', 'project': 'Installation tableau électrique', 'type': 'after', 'date': '2024-01-16'},
    {'artisan': 'Youcef M.', 'project': 'Pose cuisine sur mesure', 'type': 'before', 'date': '2024-01-17'},
    {'artisan': 'Rachid H.', 'project': 'Carrelage salon', 'type': 'after', 'date': '2024-01-17'},
    {'artisan': 'Sofiane B.', 'project': 'Peinture appartement', 'type': 'before', 'date': '2024-01-18'},
    {'artisan': 'Nabil C.', 'project': 'Escalier en fer forgé', 'type': 'after', 'date': '2024-01-19'},
  ];

  @override
  Widget build(BuildContext context) {
    return AdminLayout(
      title: 'Preuves de travaux',
      currentIndex: 6,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            _badge('Avant', AppColors.amber500, _evidences.where((e) => e['type'] == 'before').length),
            const SizedBox(width: 8),
            _badge('Après', AppColors.emerald500, _evidences.where((e) => e['type'] == 'after').length),
          ]),
        ),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, childAspectRatio: 0.85,
              crossAxisSpacing: 12, mainAxisSpacing: 12,
            ),
            itemCount: _evidences.length,
            itemBuilder: (_, i) => _EvidenceCard(evidence: _evidences[i]),
          ),
        ),
      ]),
    );
  }

  Widget _badge(String label, Color color, int count) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
    decoration: BoxDecoration(
      color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(100),
    ),
    child: Text('$label ($count)', style: TextStyle(
      fontWeight: FontWeight.w800, color: color, fontSize: 13,
    )),
  );
}

class _EvidenceCard extends StatelessWidget {
  final Map<String, dynamic> evidence;
  const _EvidenceCard({required this.evidence});

  @override
  Widget build(BuildContext context) {
    final isBefore = evidence['type'] == 'before';
    return Container(
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.slate100),
        boxShadow: [BoxShadow(
          color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 4),
        )],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Placeholder image
        Container(
          height: 120,
          decoration: BoxDecoration(
            color: isBefore ? AppColors.amber50 : AppColors.emerald50,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
          ),
          alignment: Alignment.center,
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.photo_rounded,
                size: 40, color: isBefore ? AppColors.amber500 : AppColors.emerald500),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
              decoration: BoxDecoration(
                color: isBefore ? AppColors.amber500 : AppColors.emerald500,
                borderRadius: BorderRadius.circular(100),
              ),
              child: Text(
                isBefore ? 'AVANT' : 'APRÈS',
                style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900),
              ),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(evidence['artisan'] as String, style: const TextStyle(
              fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.slate900,
            )),
            Text(evidence['project'] as String, style: const TextStyle(
              fontSize: 10, color: AppColors.slate400,
            ), maxLines: 1, overflow: TextOverflow.ellipsis),
            Text(evidence['date'] as String, style: const TextStyle(
              fontSize: 9, color: AppColors.slate300,
            )),
          ]),
        ),
      ]),
    );
  }
}

// ─── ADMIN CONFIGURATION VIEW ─────────────────────────────────────────────────
class AdminConfigurationView extends GetView<AdminController> {
  const AdminConfigurationView({super.key});

  @override
  Widget build(BuildContext context) {
    final commissionRate = 10.0.obs;
    final maxDevisPerDay = 5.obs;
    final maintenanceMode = false.obs;
    final emailNotifs = true.obs;
    final smsNotifs = false.obs;
    final autoVerify = false.obs;

    return AdminLayout(
      title: 'Configuration',
      currentIndex: 7,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Warning banner
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.amber50, borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.amber500.withOpacity(0.3)),
            ),
            child: Row(children: [
              const Icon(Icons.warning_amber_rounded, color: AppColors.amber500),
              const SizedBox(width: 10),
              const Expanded(child: Text(
                'Les modifications ici affectent toute la plateforme.',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.amber500),
              )),
            ]),
          ),
          const SizedBox(height: 24),

          const SectionTitle(title: 'Paramètres financiers'),
          const SizedBox(height: 14),
          _configCard(Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('Taux de commission (%)', style: TextStyle(fontWeight: FontWeight.w700)),
              Obx(() => Text('${commissionRate.value.toInt()}%', style: const TextStyle(
                fontWeight: FontWeight.w900, color: AppColors.primary, fontSize: 16,
              ))),
            ]),
            Obx(() => Slider(
              value: commissionRate.value, min: 0, max: 30,
              divisions: 30, activeColor: AppColors.primary,
              onChanged: (v) => commissionRate.value = v,
            )),
          ])),
          const SizedBox(height: 12),
          _configCard(Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('Devis max / jour', style: TextStyle(fontWeight: FontWeight.w700)),
              Obx(() => Text('${maxDevisPerDay.value}', style: const TextStyle(
                fontWeight: FontWeight.w900, color: AppColors.primary, fontSize: 16,
              ))),
            ]),
            Obx(() => Slider(
              value: maxDevisPerDay.value.toDouble(), min: 1, max: 20,
              divisions: 19, activeColor: AppColors.primary,
              onChanged: (v) => maxDevisPerDay.value = v.toInt(),
            )),
          ])),
          const SizedBox(height: 24),

          const SectionTitle(title: 'Notifications'),
          const SizedBox(height: 14),
          _switchTile('Notifications email', emailNotifs),
          const SizedBox(height: 8),
          _switchTile('Notifications SMS', smsNotifs),
          const SizedBox(height: 24),

          const SectionTitle(title: 'Système'),
          const SizedBox(height: 14),
          _switchTile('Mode maintenance', maintenanceMode, color: AppColors.red500),
          const SizedBox(height: 8),
          _switchTile('Vérification automatique', autoVerify, color: AppColors.emerald500),
          const SizedBox(height: 32),

          AppButton(
            label: 'Sauvegarder la configuration',
            width: double.infinity,
            icon: Icons.save_rounded,
            onTap: () => Get.snackbar(
              'Configuration sauvegardée', 'Les paramètres ont été mis à jour.',
              backgroundColor: AppColors.emerald500, colorText: Colors.white,
              snackPosition: SnackPosition.BOTTOM, margin: const EdgeInsets.all(16),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _configCard(Widget child) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(16),
      border: Border.all(color: AppColors.slate100),
    ),
    child: child,
  );

  Widget _switchTile(String label, RxBool value, {Color? color}) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppColors.slate100),
    ),
    child: Obx(() => SwitchListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
      value: value.value,
      activeColor: color ?? AppColors.primary,
      onChanged: (v) => value.value = v,
    )),
  );
}
