import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/theme/app_theme.dart';
import '../../../app/routes/app_routes.dart';
import '../../../shared/widgets/app_widgets.dart';
import '../controllers/admin_controller.dart';

class AdminLayout extends GetView<AdminController> {
  final Widget child;
  final String title;
  final int currentIndex;
  final List<Widget>? actions;
  final Widget? floatingActionButton;

  const AdminLayout({
    super.key,
    required this.child,
    required this.title,
    required this.currentIndex,
    this.actions,
    this.floatingActionButton,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgAdmin,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Row(children: [
          Container(
            width: 30, height: 30,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.primary, Color(0xFF0066CC)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            alignment: Alignment.center,
            child: const Icon(Icons.diamond_outlined, color: Colors.white, size: 16),
          ),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        ]),
        actions: [
          ...?actions,
          IconButton(icon: const Icon(Icons.notifications_none_rounded), onPressed: () {}),
        ],
        leading: Builder(builder: (ctx) => IconButton(
          icon: const Icon(Icons.menu_rounded),
          onPressed: () => Scaffold.of(ctx).openDrawer(),
        )),
      ),
      drawer: _buildDrawer(),
      bottomNavigationBar: _buildBottomNav(),
      floatingActionButton: floatingActionButton,
      body: child,
    );
  }

  Widget _buildDrawer() => Drawer(
    child: Column(children: [
      // Dark header
      Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(24, 56, 24, 28),
        color: const Color(0xFF0F172A),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.primary, Color(0xFF0066CC)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [BoxShadow(
                color: AppColors.primary.withOpacity(0.4),
                blurRadius: 20, offset: const Offset(0, 8),
              )],
            ),
            child: const Icon(Icons.diamond_outlined, color: Colors.white, size: 28),
          ),
          const SizedBox(height: 16),
          const Text('KHADAMATI', style: TextStyle(
            color: Colors.white, fontSize: 18,
            fontWeight: FontWeight.w900, letterSpacing: 3,
          )),
          const Text('ADMIN', style: TextStyle(
            color: AppColors.secondary, fontSize: 10,
            fontWeight: FontWeight.w900, letterSpacing: 3,
          )),
          const SizedBox(height: 16),
          Obx(() => Text(
            controller.currentUser.value?.name ?? 'Super Admin',
            style: const TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w600),
          )),
        ]),
      ),
      // Nav items
      Expanded(child: Container(
        color: const Color(0xFF0F172A),
        child: ListView(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), children: [
          _drawerItem(Icons.dashboard_rounded, 'Tableau de bord', AppRoutes.ADMIN_DASHBOARD, 0),
          _drawerItem(Icons.engineering_rounded, 'Artisans', AppRoutes.ADMIN_ARTISANS, 1),
          _drawerItem(Icons.people_rounded, 'Clients', AppRoutes.ADMIN_CLIENTS, 2),
          _drawerItem(Icons.folder_open_rounded, 'Projets', AppRoutes.ADMIN_PROJECTS, 3),
          _drawerItem(Icons.verified_user_rounded, 'Vérifications', AppRoutes.ADMIN_VERIFICATIONS, 4),
          _drawerItem(Icons.payments_rounded, 'Paiements', AppRoutes.ADMIN_PAYMENTS, 5),
          _drawerItem(Icons.photo_library_rounded, 'Preuves', AppRoutes.ADMIN_EVIDENCE, 6),
          _drawerItem(Icons.tune_rounded, 'Configuration', AppRoutes.ADMIN_CONFIGURATION, 7),
          const Divider(color: Color(0xFF334155), height: 24),
          _drawerItem(Icons.settings_outlined, 'Paramètres', AppRoutes.ADMIN_SETTINGS, 8),
        ]),
      )),
      Container(
        color: const Color(0xFF0F172A),
        padding: const EdgeInsets.all(16),
        child: AppButton(
          label: 'Déconnexion', onTap: controller.logout,
          isOutlined: true, color: AppColors.red500, width: double.infinity,
          icon: Icons.logout_rounded,
        ),
      ),
    ]),
  );

  Widget _drawerItem(IconData icon, String label, String route, int index) {
    final isActive = currentIndex == index;
    return Container(
      margin: const EdgeInsets.only(bottom: 2),
      decoration: BoxDecoration(
        color: isActive ? AppColors.primary.withOpacity(0.2) : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        border: isActive ? Border.all(color: AppColors.primary.withOpacity(0.4)) : null,
      ),
      child: ListTile(
        dense: true,
        leading: Icon(icon, color: isActive ? AppColors.primary : const Color(0xFF64748B), size: 20),
        title: Text(label, style: TextStyle(
          fontWeight: FontWeight.w700, fontSize: 13,
          color: isActive ? Colors.white : const Color(0xFF94A3B8),
        )),
        onTap: () { Get.back(); if (route != Get.currentRoute) Get.offNamed(route); },
      ),
    );
  }

  Widget _buildBottomNav() => NavigationBar(
    selectedIndex: currentIndex.clamp(0, 5),
    onDestinationSelected: (i) {
      const routes = [
        AppRoutes.ADMIN_DASHBOARD, AppRoutes.ADMIN_ARTISANS,
        AppRoutes.ADMIN_CLIENTS, AppRoutes.ADMIN_PROJECTS,
        AppRoutes.ADMIN_VERIFICATIONS, AppRoutes.ADMIN_SETTINGS,
      ];
      if (i < routes.length) Get.offNamed(routes[i]);
    },
    backgroundColor: Colors.white,
    indicatorColor: AppColors.primaryLight,
    destinations: const [
      NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard_rounded), label: 'Dashboard'),
      NavigationDestination(icon: Icon(Icons.engineering_outlined), selectedIcon: Icon(Icons.engineering_rounded), label: 'Artisans'),
      NavigationDestination(icon: Icon(Icons.people_outline_rounded), selectedIcon: Icon(Icons.people_rounded), label: 'Clients'),
      NavigationDestination(icon: Icon(Icons.folder_outlined), selectedIcon: Icon(Icons.folder_rounded), label: 'Projets'),
      NavigationDestination(icon: Icon(Icons.verified_outlined), selectedIcon: Icon(Icons.verified_rounded), label: 'Vérif.'),
      NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: 'Réglages'),
    ],
  );
}
