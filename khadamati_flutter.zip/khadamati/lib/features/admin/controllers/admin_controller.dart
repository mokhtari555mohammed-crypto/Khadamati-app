import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/models/app_models.dart';
import '../../../core/services/storage_service.dart';
import '../../../app/routes/app_routes.dart';

class AdminController extends GetxController {
  final stats = Rxn<AdminStats>();
  final artisans = <ArtisanModel>[].obs;
  final unverifiedArtisans = <ArtisanModel>[].obs;
  final clients = <UserModel>[].obs;
  final projects = <BookingModel>[].obs;
  final isLoading = false.obs;
  final searchQuery = ''.obs;
  final currentUser = Rxn<UserModel>();
  final selectedFilter = 'all'.obs;

  @override
  void onInit() {
    super.onInit();
    currentUser.value = StorageService.getUser();
    _load();
  }

  void _load() {
    isLoading.value = true;
    Future.delayed(const Duration(milliseconds: 700), () {
      stats.value = MockData.adminStats;
      artisans.assignAll(MockData.artisans);
      unverifiedArtisans.assignAll(MockData.artisans.where((a) => !a.isVerified).toList());
      clients.assignAll(_mockClients());
      projects.assignAll(MockData.artisanBookings);
      isLoading.value = false;
    });
  }

  List<UserModel> _mockClients() => List.generate(8, (i) => UserModel(
    id: 100 + i,
    name: ['Ahmed Bensalem', 'Sara Mansouri', 'Omar Khelifi',
           'Fatima Zerrouki', 'Hichem Bouzid', 'Leila Hamidi',
           'Yacine Belloumi', 'Amina Cherif'][i],
    email: 'client${i + 1}@email.com',
    phone: '+213 555 ${(100 + i * 111).toString().padLeft(3, '0')} 000',
    city: ['Alger', 'Oran', 'Constantine', 'Blida', 'Annaba', 'Tlemcen', 'Sétif', 'Batna'][i],
    role: 'client',
    isVerified: true,
    createdAt: DateTime.now().subtract(Duration(days: i * 30)),
  ));

  List<ArtisanModel> get filteredArtisans {
    final q = searchQuery.value.toLowerCase();
    var list = artisans.toList();
    if (q.isNotEmpty) {
      list = list.where((a) =>
          a.name.toLowerCase().contains(q) ||
          a.specialty.toLowerCase().contains(q) ||
          a.city.toLowerCase().contains(q)).toList();
    }
    if (selectedFilter.value == 'verified') list = list.where((a) => a.isVerified).toList();
    if (selectedFilter.value == 'unverified') list = list.where((a) => !a.isVerified).toList();
    return list;
  }

  List<UserModel> get filteredClients {
    final q = searchQuery.value.toLowerCase();
    if (q.isEmpty) return clients.toList();
    return clients.where((c) =>
        c.name.toLowerCase().contains(q) ||
        c.city.toLowerCase().contains(q)).toList();
  }

  void verifyArtisan(int id) {
    final idx = artisans.indexWhere((a) => a.id == id);
    if (idx != -1) {
      unverifiedArtisans.removeWhere((a) => a.id == id);
      artisans.refresh();
      _snack('Artisan vérifié', 'Le compte a été activé avec succès.', AppColors.emerald500);
    }
  }

  void refuseArtisan(int id) {
    unverifiedArtisans.removeWhere((a) => a.id == id);
    artisans.removeWhere((a) => a.id == id);
    _snack('Artisan refusé', 'La demande a été rejetée.', AppColors.red500);
  }

  void deleteClient(int id) {
    clients.removeWhere((c) => c.id == id);
    _snack('Client supprimé', '', AppColors.slate700);
  }

  void _snack(String title, String msg, Color color) => Get.snackbar(
    title, msg,
    backgroundColor: color, colorText: Colors.white,
    snackPosition: SnackPosition.BOTTOM, margin: const EdgeInsets.all(16),
    borderRadius: 16,
  );

  void logout() {
    Get.dialog(AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('Déconnexion', style: TextStyle(fontWeight: FontWeight.w900)),
      content: const Text('Voulez-vous vraiment vous déconnecter ?'),
      actions: [
        TextButton(onPressed: () => Get.back(), child: const Text('Annuler')),
        ElevatedButton(
          onPressed: () async {
            Get.back();
            await StorageService.clearAll();
            Get.offAllNamed(AppRoutes.ADMIN_LOGIN);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFEF4444),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          child: const Text('Déconnexion'),
        ),
      ],
    ));
  }
}
