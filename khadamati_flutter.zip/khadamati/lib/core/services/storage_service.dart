import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import '../models/app_models.dart';

// ─── STORAGE SERVICE ──────────────────────────────────────────────────────────
class StorageService {
  static late SharedPreferences _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static Future<void> saveToken(String token) async =>
      await _prefs.setString('token', token);

  static String? getToken() => _prefs.getString('token');

  static Future<void> saveUser(UserModel user) async =>
      await _prefs.setString('user', jsonEncode(user.toJson()));

  static UserModel? getUser() {
    final s = _prefs.getString('user');
    if (s == null) return null;
    try { return UserModel.fromJson(jsonDecode(s)); } catch (_) { return null; }
  }

  static Future<void> clearAll() async => await _prefs.clear();

  static Locale getLocale() {
    final code = _prefs.getString('locale') ?? 'fr';
    return Locale(code, code == 'ar' ? 'AR' : 'FR');
  }

  static Future<void> setLocale(String code) async =>
      await _prefs.setString('locale', code);

  static bool isLoggedIn() => getToken() != null;
}

// ─── MOCK DATA ────────────────────────────────────────────────────────────────
class MockData {
  static List<ArtisanModel> get artisans => [
    ArtisanModel(
      id: 1, name: 'Mohammed Amine Benali', email: 'amine@email.com',
      phone: '+213 555 123 456', city: 'Alger', specialty: 'Plomberie et Réseaux',
      isVerified: true, isAvailable: true, rating: 4.9, reviewCount: 127,
      yearsExperience: 12, projectsDone: 340,
      bio: 'Plombier certifié avec plus de 12 ans d\'expérience dans tous types de travaux.',
      responseTime: '< 1h', hourlyRate: 2500,
      certifications: ['Certification Professionnelle', 'Sécurité Gaz'],
      createdAt: DateTime(2020, 3, 15),
    ),
    ArtisanModel(
      id: 2, name: 'Karim Hadj Messaoud', email: 'karim@email.com',
      phone: '+213 555 234 567', city: 'Oran', specialty: 'Électricité et Énergie',
      isVerified: true, isAvailable: true, rating: 4.7, reviewCount: 89,
      yearsExperience: 8, projectsDone: 215,
      bio: 'Électricien spécialisé en installation solaire et tableau électrique.',
      responseTime: '< 2h', hourlyRate: 2800,
      certifications: ['Habilitation Électrique BT', 'Panneaux Solaires'],
      createdAt: DateTime(2021, 6, 1),
    ),
    ArtisanModel(
      id: 3, name: 'Youcef Meziane', email: 'youcef@email.com',
      phone: '+213 555 345 678', city: 'Constantine', specialty: 'Menuiserie et Bois',
      isVerified: true, isAvailable: false, rating: 4.8, reviewCount: 203,
      yearsExperience: 15, projectsDone: 520,
      bio: 'Maître menuisier spécialisé en ébénisterie et cuisine sur mesure.',
      responseTime: '< 3h', hourlyRate: 3000,
      certifications: ['Maître Artisan', 'Ébénisterie'],
      createdAt: DateTime(2019, 1, 10),
    ),
    ArtisanModel(
      id: 4, name: 'Sofiane Bekkouche', email: 'sofiane@email.com',
      phone: '+213 555 456 789', city: 'Tlemcen', specialty: 'Peinture et Plâtre',
      isVerified: false, isAvailable: true, rating: 4.5, reviewCount: 56,
      yearsExperience: 5, projectsDone: 120,
      bio: 'Peintre décorateur spécialisé en revêtements modernes et staff.',
      responseTime: '< 4h', hourlyRate: 2000,
      certifications: [],
      createdAt: DateTime(2022, 4, 20),
    ),
    ArtisanModel(
      id: 5, name: 'Rachid Hamidouche', email: 'rachid@email.com',
      phone: '+213 555 567 890', city: 'Alger', specialty: 'Maçonnerie et Finitions',
      isVerified: true, isAvailable: true, rating: 4.6, reviewCount: 145,
      yearsExperience: 20, projectsDone: 680,
      bio: 'Maçon général avec expertise en carrelage, dallage et isolation.',
      responseTime: '< 2h', hourlyRate: 2200,
      certifications: ['Maçon Certifié', 'Isolation Thermique'],
      createdAt: DateTime(2018, 7, 5),
    ),
    ArtisanModel(
      id: 6, name: 'Nabil Chouiref', email: 'nabil@email.com',
      phone: '+213 555 678 901', city: 'Annaba', specialty: 'Ferronnerie et Soudure',
      isVerified: true, isAvailable: true, rating: 4.4, reviewCount: 72,
      yearsExperience: 10, projectsDone: 280,
      bio: 'Ferronnier d\'art et soudeur certifié, spécialisé en escaliers et portails.',
      responseTime: '< 1h', hourlyRate: 2600,
      certifications: ['Soudure Arc', 'Ferronnerie d\'Art'],
      createdAt: DateTime(2021, 2, 14),
    ),
  ];

  static List<BookingModel> get clientBookings => [
    BookingModel(
      id: 1, serviceTitle: 'Réparation fuite d\'eau', clientName: 'Ahmed Bensalem',
      clientId: 10, artisanName: 'Mohammed Amine Benali', artisanId: 1,
      bookingDate: DateTime.now().subtract(const Duration(days: 2)),
      status: 'confirmed', totalPrice: 5000, type: BookingType.booking,
      description: 'Fuite sous l\'évier de cuisine',
    ),
    BookingModel(
      id: 2, serviceTitle: 'Installation tableau électrique', clientName: 'Ahmed Bensalem',
      clientId: 10, artisanName: 'Karim Hadj Messaoud', artisanId: 2,
      bookingDate: DateTime.now().add(const Duration(days: 5)),
      status: 'pending', totalPrice: 15000, type: BookingType.devis,
    ),
    BookingModel(
      id: 3, serviceTitle: 'Peinture salon', clientName: 'Ahmed Bensalem',
      clientId: 10, artisanName: 'Sofiane Bekkouche', artisanId: 4,
      bookingDate: DateTime.now().subtract(const Duration(days: 15)),
      status: 'completed', totalPrice: 8000, type: BookingType.booking,
    ),
  ];

  static List<BookingModel> get artisanBookings => [
    BookingModel(
      id: 101, serviceTitle: 'Remplacement chauffe-eau', clientName: 'Sara Mansouri',
      clientId: 11, artisanId: 1,
      bookingDate: DateTime.now().add(const Duration(days: 1)),
      status: 'confirmed', totalPrice: 12000, type: BookingType.booking,
    ),
    BookingModel(
      id: 102, serviceTitle: 'Débouchage canalisations', clientName: 'Omar Khelifi',
      clientId: 12, artisanId: 1,
      bookingDate: DateTime.now().subtract(const Duration(hours: 6)),
      status: 'active', totalPrice: 3500, type: BookingType.booking,
    ),
    BookingModel(
      id: 103, serviceTitle: 'Installation sanitaires', clientName: 'Fatima Zerrouki',
      clientId: 13, artisanId: 1,
      bookingDate: DateTime.now().subtract(const Duration(days: 7)),
      status: 'completed', totalPrice: 25000, type: BookingType.booking,
    ),
    BookingModel(
      id: 'D-201', serviceTitle: 'Rénovation salle de bain', clientName: 'Hichem Bouzid',
      clientId: 14, artisanId: 1,
      bookingDate: DateTime.now().add(const Duration(days: 3)),
      status: 'pending', totalPrice: 45000, type: BookingType.devis,
    ),
  ];

  static List<ConversationModel> get conversations => [
    ConversationModel(
      id: 1, otherUserId: 1, otherUserName: 'Mohammed Amine Benali',
      lastMessage: 'Je serai disponible demain matin à 9h.',
      lastMessageAt: DateTime.now().subtract(const Duration(minutes: 15)),
      unreadCount: 2, isOnline: true,
    ),
    ConversationModel(
      id: 2, otherUserId: 2, otherUserName: 'Karim Hadj Messaoud',
      lastMessage: 'Le devis vous a été envoyé par email.',
      lastMessageAt: DateTime.now().subtract(const Duration(hours: 2)),
      unreadCount: 0, isOnline: false,
    ),
    ConversationModel(
      id: 3, otherUserId: 5, otherUserName: 'Rachid Hamidouche',
      lastMessage: 'Merci pour votre confiance !',
      lastMessageAt: DateTime.now().subtract(const Duration(days: 1)),
      unreadCount: 0, isOnline: false,
    ),
  ];

  static List<ReviewModel> get reviews => [
    ReviewModel(
      id: 1, clientName: 'Sara M.', rating: 5.0,
      comment: 'Excellent travail, très professionnel et ponctuel. Je recommande vivement !',
      createdAt: DateTime.now().subtract(const Duration(days: 3)),
    ),
    ReviewModel(
      id: 2, clientName: 'Omar K.', rating: 4.5,
      comment: 'Bon artisan, travail soigné. Légèrement en retard mais résultat impeccable.',
      createdAt: DateTime.now().subtract(const Duration(days: 10)),
    ),
    ReviewModel(
      id: 3, clientName: 'Fatima B.', rating: 5.0,
      comment: 'Parfait du début à la fin. Prix raisonnable et qualité au rendez-vous.',
      createdAt: DateTime.now().subtract(const Duration(days: 20)),
    ),
  ];

  static List<CategoryModel> get categories => [
    CategoryModel(id: 1, name: 'Menuiserie et Bois', artisanCount: 45,
        description: 'Ebéniste, coffreur, charpentier, travaux de bois...'),
    CategoryModel(id: 2, name: 'Ferronnerie et Soudure', artisanCount: 32,
        description: 'Soudure arc et argon, ferronnerie d\'art, métallier...'),
    CategoryModel(id: 3, name: 'Plomberie et Réseaux', artisanCount: 78,
        description: 'Sanitaire, chauffage central, fuites et débouchage...'),
    CategoryModel(id: 4, name: 'Électricité et Énergie', artisanCount: 65,
        description: 'Electricien bâtiment, industriel, solaire...'),
    CategoryModel(id: 5, name: 'Peinture et Plâtre', artisanCount: 54,
        description: 'Peintre décorateur, automobile, staff et enduit...'),
    CategoryModel(id: 6, name: 'Maçonnerie et Finitions', artisanCount: 89,
        description: 'Maçon, carreleur, isolation, crépissage...'),
    CategoryModel(id: 7, name: 'Mécanique et Machines', artisanCount: 38,
        description: 'Mécanicien auto et moto, maintenance industrielle...'),
    CategoryModel(id: 8, name: 'Couture et Cuir', artisanCount: 27,
        description: 'Tailleur, couturière, retouches, cordonnerie...'),
    CategoryModel(id: 9, name: 'Verre et Miroiterie', artisanCount: 19,
        description: 'Vitrier, miroitier, double vitrage...'),
    CategoryModel(id: 10, name: 'Métiers Alimentaires', artisanCount: 22,
        description: 'Boulanger, pâtissier, fromager, apiculteur...'),
    CategoryModel(id: 11, name: 'Jardinage et Espaces Verts', artisanCount: 31,
        description: 'Jardinier, espaces verts, irrigation, élagueur...'),
    CategoryModel(id: 12, name: 'Déménagement et Transport', artisanCount: 44,
        description: 'Déménagement, livraison, transport de meubles...'),
  ];

  static ArtisanStats get artisanStats => ArtisanStats(
    totalRevenue: 125000,
    completedBookings: 48,
    activeBookings: 3,
    pendingDevis: 5,
    totalDevis: 24,
    rating: 4.9,
    reviewCount: 127,
    isVerified: true,
  );

  static AdminStats get adminStats => AdminStats(
    totalArtisans: 423,
    totalClients: 1850,
    totalBookings: 3240,
    totalRevenue: 4500000,
    pendingDisputes: 7,
    recentActivities: [
      {'type': 'new_artisan', 'name': 'Sofiane B.', 'time': '5 min'},
      {'type': 'booking', 'name': 'Réservation #3241', 'time': '12 min'},
      {'type': 'verification', 'name': 'Youcef M.', 'time': '1h'},
    ],
  );
}
