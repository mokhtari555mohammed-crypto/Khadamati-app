import 'dart:convert';
import 'package:http/http.dart' as http;
import 'storage_service.dart';
import '../models/app_models.dart';

class ApiService {
  static const String baseUrl = 'https://your-api-url.com/api';

  // ─── HEADERS ──────────────────────────────────────────────────────────────
  static Map<String, String> _headers({bool auth = true}) {
    final token = StorageService.getToken();
    return {
      'Content-Type': 'application/json',
      if (auth && token != null) 'Authorization': 'Bearer $token',
    };
  }

  static Future<dynamic> _handleResponse(http.Response res) async {
    if (res.statusCode >= 200 && res.statusCode < 300) {
      return jsonDecode(res.body);
    } else if (res.statusCode == 401) {
      await StorageService.clearAll();
      throw Exception('Session expirée. Veuillez vous reconnecter.');
    } else {
      final err = jsonDecode(res.body);
      throw Exception(err['error'] ?? 'Erreur ${res.statusCode}');
    }
  }

  // ─── AUTH ──────────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> login({
    required String email,
    required String password,
    required String role,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/auth/login'),
      headers: _headers(auth: false),
      body: jsonEncode({'email': email, 'password': password, 'role': role}),
    );
    return await _handleResponse(res);
  }

  static Future<Map<String, dynamic>> register(Map<String, dynamic> data) async {
    final res = await http.post(
      Uri.parse('$baseUrl/auth/register'),
      headers: _headers(auth: false),
      body: jsonEncode(data),
    );
    return await _handleResponse(res);
  }

  static Future<void> logout() async => await StorageService.clearAll();

  // ─── ARTISANS ─────────────────────────────────────────────────────────────
  static Future<List<ArtisanModel>> getArtisans({Map<String, String>? params}) async {
    final uri = Uri.parse('$baseUrl/artisans').replace(queryParameters: params);
    final res = await http.get(uri, headers: _headers());
    final data = await _handleResponse(res);
    final list = data is List ? data : (data['data'] ?? []);
    return (list as List).map((e) => ArtisanModel.fromJson(e)).toList();
  }

  static Future<ArtisanModel> getArtisanById(int id) async {
    final res = await http.get(Uri.parse('$baseUrl/artisans/$id'), headers: _headers());
    return ArtisanModel.fromJson(await _handleResponse(res));
  }

  static Future<ArtisanStats> getArtisanStats(int id) async {
    final res = await http.get(Uri.parse('$baseUrl/artisans/$id/stats'), headers: _headers());
    return ArtisanStats.fromJson(await _handleResponse(res));
  }

  static Future<List<ArtisanModel>> getUnverifiedArtisans() async {
    final res = await http.get(Uri.parse('$baseUrl/admin/artisans/unverified'), headers: _headers());
    final data = await _handleResponse(res);
    return (data as List).map((e) => ArtisanModel.fromJson(e)).toList();
  }

  static Future<void> verifyArtisan(int id) async {
    await http.put(Uri.parse('$baseUrl/admin/artisans/$id/verify'), headers: _headers());
  }

  static Future<void> refuseArtisan(int id) async {
    await http.put(Uri.parse('$baseUrl/admin/artisans/$id/refuse'), headers: _headers());
  }

  // ─── BOOKINGS ─────────────────────────────────────────────────────────────
  static Future<List<BookingModel>> getClientBookings(int clientId) async {
    final res = await http.get(
        Uri.parse('$baseUrl/bookings/client/$clientId'), headers: _headers());
    final data = await _handleResponse(res);
    return (data as List).map((e) => BookingModel.fromJson(e)).toList();
  }

  static Future<List<BookingModel>> getArtisanBookings(int artisanId) async {
    final res = await http.get(
        Uri.parse('$baseUrl/bookings/artisan/$artisanId'), headers: _headers());
    final data = await _handleResponse(res);
    return (data as List).map((e) => BookingModel.fromJson(e)).toList();
  }

  static Future<void> createBooking(Map<String, dynamic> data) async {
    final res = await http.post(
      Uri.parse('$baseUrl/bookings'),
      headers: _headers(),
      body: jsonEncode(data),
    );
    await _handleResponse(res);
  }

  static Future<void> updateBookingStatus(dynamic id, String status) async {
    final res = await http.put(
      Uri.parse('$baseUrl/bookings/$id/status'),
      headers: _headers(),
      body: jsonEncode({'status': status}),
    );
    await _handleResponse(res);
  }

  // ─── DEVIS ────────────────────────────────────────────────────────────────
  static Future<List<BookingModel>> getPendingDevis(String specialty) async {
    final res = await http.get(
        Uri.parse('$baseUrl/devis/pending?specialty=$specialty'), headers: _headers());
    final data = await _handleResponse(res);
    return (data as List).map((e) => BookingModel.fromJson(e)).toList();
  }

  static Future<void> acceptDevis(dynamic id) async {
    final res = await http.put(
        Uri.parse('$baseUrl/devis/$id/accept'), headers: _headers());
    await _handleResponse(res);
  }

  static Future<void> updateDevisStatus(dynamic id, String status) async {
    final res = await http.put(
      Uri.parse('$baseUrl/devis/$id/status'),
      headers: _headers(),
      body: jsonEncode({'status': status}),
    );
    await _handleResponse(res);
  }

  // ─── MESSAGES ─────────────────────────────────────────────────────────────
  static Future<List<ConversationModel>> getConversations(int userId) async {
    final res = await http.get(
        Uri.parse('$baseUrl/conversations/$userId'), headers: _headers());
    final data = await _handleResponse(res);
    return (data as List).map((e) => ConversationModel.fromJson(e)).toList();
  }

  static Future<List<MessageModel>> getMessages(int conversationId) async {
    final res = await http.get(
        Uri.parse('$baseUrl/messages/$conversationId'), headers: _headers());
    final data = await _handleResponse(res);
    return (data as List).map((e) => MessageModel.fromJson(e)).toList();
  }

  static Future<void> sendMessage({
    required int receiverId,
    required String content,
    int? projectId,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/messages'),
      headers: _headers(),
      body: jsonEncode({'receiver_id': receiverId, 'content': content, 'project_id': projectId}),
    );
    await _handleResponse(res);
  }

  // ─── REVIEWS ─────────────────────────────────────────────────────────────
  static Future<List<ReviewModel>> getArtisanReviews(int artisanId) async {
    final res = await http.get(
        Uri.parse('$baseUrl/reviews/artisan/$artisanId'), headers: _headers());
    final data = await _handleResponse(res);
    return (data as List).map((e) => ReviewModel.fromJson(e)).toList();
  }

  static Future<void> createReview({
    required int artisanId,
    required double rating,
    required String comment,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/reviews'),
      headers: _headers(),
      body: jsonEncode({'artisan_id': artisanId, 'rating': rating, 'comment': comment}),
    );
    await _handleResponse(res);
  }

  // ─── CATEGORIES ──────────────────────────────────────────────────────────
  static Future<List<CategoryModel>> getCategories() async {
    final res = await http.get(Uri.parse('$baseUrl/categories'), headers: _headers(auth: false));
    final data = await _handleResponse(res);
    return (data as List).map((e) => CategoryModel.fromJson(e)).toList();
  }

  // ─── ADMIN ────────────────────────────────────────────────────────────────
  static Future<AdminStats> getAdminStats() async {
    final res = await http.get(Uri.parse('$baseUrl/admin/stats'), headers: _headers());
    return AdminStats.fromJson(await _handleResponse(res));
  }

  static Future<List<UserModel>> getAllClients() async {
    final res = await http.get(Uri.parse('$baseUrl/admin/clients'), headers: _headers());
    final data = await _handleResponse(res);
    return (data as List).map((e) => UserModel.fromJson(e)).toList();
  }

  static Future<List<BookingModel>> getAllProjects() async {
    final res = await http.get(Uri.parse('$baseUrl/admin/projects'), headers: _headers());
    final data = await _handleResponse(res);
    return (data as List).map((e) => BookingModel.fromJson(e)).toList();
  }

  // ─── USER ────────────────────────────────────────────────────────────────
  static Future<UserModel> updateProfile(int id, Map<String, dynamic> data) async {
    final res = await http.put(
      Uri.parse('$baseUrl/users/$id'),
      headers: _headers(),
      body: jsonEncode(data),
    );
    return UserModel.fromJson(await _handleResponse(res));
  }

  static Future<void> changePassword({
    required int userId,
    required String currentPassword,
    required String newPassword,
  }) async {
    final res = await http.put(
      Uri.parse('$baseUrl/users/$userId/password'),
      headers: _headers(),
      body: jsonEncode({'current_password': currentPassword, 'new_password': newPassword}),
    );
    await _handleResponse(res);
  }
}
