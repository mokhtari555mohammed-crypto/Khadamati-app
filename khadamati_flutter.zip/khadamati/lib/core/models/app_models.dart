// ─── USER MODEL ──────────────────────────────────────────────────────────────
class UserModel {
  final int id;
  final String name;
  final String email;
  final String phone;
  final String city;
  final String role; // 'client' | 'artisan' | 'admin'
  final String? profileImage;
  final bool isVerified;
  final DateTime createdAt;

  UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.city,
    required this.role,
    this.profileImage,
    this.isVerified = false,
    required this.createdAt,
  });

  factory UserModel.fromJson(Map<String, dynamic> j) => UserModel(
    id: j['id'] ?? 0,
    name: j['name'] ?? '',
    email: j['email'] ?? '',
    phone: j['phone'] ?? '',
    city: j['city'] ?? '',
    role: j['role'] ?? 'client',
    profileImage: j['profile_image'],
    isVerified: j['is_verified'] ?? false,
    createdAt: DateTime.tryParse(j['created_at'] ?? '') ?? DateTime.now(),
  );

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'email': email,
    'phone': phone, 'city': city, 'role': role,
    'profile_image': profileImage, 'is_verified': isVerified,
    'created_at': createdAt.toIso8601String(),
  };

  String get initials {
    final parts = name.trim().split(' ');
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    return name.isNotEmpty ? name[0].toUpperCase() : 'U';
  }
}

// ─── ARTISAN MODEL ────────────────────────────────────────────────────────────
class ArtisanModel {
  final int id;
  final String name;
  final String email;
  final String phone;
  final String city;
  final String specialty;
  final String? profileImage;
  final bool isVerified;
  final bool isAvailable;
  final double rating;
  final int reviewCount;
  final int yearsExperience;
  final int projectsDone;
  final String? bio;
  final String? responseTime;
  final List<String> certifications;
  final List<String> galleryImages;
  final double? hourlyRate;
  final double? totalRevenue;
  final DateTime createdAt;

  ArtisanModel({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.city,
    required this.specialty,
    this.profileImage,
    this.isVerified = false,
    this.isAvailable = true,
    this.rating = 0.0,
    this.reviewCount = 0,
    this.yearsExperience = 0,
    this.projectsDone = 0,
    this.bio,
    this.responseTime,
    this.certifications = const [],
    this.galleryImages = const [],
    this.hourlyRate,
    this.totalRevenue,
    required this.createdAt,
  });

  factory ArtisanModel.fromJson(Map<String, dynamic> j) => ArtisanModel(
    id: j['id'] ?? 0,
    name: j['name'] ?? '',
    email: j['email'] ?? '',
    phone: j['phone'] ?? '',
    city: j['city'] ?? '',
    specialty: j['specialty'] ?? '',
    profileImage: j['profile_image'],
    isVerified: j['is_verified'] ?? false,
    isAvailable: j['is_available'] ?? true,
    rating: (j['rating'] ?? 0.0).toDouble(),
    reviewCount: j['review_count'] ?? 0,
    yearsExperience: j['years_experience'] ?? 0,
    projectsDone: j['projects_done'] ?? 0,
    bio: j['bio'],
    responseTime: j['response_time'],
    certifications: List<String>.from(j['certifications'] ?? []),
    galleryImages: List<String>.from(j['gallery_images'] ?? []),
    hourlyRate: j['hourly_rate']?.toDouble(),
    totalRevenue: j['total_revenue']?.toDouble(),
    createdAt: DateTime.tryParse(j['created_at'] ?? '') ?? DateTime.now(),
  );

  String get initials {
    final parts = name.trim().split(' ');
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    return name.isNotEmpty ? name[0].toUpperCase() : 'A';
  }
}

// ─── BOOKING MODEL ────────────────────────────────────────────────────────────
enum BookingType { booking, devis }

class BookingModel {
  final dynamic id;
  final String serviceTitle;
  final String clientName;
  final int clientId;
  final String? artisanName;
  final int? artisanId;
  final DateTime bookingDate;
  final String status;
  final double totalPrice;
  final BookingType type;
  final String? description;
  final String? address;

  BookingModel({
    required this.id,
    required this.serviceTitle,
    required this.clientName,
    required this.clientId,
    this.artisanName,
    this.artisanId,
    required this.bookingDate,
    required this.status,
    required this.totalPrice,
    this.type = BookingType.booking,
    this.description,
    this.address,
  });

  factory BookingModel.fromJson(Map<String, dynamic> j) => BookingModel(
    id: j['id'],
    serviceTitle: j['service_title'] ?? j['category_name'] ?? '',
    clientName: j['client_name'] ?? '',
    clientId: j['client_id'] ?? 0,
    artisanName: j['artisan_name'],
    artisanId: j['artisan_id'],
    bookingDate: DateTime.tryParse(j['booking_date'] ?? j['date'] ?? '') ?? DateTime.now(),
    status: j['status'] ?? 'pending',
    totalPrice: (j['total_price'] ?? j['budget'] ?? 0).toDouble(),
    type: (j['type'] == 'devis') ? BookingType.devis : BookingType.booking,
    description: j['description'],
    address: j['address'],
  );

  Color get statusColor {
    switch (status.toLowerCase()) {
      case 'confirmed':
      case 'accepté':
      case 'accepted':
        return const Color(0xFF10B981);
      case 'pending':
      case 'en attente':
        return const Color(0xFFF59E0B);
      case 'completed':
      case 'terminé':
        return const Color(0xFF3B82F6);
      case 'cancelled':
      case 'annulé':
        return const Color(0xFFEF4444);
      default:
        return const Color(0xFF94A3B8);
    }
  }
}

// ─── REVIEW MODEL ─────────────────────────────────────────────────────────────
class ReviewModel {
  final int id;
  final String clientName;
  final String? clientImage;
  final double rating;
  final String comment;
  final DateTime createdAt;

  ReviewModel({
    required this.id,
    required this.clientName,
    this.clientImage,
    required this.rating,
    required this.comment,
    required this.createdAt,
  });

  factory ReviewModel.fromJson(Map<String, dynamic> j) => ReviewModel(
    id: j['id'] ?? 0,
    clientName: j['client_name'] ?? '',
    clientImage: j['client_image'],
    rating: (j['rating'] ?? 0).toDouble(),
    comment: j['comment'] ?? '',
    createdAt: DateTime.tryParse(j['created_at'] ?? '') ?? DateTime.now(),
  );
}

// ─── MESSAGE MODEL ────────────────────────────────────────────────────────────
class MessageModel {
  final int id;
  final int senderId;
  final int receiverId;
  final String content;
  final DateTime createdAt;
  final bool isRead;

  MessageModel({
    required this.id,
    required this.senderId,
    required this.receiverId,
    required this.content,
    required this.createdAt,
    this.isRead = false,
  });

  factory MessageModel.fromJson(Map<String, dynamic> j) => MessageModel(
    id: j['id'] ?? 0,
    senderId: j['sender_id'] ?? 0,
    receiverId: j['receiver_id'] ?? 0,
    content: j['content'] ?? '',
    createdAt: DateTime.tryParse(j['created_at'] ?? '') ?? DateTime.now(),
    isRead: j['is_read'] ?? false,
  );
}

// ─── CONVERSATION MODEL ───────────────────────────────────────────────────────
class ConversationModel {
  final int id;
  final int otherUserId;
  final String otherUserName;
  final String? otherUserImage;
  final String lastMessage;
  final DateTime lastMessageAt;
  final int unreadCount;
  final bool isOnline;

  ConversationModel({
    required this.id,
    required this.otherUserId,
    required this.otherUserName,
    this.otherUserImage,
    required this.lastMessage,
    required this.lastMessageAt,
    this.unreadCount = 0,
    this.isOnline = false,
  });

  factory ConversationModel.fromJson(Map<String, dynamic> j) => ConversationModel(
    id: j['id'] ?? 0,
    otherUserId: j['other_user_id'] ?? 0,
    otherUserName: j['other_user_name'] ?? '',
    otherUserImage: j['other_user_image'],
    lastMessage: j['last_message'] ?? '',
    lastMessageAt: DateTime.tryParse(j['last_message_at'] ?? '') ?? DateTime.now(),
    unreadCount: j['unread_count'] ?? 0,
    isOnline: j['is_online'] ?? false,
  );

  String get initials {
    final parts = otherUserName.trim().split(' ');
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    return otherUserName.isNotEmpty ? otherUserName[0].toUpperCase() : '?';
  }
}

// ─── CATEGORY MODEL ───────────────────────────────────────────────────────────
class CategoryModel {
  final int id;
  final String name;
  final String? description;
  final String? icon;
  final List<SubcategoryModel> subcategories;
  final int artisanCount;

  CategoryModel({
    required this.id,
    required this.name,
    this.description,
    this.icon,
    this.subcategories = const [],
    this.artisanCount = 0,
  });

  factory CategoryModel.fromJson(Map<String, dynamic> j) => CategoryModel(
    id: j['id'] ?? 0,
    name: j['name'] ?? '',
    description: j['description'],
    icon: j['icon'],
    subcategories: (j['subcategories'] as List? ?? [])
        .map((s) => SubcategoryModel.fromJson(s))
        .toList(),
    artisanCount: j['artisan_count'] ?? 0,
  );
}

class SubcategoryModel {
  final int id;
  final String name;
  final int categoryId;
  final String? description;

  SubcategoryModel({
    required this.id,
    required this.name,
    required this.categoryId,
    this.description,
  });

  factory SubcategoryModel.fromJson(Map<String, dynamic> j) => SubcategoryModel(
    id: j['id'] ?? 0,
    name: j['name'] ?? '',
    categoryId: j['category_id'] ?? 0,
    description: j['description'],
  );
}

// ─── DASHBOARD STATS ──────────────────────────────────────────────────────────
class ArtisanStats {
  final double totalRevenue;
  final int completedBookings;
  final int activeBookings;
  final int pendingDevis;
  final int totalDevis;
  final double rating;
  final int reviewCount;
  final bool isVerified;

  ArtisanStats({
    this.totalRevenue = 0,
    this.completedBookings = 0,
    this.activeBookings = 0,
    this.pendingDevis = 0,
    this.totalDevis = 0,
    this.rating = 0,
    this.reviewCount = 0,
    this.isVerified = false,
  });

  factory ArtisanStats.fromJson(Map<String, dynamic> j) => ArtisanStats(
    totalRevenue: (j['totalRevenue'] ?? 0).toDouble(),
    completedBookings: j['completedBookings'] ?? 0,
    activeBookings: j['activeBookings'] ?? 0,
    pendingDevis: j['pendingDevis'] ?? 0,
    totalDevis: j['totalDevis'] ?? 0,
    rating: (j['rating'] ?? 0).toDouble(),
    reviewCount: j['reviewCount'] ?? 0,
    isVerified: j['isVerified'] ?? false,
  );
}

class AdminStats {
  final int totalArtisans;
  final int totalClients;
  final int totalBookings;
  final double totalRevenue;
  final int pendingDisputes;
  final List<dynamic> recentActivities;

  AdminStats({
    this.totalArtisans = 0,
    this.totalClients = 0,
    this.totalBookings = 0,
    this.totalRevenue = 0,
    this.pendingDisputes = 0,
    this.recentActivities = const [],
  });

  factory AdminStats.fromJson(Map<String, dynamic> j) => AdminStats(
    totalArtisans: j['totalArtisans'] ?? 0,
    totalClients: j['totalClients'] ?? 0,
    totalBookings: j['totalBookings'] ?? 0,
    totalRevenue: (j['totalRevenue'] ?? 0).toDouble(),
    pendingDisputes: j['pendingDisputes'] ?? 0,
    recentActivities: j['recentActivities'] ?? [],
  );
}
