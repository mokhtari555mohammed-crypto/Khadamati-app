// This file adds missing color constants used across the app.
// Import this in files that need slate200, slate600, etc.

import 'package:flutter/material.dart';

extension AppColorsExtended on Color {
  // Dummy to allow import
}

// Additional colors not in AppTheme
const kSlate200 = Color(0xFFE2E8F0);
const kSlate600 = Color(0xFF475569);
