# Khadamati — Flutter App 📱
**خدماتي | Plateforme des Artisans**

Application Flutter complète convertie depuis le projet React frontend original.

---

## 🏗️ Architecture

```
lib/
├── main.dart                    # Point d'entrée
├── app/
│   ├── app.dart                 # GetMaterialApp + config
│   ├── routes/                  # Toutes les routes (100+ pages)
│   ├── theme/                   # Couleurs, typographie, thème
│   └── translations/            # Traductions FR + AR
├── core/
│   ├── models/                  # UserModel, ArtisanModel, BookingModel...
│   └── services/                # ApiService + StorageService + MockData
├── features/
│   ├── auth/                    # Splash, Login (3 rôles), Register, ForgotPassword
│   ├── home/                    # HomeView, AboutView
│   ├── search/                  # FindExpert, ArtisanProfile
│   ├── services_pages/          # ServiceDetails, RequestQuote, Pricing, Moving...
│   ├── client/                  # Inbox, Projects, Messages, Favorites, Settings
│   ├── artisan/                 # Dashboard, Projects, Pricing, Messages, Docs, Settings
│   └── admin/                   # Dashboard, Artisans, Clients, Projects, Verif, Payments...
└── shared/
    └── widgets/                 # AppButton, AppTextField, ArtisanCard, StatCard...
```

---

## ⚙️ Technologies

| Lib | Usage |
|-----|-------|
| `get: ^4.6.6` | State Management + Routing + i18n |
| `fl_chart: ^0.68.0` | Graphiques (revenus, stats) |
| `shared_preferences` | Stockage local |
| `http + dio` | Appels API |
| `google_fonts` | Police Outfit |
| `intl` | Formatage dates |

---

## 🚀 Installation

### 1. Prérequis
```bash
flutter --version   # >= 3.0.0
dart --version      # >= 3.0.0
```

### 2. Cloner & installer
```bash
cd khadamati
flutter pub get
```

### 3. Polices Outfit (OBLIGATOIRE)
Téléchargez depuis [Google Fonts - Outfit](https://fonts.google.com/specimen/Outfit) et placez dans `assets/fonts/` :
- `Outfit-Regular.ttf`
- `Outfit-Medium.ttf`
- `Outfit-SemiBold.ttf`
- `Outfit-Bold.ttf`
- `Outfit-ExtraBold.ttf`
- `Outfit-Black.ttf`

### 4. Lancer l'application
```bash
# Android
flutter run

# iOS
cd ios && pod install && cd ..
flutter run
```

---

## 🔗 Connexion API

Dans `lib/core/services/api_service.dart` :
```dart
static const String baseUrl = 'https://VOTRE-API.com/api';
```

Actuellement en mode **Mock Data** (données fictives intégrées).

---

## 👤 Comptes de test (Mock)

| Rôle | Email | Mot de passe |
|------|-------|-------------|
| Client | n'importe lequel | n'importe lequel |
| Artisan | n'importe lequel | n'importe lequel |
| Admin | n'importe lequel | n'importe lequel |

---

## 🌍 Langues

L'app supporte **Français** et **Arabe** (RTL automatique).
Changez la langue depuis : Paramètres → Langue.

---

## 📋 Pages incluses (100+)

### 🔑 Auth
- Splash screen animé
- Login Client / Artisan / Admin
- Register Client / Artisan
- Mot de passe oublié

### 🏠 Public
- Accueil (Hero, Catégories, Comment ça marche, Top Artisans, Avis, CTA)
- À propos
- Recherche d'expert (filtres avancés)
- Profil artisan complet
- Détails service
- Demande de devis
- Tarification
- Réservation déménagement
- Page succès

### 👤 Dashboard Client
- Inbox / Tableau de bord
- Mes projets
- Messages / Conversations
- Favoris
- Paramètres

### 🔧 Dashboard Artisan
- Tableau de bord (stats + graphique)
- Projets & Devis (accepter/refuser)
- Tarification
- Messages
- Documents & Vérifications
- Paramètres

### 🛡️ Dashboard Admin (Premium)
- Dashboard (stats + graphiques)
- Gestion Artisans (filtres, vérif)
- Gestion Clients
- Gestion Projets
- Vérifications documents
- Paiements
- Preuves de travaux
- Configuration plateforme
- Paramètres

---

## 🎨 Design System

```dart
AppColors.primary    = Color(0xFF004C96)  // Bleu principal
AppColors.secondary  = Color(0xFFF28B2C)  // Orange
AppColors.emerald500 = Color(0xFF10B981)  // Vert succès
AppColors.red500     = Color(0xFFEF4444)  // Rouge erreur
AppColors.amber500   = Color(0xFFF59E0B)  // Orange warning
```

---

## 📞 Support

Développé avec ❤️ par Khadamati Team  
**© 2024 Khadamati — Tous droits réservés**
